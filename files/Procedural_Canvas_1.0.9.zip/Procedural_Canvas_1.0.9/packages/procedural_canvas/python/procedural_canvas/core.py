pass
import hou
import os
import sys
import json
import base64
import zlib
import hashlib
import html as html_lib
import math
import re
import time
import uuid
import tempfile
import threading
import traceback
import urllib.parse
import urllib.request
import urllib.error
import ssl
import subprocess


try:
    from PySide6 import QtWidgets, QtCore, QtGui
except ImportError:
    from PySide2 import QtWidgets, QtCore, QtGui


def _qt_class(name):
    pass
    for module in (QtWidgets, QtGui):
        cls = getattr(module, name, None)
        if cls is not None:
            return cls
    raise ImportError(name)


QShortcut = _qt_class('QShortcut')






_SSL_CONTEXT = None


def _ca_count(context):
    try:
        return context.cert_store_stats().get('x509_ca', 0)
    except Exception:
        return 0


def ssl_context():
    global _SSL_CONTEXT
    if _SSL_CONTEXT is not None:
        return _SSL_CONTEXT
    context = ssl.create_default_context()
    if not _ca_count(context):
        sources = []
        try:
            import certifi
            sources.append(('file', certifi.where()))
        except Exception:
            pass
        for path in ('/etc/ssl/cert.pem', '/usr/local/etc/openssl/cert.pem', '/opt/homebrew/etc/openssl@3/cert.pem'):
            sources.append(('file', path))
        if sys.platform == 'darwin':
            sources.append(('keychain', '/System/Library/Keychains/SystemRootCertificates.keychain'))
        for kind, where in sources:
            try:
                if kind == 'file':
                    if os.path.isfile(where):
                        context.load_verify_locations(cafile=where)
                else:
                    pem = subprocess.run(['/usr/bin/security', 'find-certificate', '-a', '-p', where],
                                         capture_output=True, timeout=10).stdout.decode('ascii', 'ignore')
                    if pem.strip():
                        context.load_verify_locations(cadata=pem)
            except Exception:
                continue
            if _ca_count(context):
                break
    _SSL_CONTEXT = context
    return context


def open_url(request, timeout=15):
    pass
    return urllib.request.urlopen(request, timeout=timeout, context=ssl_context())


def _os_env_flag(name, default):
    pass
    value = os.environ.get(name)
    return default if value is None else value.strip().lower() in ('1', 'true', 'yes', 'on')




QtGui.QPixmapCache.setCacheLimit(max(QtGui.QPixmapCache.cacheLimit(), 256 * 1024))





PLUGIN_NAME = 'Procedural Canvas'
PLUGIN_VERSION = '1.0.9'
PLUGIN_AUTHOR = 'Alexander Klymak'
SUPPORT_CONTACT = 'projectcanvas.support@gmail.com'
FORMAT_VERSION = 1
PAYLOAD_PREFIX_V1 = 'HCNV1:'
PAYLOAD_PREFIX = 'HCNV2:'
FRAGMENT_MIME = 'application/x-procedural-canvas'
PARM_NAME = 'canvas_data'
MAX_IMAGE_SIDE = 1600
EXPORT_MAX_SIDE = 8000
HISTORY_LIMIT = 100
SAVE_DELAY_MS = 2000
HANDLE_SIZE = 14
HIT_TOLERANCE = 10
LINK_COLOR = "#a29bfe"
LINK_EDGE_ZONE = 0.25
LINK_FLOW_SPEED = 90.0
LINK_FLOW_SPACING = 46.0
LINK_FLOW_FPS = 30
SCENE_HALF = 2000000


EMULATE_MAXIMIZE = os.name == 'nt'
SIZED_CURSOR_TOOLS =('pen', 'highlighter', 'eraser')
ERASER_SIZE_FACTOR = 4
DEFAULT_PEN_COLOR = '#ff4757'
DEFAULT_PEN_WIDTH = 4
RESET_TOOLS_KEY = 'R'



GPU_VIEWPORT = _os_env_flag('CANVAS_GPU', True)
EXACT_CACHE_MAX_PIXELS =12_000_000
BRUSH_CURSOR_MAX_PX = 256
HIGHLIGHTER_ALPHA = 30
LIST_INDENT = 24
FAST_PAINT_HOLD_MS = 180
ZOOM_PROXY_MIN_GAP_MS = 120
ZOOM_PROXY_COVERAGE = 0.85
ZOOM_PROXY_STRETCH = 1.08
ZOOM_PROXY_SHRINK = 0.55
ZOOM_PROXY_OVERSAMPLE = 1.25
OVERVIEW_MAX_PIXELS = 3_000_000
ZOOM_DIRECT_MS = 10.0
ZOOM_DIRECT_TRIP_MS = 15.0
GRID_TILE_MAX_PX = 256


SHAPE_TOOLS = ('arrow', 'rect', 'ellipse')


MIN_ZOOM, MAX_ZOOM = 0.02, 30.0
ZOOM_PRESETS = (0.25, 0.5, 1.0, 2.0)


HOVER_SCALE = 1.03
GLOW_BLUR = 26
GLOW_ALPHA = 220
SHADOW_BLUR = 30
SHADOW_OFFSET = 12
SHADOW_ALPHA = 170


DROP_GAP = 20
DROP_NORMALIZE_HEIGHT = True


UD_CANVAS_ID = 'project_canvas_id'
UD_COMMENT = 'project_canvas_comment'
LEGACY_THUMB_DIR = '$HIP/canvas_previews'


TOOLBAR_DENSITY = [
    (1500, 36, 190, 110),
    (1150, 30, 150, 80),
    (0, 28, 120, 60),
]


def _pref_path(name):
    pass

    folder = hou.getenv('HOUDINI_USER_PREF_DIR') or hou.homeHoudiniDirectory()
    path = os.path.join(folder, name)
    old = os.path.join(folder, name.replace('procedural_canvas', 'project_canvas', 1))
    if old != path and not os.path.exists(path) and os.path.exists(old):
        try:
            os.replace(old, path)
        except OSError:
            return old
    return path


class CanvasSettings(object):
    pass


    DEFAULTS = {

        'theme': 'dark',
        'canvas_bg': '',
        'accent': '#a29bfe',
        'grid_style': 'lines',
        'grid_default': True,
        'settings_version': 2,
        'update_checked_at': 0.0,
        'auto_update': True,
        'grid_size': 40,
        'image_corner': 5,
        'minimap_visible': True,
        'minimap_corner': 'br',
        'minimap_size': 'M',

        'font_family': '',
        'font_size': 16,

        'zoom_speed': 5,
        'zoom_smooth': 3,
        'hover_strength': 100,
        'hover_open_ms': 1000,
        'node_summary': False,
        'gpu': False,

        'gpu_vsync': False,
        'gpu_samples': 4,
        'gpu_docked': False,
        'frame_stats': False,
        'zoom_proxy': True,
    }

    def __init__(self):
        self.values = dict(self.DEFAULTS)
        self.load()

    @staticmethod
    def path():
        return _pref_path('procedural_canvas_settings.json')

    def load(self):
        try:
            with open(self.path(), 'r', encoding='utf-8') as f:
                data = json.load(f)
            for key, default in self.DEFAULTS.items():
                if key in data and isinstance(data[key], type(default)):
                    self.values[key] = data[key]
            if int(data.get('settings_version') or 1) < 2:

                self.values['grid_default'] = True
        except (OSError, ValueError):
            pass

    def save(self):
        try:
            with open(self.path(), 'w', encoding='utf-8') as f:
                json.dump(self.values, f, indent=2)
        except OSError:
            _log_error('Could not save settings')

    def __getitem__(self, key):
        return self.values[key]


SETTINGS = CanvasSettings()


THEMES = {
    'dark': {
        'canvas': '#1e1e1e', 'toolbar': '#1b1b1b', 'border': '#000000', 'group': '#262626',
        'group_border': '#333333', 'btn': '#353535', 'btn_border': '#474747', 'btn_hover': '#4a4a4a',
        'text': '#ffffff', 'dim': '#9a9a9a', 'caption': '#6f6f6f', 'panel': '#252525',
        'panel_border': '#555555', 'input': '#1a1a1a', 'grid': '#3c3c3c', 'note_text': '#dcdcdc',
        'menu_sep': '#3a3a3a', 'status': '#181818', 'shade': 'rgba(0, 0, 0, 150)',
    },
    'light': {
        'canvas': '#f2f2f5', 'toolbar': '#ffffff', 'border': '#d9d9de', 'group': '#f3f3f6',
        'group_border': '#dcdce2', 'btn': '#ffffff', 'btn_border': '#cfcfd6', 'btn_hover': '#e8e8ee',
        'text': '#1f1f24', 'dim': '#5f5f6a', 'caption': '#8a8a96', 'panel': '#ffffff',
        'panel_border': '#cfcfd6', 'input': '#f7f7f9', 'grid': '#d6d6de', 'note_text': '#26262b',
        'menu_sep': '#e3e3e8', 'status': '#fafafa', 'shade': 'rgba(20, 20, 30, 110)',
    },
}

GLOW_COLOR = [162, 155, 254]


def _theme():
    return THEMES.get(SETTINGS['theme'], THEMES['dark'])


def _canvas_bg():
    return SETTINGS['canvas_bg'] or _theme()['canvas']


def _zoom_per_notch():
    pass
    return 1.03 + SETTINGS['zoom_speed'] * 0.024


def _zoom_smoothing():
    pass
    smooth = SETTINGS['zoom_smooth']
    return 1.0 if smooth <= 0 else max(0.08, 0.55 - smooth * 0.045)


def _refresh_accent():
    color = QtGui.QColor(SETTINGS['accent'])
    if not color.isValid():
        color = QtGui.QColor('#a29bfe')
    GLOW_COLOR[:] = [color.red(), color.green(), color.blue()]


def _style(template):
    pass
    values = dict(_theme())
    accent = QtGui.QColor(*GLOW_COLOR)
    values['accent'] = accent.name()
    values['accent_strong'] = accent.darker(135).name()
    values['accent_hover'] = accent.darker(115).name()
    values['ui_font'] = _font_family('ui')
    values['emoji_font'] = _font_family('emoji')
    values['mono_font'] = _font_family('mono')
    return template % values


_refresh_accent()

FRAME_HEADER = 28
GUIDE_COLOR = '#ff4fd8'
GUIDE_TOLERANCE_PX = 6
STICKY_COLORS = ['#ffeb3b', '#ffd59e', '#ffb3c7', '#d0bfff', '#a5d8ff', '#96f2d7', '#b2f2bb', '#dee2e6']
STICKY_WIDTH = 240
MAX_DOWNLOAD_BYTES = 30 * 1024 * 1024



BRUSH_STABILIZER = 0.3
BRUSH_STEP_PX = 2.0
BRUSH_FINAL_SMOOTHING = 2

BRUSH_STYLES = {
    'smooth': 'Smooth',
    'ink': 'Ink (tapered ends)',
    'calligraphy': 'Calligraphy (flat nib)',
    'chalk': 'Chalk (grainy)',
    'neon': 'Neon glow',
}
BRUSH_SIMPLIFY_PX = 0.35
PATH_SIMPLIFY_MIN_ELEMS = 400
TEXT_LOD_MIN_PX = 1.5

UNLOCK_HOLD_SEC = 1.0
LOCK_BADGE_PX = 26



VEX_COLORS = {
    'default': '#d4d4d4',
    'keyword': '#5f97cf',
    'type': '#7fc8f2',
    'function': '#9d8ff0',
    'attribute': '#e3d8a2',
    'number': '#f0b232',
    'string': '#7fbf62',
    'comment': '#8a8a8a',
    'preprocessor': '#dcd4a0',
}

VEX_FONTS = ['Source Code Pro', 'DejaVu Sans Mono', 'Consolas', 'Menlo']

_FONT_CANDIDATES = {
    'ui': ['Segoe UI', 'SF Pro Text', 'Helvetica Neue', 'Noto Sans', 'DejaVu Sans', 'Liberation Sans'],
    'emoji': ['Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', 'Twemoji', 'EmojiOne Color', 'Symbola'],
    'mono': ['Consolas', 'Source Code Pro', 'Menlo', 'DejaVu Sans Mono', 'Liberation Mono'],
}
_FONT_CHOICE = {}


def _font_families():
    db = QtGui.QFontDatabase
    try:
        return list(db.families())
    except TypeError:
        return list(db().families())


def _font_family(kind):
    pass


    family = _FONT_CHOICE.get(kind)
    if family is None:
        try:
            families = set(_font_families())
        except Exception:
            families = set()
        family = next((f for f in _FONT_CANDIDATES[kind] if f in families), None) or QtGui.QFont().family()
        _FONT_CHOICE[kind] = family
    return family


def _ui_font(pixel_size, bold=False, kind='ui'):
    font = QtGui.QFont(_font_family(kind))
    font.setPixelSize(pixel_size)
    font.setBold(bold)
    return font
VEX_KEYWORDS = {'if', 'else', 'for', 'foreach', 'while', 'do', 'return', 'break', 'continue', 'function',
                'struct', 'export', 'const', 'import'}
VEX_TYPES = {'int', 'float', 'vector', 'vector2', 'vector4', 'matrix', 'matrix2', 'matrix3', 'string', 'void',
             'dict', 'bsdf', 'light', 'material', 'shadow', 'surface', 'displace', 'fog', 'cvex', 'chop', 'cop2'}

VEX_FUNCTIONS = set('''
abs acos addattrib addpoint addprim addvertex append argsort array asin atan atan2 avg ceil ch chf chi chp chramp
chs chu chv chv2 chv4 clamp cos cosh cross degrees detail detailattrib distance distance2 dot efit exp
fit fit01 fit10 fit11 floor frac getbbox getbbox_center getbbox_max getbbox_min getbbox_size haspointattrib
ident insert invert isbound isnan itoa len length length2 lerp log max min nearpoint nearpoints neighbour
neighbourcount neighbours noise normalize npoints nprimitives nvertices onoise pcfilter pcfind pcopen point
pointattrib pointprims pow prim primattrib primpoints primuv print printf push qconvert quaternion radians rand
random relbbox removepoint removeprim removevalue resize reverse rint rotate scale select set setattrib
setdetailattrib setpointattrib setpointgroup setprimattrib setprimgroup setvertexattrib sign sin sinh slerp
smooth snoise sort split sprintf sqrt sum tan tanh toupper tolower translate transpose trunc vector2 vertex
vertexattrib vnoise xnoise xyzdist anoise curlnoise flownoise pnoise sample_sphere_uniform fit_range
chramp chdict getcomp setcomp maketransform cracktransform lookat dihedral primintrinsic findattribval
inpointgroup inprimgroup expandpointgroup expandprimgroup idtopoint nametopoint uvsample intersect
'''.split())


PANEL_NAME = 'procedural_canvas'
_PANEL_XML = r"""<?xml version="1.0" encoding="UTF-8"?>
<pythonPanelDocument>
  <interface name="procedural_canvas" label="Procedural Canvas" icon="MISC_python" showNetworkNavigationBar="false" help_url="">
    <script><![CDATA[
import hou
_panel = None

def onCreateInterface():
    global _panel
    try:
        import procedural_canvas
    except ImportError:
        # The package was removed but the tab is still in a saved desktop: show a hint instead of a traceback
        from hutil.Qt import QtWidgets, QtCore
        label = QtWidgets.QLabel('Procedural Canvas is not installed.\nCopy it into the Houdini packages folder '
                                 '(see INSTALL.txt), or close this tab.')
        label.setAlignment(QtCore.Qt.AlignCenter)
        label.setWordWrap(True)
        return label
    _panel = procedural_canvas.CanvasPanel()
    return _panel

def onDestroyInterface():
    if _panel is not None:
        _panel.shutdown()
]]></script>
    <includeInToolbarMenu menu_position="300" create_separator="false"/>
    <help><![CDATA[]]></help>
  </interface>
</pythonPanelDocument>
"""

TOOLS = [
    ('select', "👆 Select (V)", 'V'),
    ('link', "🔗 Link (L)", 'L'),
    ('pen', "✏️ Brush (B)", 'B'),
    ('highlighter', "🖍 Highlighter (M)", 'M'),
    ('arrow', "↗️ Arrow (A)", 'A'),
    ('rect', "⬜ Rectangle (U)", 'U'),
    ('ellipse', "⭕ Ellipse (O)", 'O'),
    ('frame', "🔲 Frame (F)", 'F'),
    ('eraser', "🧽 Eraser (E)", 'E'),
    ('eyedropper', "💧 Eyedropper (I)", 'I'),
    ('sticky', "📝 Sticky (N)", 'N'),
    ('code', "⌨️ Code (C)", 'C'),
]



_CANVAS_WINDOWS = {}


def _new_id():
    return uuid.uuid4().hex[:12]


LOG_MAX_BYTES = 1024 * 1024


def _log_path():
    return os.path.join(_pref_path('procedural_canvas_logs'), 'procedural_canvas.log')


def platform_tag():
    import platform
    return '%s/%s' % (platform.system().lower(), 'qt%s' % QtCore.qVersion().split('.')[0])


def _system_info():
    pass
    import platform
    try:
        houdini = '%s %s' % (hou.applicationName(), hou.applicationVersionString())
        license_name = hou.licenseCategory().name()
    except Exception:
        houdini, license_name = '?', '?'
    qt_binding = 'PySide6' if 'PySide6' in QtCore.__name__ else 'PySide2'
    try:
        binding_version = __import__(qt_binding).__version__
    except Exception:
        binding_version = '?'
    return ('%s %s | %s (%s) | %s %s, Qt %s | Python %s | %s' % (
        PLUGIN_NAME, PLUGIN_VERSION, houdini, license_name, qt_binding, binding_version, QtCore.qVersion(),
        platform.python_version(), platform.platform()))


_LOG_STATE = {'header': False}


def _write_log(text):
    pass
    try:
        path = _log_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.exists(path) and os.path.getsize(path) > LOG_MAX_BYTES:
            os.replace(path, path + '.1')
            _LOG_STATE['header'] = False
        with open(path, 'a', encoding='utf-8') as f:
            if not _LOG_STATE['header']:
                f.write('\n===== %s | %s =====\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), _system_info()))
                _LOG_STATE['header'] = True
            f.write(text.rstrip() + '\n')
    except Exception:
        pass


def _log_error(message):
    details = traceback.format_exc()
    print('[Procedural Canvas] ' + message)
    if details and not details.startswith('NoneType: None'):
        print(details.rstrip())
    else:
        details = ''
    _write_log('%s ERROR %s\n%s' % (time.strftime('%H:%M:%S'), message, details))


def _log_info(message):
    print('[Procedural Canvas] ' + message)
    _write_log('%s %s' % (time.strftime('%H:%M:%S'), message))


def _install_excepthook():
    pass

    own_dir = os.path.dirname(os.path.abspath(_log_error.__code__.co_filename))

    previous = getattr(sys.excepthook, '_procedural_canvas_previous', sys.excepthook)

    def hook(exc_type, exc, tb):
        try:
            frames = traceback.extract_tb(tb)
            if any(os.path.dirname(os.path.abspath(f.filename)) == own_dir for f in frames):
                _write_log('%s UNHANDLED\n%s' % (time.strftime('%H:%M:%S'),
                                                  ''.join(traceback.format_exception(exc_type, exc, tb))))
        except Exception:
            pass
        previous(exc_type, exc, tb)

    hook._procedural_canvas_previous = previous
    sys.excepthook = hook


_install_excepthook()


def _precise(timer):
    pass

    timer.setTimerType(QtCore.Qt.PreciseTimer)
    return timer


def _exec(obj, *args):
    pass
    fn = getattr(obj, 'exec', None) or getattr(obj, 'exec_')
    return fn(*args)


def _enum_int(value):
    return int(getattr(value, 'value', value))


def _mouse_pressed():
    return _enum_int(QtWidgets.QApplication.mouseButtons()) != 0


def _event_pos(event):
    return event.position() if hasattr(event, 'position') else QtCore.QPointF(event.pos())


def _with_ctrl_for_shift(event):
    pass
    value = (_enum_int(event.modifiers()) & ~_enum_int(QtCore.Qt.ShiftModifier)) | _enum_int(QtCore.Qt.ControlModifier)
    flags = getattr(QtCore.Qt, 'KeyboardModifiers', None) or QtCore.Qt.KeyboardModifier
    mods = flags(value)
    if hasattr(event, 'position'):
        return QtGui.QMouseEvent(event.type(), event.position(), event.scenePosition(), event.globalPosition(),
                                 event.button(), event.buttons(), mods)
    return QtGui.QMouseEvent(event.type(), event.localPos(), event.screenPos(),
                             event.button(), event.buttons(), mods)






_MAC_KEYS = {'A': 0, 'S': 1, 'D': 2, 'F': 3, 'H': 4, 'G': 5, 'Z': 6, 'X': 7, 'C': 8, 'V': 9, 'B': 11, 'Q': 12,
             'W': 13, 'E': 14, 'R': 15, 'Y': 16, 'T': 17, '1': 18, '2': 19, '3': 20, '4': 21, '6': 22, '5': 23,
             '9': 25, '7': 26, '8': 28, '0': 29, ']': 30, 'O': 31, 'U': 32, '[': 33, 'I': 34, 'P': 35, 'L': 37,
             'J': 38, 'K': 40, 'N': 45, 'M': 46}
_LINUX_KEYS = {'1': 2, '2': 3, '3': 4, '4': 5, '5': 6, '6': 7, '7': 8, '8': 9, '9': 10, '0': 11,
               'Q': 16, 'W': 17, 'E': 18, 'R': 19, 'T': 20, 'Y': 21, 'U': 22, 'I': 23, 'O': 24, 'P': 25, '[': 26,
               ']': 27, 'A': 30, 'S': 31, 'D': 32, 'F': 33, 'G': 34, 'H': 35, 'J': 36, 'K': 37, 'L': 38,
               'Z': 44, 'X': 45, 'C': 46, 'V': 47, 'B': 48, 'N': 49, 'M': 50}
_WIN_KEYS = {'[': 0xDB, ']': 0xDD}
_QT_KEYS = {'[': ('Key_BracketLeft', 'Key_BraceLeft'), ']': ('Key_BracketRight', 'Key_BraceRight'),
            '1': ('Key_1', 'Key_Exclam'), '2': ('Key_2', 'Key_At')}


def _key_is(event, char):
    pass
    names = _QT_KEYS.get(char, ('Key_' + char,))
    if any(event.key() == getattr(QtCore.Qt, name) for name in names):
        return True
    try:
        if sys.platform == 'win32':
            return event.nativeVirtualKey() == _WIN_KEYS.get(char, ord(char))
        if sys.platform == 'darwin':
            return event.nativeVirtualKey() == _MAC_KEYS.get(char, -1)
        return event.nativeScanCode() == _LINUX_KEYS.get(char, -9) + 8
    except Exception:
        return False


def _ctrl_letter(event, letter, shift=False):
    pass
    mods = event.modifiers()
    if not mods & QtCore.Qt.ControlModifier or bool(mods & QtCore.Qt.ShiftModifier) != shift:
        return False
    return _key_is(event, letter)


def _set_font_family(fmt, family):
    pass
    if hasattr(fmt, 'setFontFamilies'):
        fmt.setFontFamilies([family])
    else:
        fmt.setFontFamily(family)


_ELEMS_JSON = {}
_ELEMS_JSON_LIMIT = 4000


def _item_json(d):
    pass


    elems = d.get('elems')
    if not isinstance(elems, list) or len(elems) < 8:
        return json.dumps(d, separators=(',', ':'))
    cached = _ELEMS_JSON.get(id(elems))
    if cached is None or cached[0] is not elems:
        if len(_ELEMS_JSON) >= _ELEMS_JSON_LIMIT:
            _ELEMS_JSON.clear()
        cached = _ELEMS_JSON[id(elems)] = (elems, json.dumps(elems, separators=(',', ':')))
    rest = json.dumps({k: v for k, v in d.items() if k != 'elems'}, separators=(',', ':'))
    return rest[:-1] + ',"elems":' + cached[1] + '}'


def encode_payload(doc):





    body = {k: v for k, v in doc.items() if k not in ('assets', 'items')}
    head = json.dumps(body, separators=(',', ':'))
    items = ','.join(_item_json(d) for d in doc.get('items', []))
    raw = (head[:-1] + (',' if len(head) > 2 else '') + '"items":[' + items + ']}').encode('utf-8')
    parts = [PAYLOAD_PREFIX + base64.b64encode(zlib.compress(raw, 6)).decode('ascii')]
    parts.extend('%s:%s' % (aid, b64) for aid, b64 in doc.get('assets', {}).items())
    return ';'.join(parts)


def decode_payload(text):
    text = text.strip()
    if text.startswith(PAYLOAD_PREFIX):
        parts = text[len(PAYLOAD_PREFIX):].split(';')
        doc = json.loads(zlib.decompress(base64.b64decode(parts[0])).decode('utf-8'))
        doc['assets'] = dict(p.split(':', 1) for p in parts[1:] if p)
        return doc
    if text.startswith(PAYLOAD_PREFIX_V1):
        raw = zlib.decompress(base64.b64decode(text[len(PAYLOAD_PREFIX_V1):]))
        return json.loads(raw.decode('utf-8'))
    if text[:1] in ('{', '['):
        return json.loads(text)

    return json.loads(base64.b64decode(text.encode('utf-8')).decode('utf-8'))


def migrate_legacy(items):
    pass
    assets = {}
    migrated = []
    for d in items:
        d = dict(d)
        d['id'] = _new_id()
        if d.get('type') == 'image' and 'b64' in d:
            b64 = d.pop('b64')
            asset_id = hashlib.sha1(base64.b64decode(b64)).hexdigest()
            assets[asset_id] = b64
            d['asset'] = asset_id
        elif d.get('type') == 'path' and 'points' in d:

            d['elems'] = [['L' if i else 'M', p[0], p[1]] for i, p in enumerate(d.pop('points'))]
        migrated.append(d)
    return {'version': FORMAT_VERSION, 'items': migrated, 'links': [], 'assets': assets}


def path_to_elems(path):
    elems = []
    for i in range(path.elementCount()):
        e = path.elementAt(i)
        if e.isMoveTo():
            code = 'M'
        elif e.isLineTo():
            code = 'L'
        elif e.isCurveTo():
            code = 'C'
        else:
            code = 'D'
        elems.append([code, round(e.x, 2), round(e.y, 2)])
    return elems


def elems_to_path(elems):
    path = QtGui.QPainterPath()
    i, n = 0, len(elems)
    while i < n:
        code, x, y = elems[i]
        if code == 'M':
            path.moveTo(x, y)
        elif code == 'C' and i + 2 < n:
            c2, end = elems[i + 1], elems[i + 2]
            path.cubicTo(x, y, c2[1], c2[2], end[1], end[2])
            i += 3
            continue
        else:
            path.lineTo(x, y)
        i += 1
    return path



_SIDE_NORMALS = {'top': (0, -1), 'bottom': (0, 1), 'left': (-1, 0), 'right': (1, 0)}


def _side_point(rect, side):
    c = rect.center()
    if side == 'top':
        return QtCore.QPointF(c.x(), rect.top())
    if side == 'bottom':
        return QtCore.QPointF(c.x(), rect.bottom())
    if side == 'left':
        return QtCore.QPointF(rect.left(), c.y())
    return QtCore.QPointF(rect.right(), c.y())


def _candidate_sides(side):
    return [side] if side in _SIDE_NORMALS else list(_SIDE_NORMALS)


def _side_at(rect, p):
    pass
    if rect.width() <= 0 or rect.height() <= 0 or not rect.contains(p):
        return 'auto'
    dist = {'left': (p.x() - rect.left()) / rect.width(), 'right': (rect.right() - p.x()) / rect.width(),
            'top': (p.y() - rect.top()) / rect.height(), 'bottom': (rect.bottom() - p.y()) / rect.height()}
    side = min(dist, key=dist.get)
    return side if dist[side] < LINK_EDGE_ZONE else 'auto'


def _link_curve(p1, n1, p2, n2):
    k = max(30.0, QtCore.QLineF(p1, p2).length() * 0.4)
    c1 = QtCore.QPointF(p1.x() + n1[0] * k, p1.y() + n1[1] * k)
    c2 = QtCore.QPointF(p2.x() + n2[0] * k, p2.y() + n2[1] * k) if n2 else p2
    path = QtGui.QPainterPath(p1)
    path.cubicTo(c1, c2, p2)
    return path


def _link_path(r1, side1, r2, side2, waypoints=None):
    pass

    if waypoints:
        a = min(_candidate_sides(side1), key=lambda s: QtCore.QLineF(_side_point(r1, s), waypoints[0]).length())
        b = min(_candidate_sides(side2), key=lambda s: QtCore.QLineF(_side_point(r2, s), waypoints[-1]).length())
        pts = [_side_point(r1, a)] + list(waypoints) + [_side_point(r2, b)]
        na, nb = _SIDE_NORMALS[a], _SIDE_NORMALS[b]
        tangents = []
        for i, p in enumerate(pts):
            if i == 0:
                d = QtCore.QLineF(p, pts[1]).length()
                tangents.append(QtCore.QPointF(na[0] * d, na[1] * d))
            elif i == len(pts) - 1:
                d = QtCore.QLineF(pts[-2], p).length()
                tangents.append(QtCore.QPointF(-nb[0] * d, -nb[1] * d))
            else:
                tangents.append((pts[i + 1] - pts[i - 1]) * 0.5)
        path = QtGui.QPainterPath(pts[0])
        for i in range(len(pts) - 1):
            path.cubicTo(pts[i] + tangents[i] / 3.0, pts[i + 1] - tangents[i + 1] / 3.0, pts[i + 1])
        return path
    best = None
    for a in _candidate_sides(side1):
        pa = _side_point(r1, a)
        for b in _candidate_sides(side2):
            pb = _side_point(r2, b)
            d = QtCore.QLineF(pa, pb).length()
            if best is None or d < best[0]:
                best = (d, a, pa, b, pb)
    _, a, pa, b, pb = best
    return _link_curve(pa, _SIDE_NORMALS[a], pb, _SIDE_NORMALS[b])


def _link_preview_path(r1, side1, p2):
    a = min(_candidate_sides(side1), key=lambda s: QtCore.QLineF(_side_point(r1, s), p2).length())
    return _link_curve(_side_point(r1, a), _SIDE_NORMALS[a], p2, None)


def _link_rect(item):
    pass

    if isinstance(item, ShapeNode):
        return item.mapRectToScene(item.geom_rect.normalized())
    return item.sceneBoundingRect()


def _chaikin(points, iterations):
    pass
    for _ in range(iterations):
        if len(points) < 3:
            break
        out = [points[0]]
        for a, b in zip(points, points[1:]):
            out.append(a * 0.75 + b * 0.25)
            out.append(a * 0.25 + b * 0.75)
        out.append(points[-1])
        points = out
    return points


def _simplify_points(points, tolerance):
    pass

    n = len(points)
    if n < 3:
        return list(points)
    keep = [False] * n
    keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        a, b = stack.pop()
        ax, ay, bx, by = points[a].x(), points[a].y(), points[b].x(), points[b].y()
        dx, dy = bx - ax, by - ay
        length = math.hypot(dx, dy)
        best, worst = -1, tolerance
        for i in range(a + 1, b):
            px, py = points[i].x(), points[i].y()
            if length < 1e-9:
                d = math.hypot(px - ax, py - ay)
            else:
                d = abs(dy * px - dx * py + bx * ay - by * ax) / length
            if d > worst:
                best, worst = i, d
        if best >= 0:
            keep[best] = True
            stack.append((a, best))
            stack.append((best, b))
    return [p for p, k in zip(points, keep) if k]


def _simplify_path(path, tolerance):
    pass
    result = QtGui.QPainterPath()
    for poly in path.toSubpathPolygons():
        points = _simplify_points([QtCore.QPointF(p) for p in poly], tolerance)
        if points:
            result.addPath(_points_path(points))
    return result


def _resample(points, step):
    pass
    if len(points) < 2:
        return list(points)
    out = [points[0]]
    since = 0.0
    for a, b in zip(points, points[1:]):
        seg = QtCore.QLineF(a, b).length()
        if seg < 1e-9:
            continue
        pos = 0.0
        while since + (seg - pos) >= step:
            pos += step - since
            out.append(a + (b - a) * (pos / seg))
            since = 0.0
        since += seg - pos
    if QtCore.QLineF(out[-1], points[-1]).length() > 1e-6:
        out.append(points[-1])
    return out


def _ribbon_path(path, width, style):
    pass

    result = QtGui.QPainterPath()
    result.setFillRule(QtCore.Qt.WindingFill)
    nib = math.radians(40)
    for poly in path.toSubpathPolygons():
        pts = _resample([QtCore.QPointF(p) for p in poly], max(1.0, width * 0.35))
        n = len(pts)
        if n < 2:
            continue
        lengths = [0.0]
        for a, b in zip(pts, pts[1:]):
            lengths.append(lengths[-1] + QtCore.QLineF(a, b).length())
        total = max(lengths[-1], 1e-6)
        left, right = [], []
        for i, p in enumerate(pts):
            a, b = pts[max(0, i - 1)], pts[min(n - 1, i + 1)]
            dx, dy = b.x() - a.x(), b.y() - a.y()
            norm = math.hypot(dx, dy) or 1.0
            nx, ny = -dy / norm, dx / norm
            s = lengths[i]
            if style == 'ink':
                start = min(1.0, s / max(total * 0.12, width))
                end = min(1.0, (total - s) / max(total * 0.3, width * 2))
                w = width * max(0.12, min(start, end) ** 0.7) * 1.25
            else:
                angle = math.atan2(dy, dx)
                w = width * (0.18 + 0.82 * abs(math.sin(angle - nib))) * 1.4
                w *= max(0.35, min(1.0, s / width, (total - s) / width))
            left.append(QtCore.QPointF(p.x() + nx * w / 2, p.y() + ny * w / 2))
            right.append(QtCore.QPointF(p.x() - nx * w / 2, p.y() - ny * w / 2))
        result.addPolygon(QtGui.QPolygonF(left + right[::-1]))
        result.closeSubpath()
    return result


_CHALK_CACHE = {}


def _chalk_texture(color):
    pass
    pixmap = _CHALK_CACHE.get(color)
    if pixmap is None:
        import random
        rng = random.Random(7)
        size = 64
        image = QtGui.QImage(size, size, QtGui.QImage.Format_ARGB32)
        base = QtGui.QColor(color)
        for y in range(size):
            for x in range(size):
                v = rng.random()
                alpha = 0 if v < 0.18 else int(110 + 145 * rng.random())
                c = QtGui.QColor(base)
                c.setAlpha(alpha)
                image.setPixelColor(x, y, c)
        pixmap = _CHALK_CACHE[color] = QtGui.QPixmap.fromImage(image)
    return pixmap


def _is_fast_paint(item, widget):
    pass

    if widget is not None:
        view = widget.parentWidget()
        return bool(getattr(view, 'fast_paint', False)) and not getattr(view, '_gpu', False)
    scene = item.scene()
    return any(getattr(v, 'fast_paint', False) for v in (scene.views() if scene is not None else []))


def _first_view(item):
    pass
    scene = item.scene()
    views = scene.views() if scene is not None else []
    return views[0] if views else None


def _view_lod(item):
    pass

    view = _first_view(item)
    if view is None:
        return 1.0
    t = item.sceneTransform()
    return max(1e-6, view.transform().m11() * math.hypot(t.m11(), t.m12()))


def _smooth_through(pts):
    pass
    path = QtGui.QPainterPath(pts[0])
    if len(pts) == 2:
        path.lineTo(pts[1])
        return path
    n = len(pts)
    tangents = [(pts[min(n - 1, i + 1)] - pts[max(0, i - 1)]) * (0.5 if 0 < i < n - 1 else 1.0) for i in range(n)]
    for i in range(n - 1):
        path.cubicTo(pts[i] + tangents[i] / 3.0, pts[i + 1] - tangents[i + 1] / 3.0, pts[i + 1])
    return path


def _path_mids(path):
    pass
    mids = []
    e = path.elementAt
    count = path.elementCount()
    if count < 2:
        return mids
    prev = QtCore.QPointF(e(0).x, e(0).y)
    i = 1
    while i < count:
        el = e(i)
        if el.isCurveTo() and i + 2 < count:
            c1, c2, end = (QtCore.QPointF(e(i + k).x, e(i + k).y) for k in range(3))
            mids.append((prev + c1 * 3 + c2 * 3 + end) / 8.0)
            prev = end
            i += 3
        else:
            end = QtCore.QPointF(el.x, el.y)
            mids.append((prev + end) / 2.0)
            prev = end
            i += 1
    return mids


def _trimmed_path(path, cut_start, cut_end):
    pass
    length = path.length()
    if length <= cut_start + cut_end + 2:
        return path
    t0, t1 = path.percentAtLength(cut_start), path.percentAtLength(length - cut_end)
    n = int(max(12, min(240, length / 5)))
    trimmed = QtGui.QPainterPath(path.pointAtPercent(t0))
    for k in range(1, n + 1):
        trimmed.lineTo(path.pointAtPercent(t0 + (t1 - t0) * k / float(n)))
    return trimmed


def _draw_point_handles(painter, points, mids, lod, ends=()):
    pass
    r = 6.0 / max(lod, 1e-6)
    line = 1.5 / max(lod, 1e-6)
    accent = QtGui.QColor(*GLOW_COLOR)
    painter.setPen(QtGui.QPen(accent, line))
    painter.setBrush(QtGui.QColor('#ffffff'))
    for p in ends:
        painter.drawEllipse(p, r, r)
    painter.setPen(QtGui.QPen(QtGui.QColor('#ffffff'), line))
    painter.setBrush(accent)
    for p in points:
        painter.drawEllipse(p, r, r)
    painter.setPen(QtGui.QPen(accent, line))
    painter.setBrush(QtGui.QColor(_theme()['panel']))
    small = r * 0.75
    for p in mids:
        painter.drawEllipse(p, small, small)
        painter.drawLine(QtCore.QPointF(p.x() - small * 0.5, p.y()), QtCore.QPointF(p.x() + small * 0.5, p.y()))
        painter.drawLine(QtCore.QPointF(p.x(), p.y() - small * 0.5), QtCore.QPointF(p.x(), p.y() + small * 0.5))


def _draw_selection_rect(painter, option, rect):
    pass
    if not option.state & QtWidgets.QStyle.State_Selected:
        return
    painter.setRenderHint(QtGui.QPainter.Antialiasing, False)
    painter.setBrush(QtCore.Qt.NoBrush)
    painter.setPen(QtGui.QPen(option.palette.window().color(), 0, QtCore.Qt.SolidLine))
    painter.drawRect(rect)
    painter.setPen(QtGui.QPen(option.palette.windowText().color(), 0, QtCore.Qt.DashLine))
    painter.drawRect(rect)


def _points_path(points):
    pass
    path = QtGui.QPainterPath(points[0])
    for prev, cur in zip(points[1:-1], points[2:]):
        path.quadTo(prev, (prev + cur) / 2)
    if len(points) > 1:
        path.lineTo(points[-1])
    return path


def _stroke_shape(path, width):
    pass
    stroker = QtGui.QPainterPathStroker()
    stroker.setWidth(max(width, 1) + HIT_TOLERANCE)
    stroker.setCapStyle(QtCore.Qt.RoundCap)
    stroker.setJoinStyle(QtCore.Qt.RoundJoin)
    return stroker.createStroke(path)


LINE_STYLES = (('solid', 'Solid'), ('dash', 'Dashed'), ('dot', 'Dotted'))


def _make_pen(color, width, dash='solid', alpha=None):
    pass
    c = QtGui.QColor(color)
    if alpha is not None:
        c.setAlpha(alpha)
    pen = QtGui.QPen(c, width, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin)
    if dash == 'dash':
        pen.setDashPattern([3.0, 2.2])
    elif dash == 'dot':
        pen.setDashPattern([0.01, 2.2])
    return pen


def _set_origin_keep_place(item, origin):
    pass
    before = item.mapToScene(QtCore.QPointF(0, 0))
    item.setTransformOriginPoint(origin)
    after = item.mapToScene(QtCore.QPointF(0, 0))
    if before != after:
        item.setPos(item.pos() + (before - after))


class _NoHover(object):
    pass
    halo = None

    def suspend(self):
        pass

    def resume(self):
        pass

    def enter(self):
        pass

    def leave(self):
        pass


_NO_HOVER = _NoHover()


def _base_dict(item):
    d = {'id': item.uid, 'type': item.TYPE, 'x': item.pos().x(), 'y': item.pos().y(),
         'z': item.zValue(), 'scale': item.scale(), 'rot': item.rotation()}
    origin = item.transformOriginPoint()
    d['ox'], d['oy'] = round(origin.x(), 3), round(origin.y(), 3)
    if getattr(item, 'locked', False):
        d['locked'] = True
    if getattr(item, 'group_id', None):
        d['group'] = item.group_id
    return d


def _apply_base(item, d):

    if 'ox' in d:
        item.setTransformOriginPoint(d['ox'], d.get('oy', 0))
    elif item.TYPE != 'image':
        item.setTransformOriginPoint(0, 0)
    item.setPos(d.get('x', 0), d.get('y', 0))
    item.setZValue(d.get('z', 0))
    item.setScale(d.get('scale', 1.0))
    item.setRotation(d.get('rot', 0))
    item.group_id = d.get('group')
    _set_locked(item, d.get('locked', False))


def _set_locked(item, locked):
    pass
    item.locked = bool(locked)
    item.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, not item.locked)


def _is_locked(item):
    return getattr(item, 'locked', False)


_ICON_CACHE = {}


def _emoji_icon(text):
    pass

    icon = _ICON_CACHE.get(text)
    if icon is None:
        pixmap = QtGui.QPixmap(64, 64)
        pixmap.fill(QtCore.Qt.transparent)
        painter = QtGui.QPainter(pixmap)
        painter.setRenderHint(QtGui.QPainter.TextAntialiasing)
        painter.setFont(_ui_font(46, kind='emoji'))
        painter.setPen(QtGui.QColor('#ffffff'))
        painter.drawText(pixmap.rect(), QtCore.Qt.AlignCenter, text)
        painter.end()
        icon = _ICON_CACHE[text] = QtGui.QIcon(pixmap)
    return icon


def _swatch_icon(color):
    pass
    pixmap = QtGui.QPixmap(16, 16)
    pixmap.fill(QtCore.Qt.transparent)
    painter = QtGui.QPainter(pixmap)
    painter.setRenderHint(QtGui.QPainter.Antialiasing)
    painter.setBrush(QtGui.QColor(color))
    painter.setPen(QtGui.QPen(QtGui.QColor(0, 0, 0, 90), 1))
    painter.drawRoundedRect(QtCore.QRectF(1, 1, 14, 14), 3, 3)
    painter.end()
    return QtGui.QIcon(pixmap)


def _align_icon(kind):
    pass
    size = 64
    pixmap = QtGui.QPixmap(size, size)
    pixmap.fill(QtCore.Qt.transparent)
    painter = QtGui.QPainter(pixmap)
    painter.setRenderHint(QtGui.QPainter.Antialiasing)
    pen = QtGui.QPen(QtGui.QColor(_theme()['text']), 6, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap)
    painter.setPen(pen)
    for k, length in enumerate((44, 30, 44, 24)):
        y = 14 + k * 12
        if kind == 'left':
            x0 = 10
        elif kind == 'right':
            x0 = size - 10 - length
        else:
            x0 = (size - length) / 2.0
        painter.drawLine(QtCore.QPointF(x0, y), QtCore.QPointF(x0 + length, y))
    painter.end()
    return QtGui.QIcon(pixmap)


class HoverOpener(QtCore.QObject):
    pass


    def __init__(self, widget, open_fn, popup_fn, close_fn):
        super().__init__(widget)
        self.widget = widget
        self.open_fn, self.popup_fn, self.close_fn = open_fn, popup_fn, close_fn
        self._outside = 0
        self._delay = QtCore.QTimer(self)
        self._delay.setSingleShot(True)
        self._delay.timeout.connect(self._open)
        self._watch = QtCore.QTimer(self)
        self._watch.setInterval(120)
        self._watch.timeout.connect(self._check)
        widget.installEventFilter(self)

    def eventFilter(self, obj, event):
        kind = event.type()
        if kind == QtCore.QEvent.Enter:
            delay = SETTINGS['hover_open_ms']
            if delay > 0:
                self._delay.start(delay)
        elif kind in (QtCore.QEvent.Leave, QtCore.QEvent.MouseButtonPress):
            self._delay.stop()
        return False

    def _open(self):
        popup = self.popup_fn()
        if _mouse_pressed() or not self.widget.underMouse() or (popup is not None and popup.isVisible()):
            return
        self.open_fn()
        self._outside = 0
        self._watch.start()

    def _check(self):
        popup = self.popup_fn()
        if popup is None or not popup.isVisible():
            self._watch.stop()
            return
        pos = QtGui.QCursor.pos()
        over_widget = self.widget.rect().contains(self.widget.mapFromGlobal(pos))
        if over_widget or popup.geometry().contains(pos):
            self._outside = 0
            return
        self._outside += 1
        if self._outside >= 3:
            self._watch.stop()
            self.close_fn()


def _fly_to(view, rect, keep_zoom=False, duration=380, on_step=None):
    pass
    vp = view.viewport().rect()
    current = view.transform().m11()
    if rect.width() > 0 and rect.height() > 0:
        fit = min(vp.width() / rect.width(), vp.height() / rect.height())
    else:
        fit = current
    target = min(current, fit) if keep_zoom else fit
    target = max(MIN_ZOOM, min(MAX_ZOOM, target))
    start_center = view.mapToScene(vp.center())
    end_center = rect.center()
    anim = QtCore.QVariantAnimation(view)
    anim.setStartValue(0.0)
    anim.setEndValue(1.0)
    anim.setDuration(duration)
    anim.setEasingCurve(QtCore.QEasingCurve.OutCubic)

    def step(t):
        t = float(t)
        zoom = math.exp(math.log(current) + (math.log(target) - math.log(current)) * t)
        view.setTransform(QtGui.QTransform.fromScale(zoom, zoom))
        view.centerOn(start_center + (end_center - start_center) * t)
        if on_step is not None:
            on_step()

    anim.valueChanged.connect(step)
    anim.finished.connect(anim.deleteLater)
    anim.start()
    return anim, target


def _stop_animation(anim):
    pass
    if anim is None:
        return
    try:
        anim.stop()
        anim.deleteLater()
    except RuntimeError:
        pass


def _geometry_changed(item):
    pass
    for link in getattr(item, 'links', ()):
        link.update_path()
    if item.isSelected():
        scene = item.scene()
        if isinstance(scene, CanvasScene):
            scene.update_selection_box()


def _items_rect(items):
    rect = QtCore.QRectF()
    for item in items:
        rect = rect.united(item.sceneBoundingRect())
    return rect


def _move_top_left(item, target):
    item.setPos(item.pos() + (target - item.sceneBoundingRect().topLeft()))


def _move_group_center(items, center):
    delta = center - _items_rect(items).center()
    for item in items:
        item.setPos(item.pos() + delta)


def _arrange_in_rows(items, origin):
    pass
    heights = sorted(i.boundingRect().height() for i in items)
    row_h = max(1.0, heights[len(heights) // 2])
    if DROP_NORMALIZE_HEIGHT:
        for item in items:
            item.setScale(row_h / max(1.0, item.boundingRect().height()))
    sizes = [(i.boundingRect().width() * i.scale(), i.boundingRect().height() * i.scale()) for i in items]
    total_w = sum(w for w, _ in sizes) + DROP_GAP * (len(items) - 1)
    rows = max(1, int(round(math.sqrt(total_w / (row_h * 1.6)))))
    limit = total_w / rows
    x = y = row_height = 0.0
    for item, (w, h) in zip(items, sizes):
        if x > 0 and x + w > limit * 1.05:
            x = 0.0
            y += row_height + DROP_GAP
            row_height = 0.0
        _move_top_left(item, QtCore.QPointF(origin.x() + x, origin.y() + y))
        x += w + DROP_GAP
        row_height = max(row_height, h)


def _snap_position(item, change, value):
    pass
    if change != QtWidgets.QGraphicsItem.ItemPositionChange:
        return value
    scene = item.scene()
    if not isinstance(scene, CanvasScene) or not scene.snap_to_grid:
        return value
    if not isinstance(scene.mouseGrabberItem(), CANVAS_TYPES):
        return value
    if not item.isSelected():
        return value


    offset = item.sceneBoundingRect().topLeft() - item.pos()
    corner = value + offset
    grid = SETTINGS['grid_size']
    snapped = QtCore.QPointF(round(corner.x() / grid) * grid, round(corner.y() / grid) * grid)
    return snapped - offset


def _encode_image(image):
    if max(image.width(), image.height()) > MAX_IMAGE_SIDE:
        image = image.scaled(MAX_IMAGE_SIDE, MAX_IMAGE_SIDE, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)

    fmt, quality = ('PNG', -1) if image.hasAlphaChannel() else ('JPG', 90)
    byte_array = QtCore.QByteArray()
    buffer = QtCore.QBuffer(byte_array)
    buffer.open(QtCore.QIODevice.WriteOnly)
    image.save(buffer, fmt, quality)
    buffer.close()
    return bytes(byte_array.data())


def _image_bytes_from_data(data):
    pass

    image = QtGui.QImage.fromData(QtCore.QByteArray(data))
    if image.isNull():
        return None
    fmt = _sniff_image_format(data) if data[:4] in (b'\x89PNG', b'GIF8') or data[:2] == b'\xff\xd8' else None
    if fmt == 'GIF' and len(data) <= MAX_DOWNLOAD_BYTES:
        return bytes(data)
    if fmt in ('PNG', 'JPG') and max(image.width(), image.height()) <= MAX_IMAGE_SIDE:
        return bytes(data)
    return _encode_image(image)


def _image_bytes_from_file(file_path):
    try:
        with open(file_path, 'rb') as f:
            return _image_bytes_from_data(f.read())
    except OSError:
        return None


def _focus_network_editor(node):
    node.setSelected(True, clear_all_selected=True)
    try:
        editor = hou.ui.paneTabOfType(hou.paneTabType.NetworkEditor)
        if editor is not None:
            editor.setCurrentNode(node)
            editor.homeToSelection()
    except hou.Error:
        _log_error('Could not focus the Network Editor')
