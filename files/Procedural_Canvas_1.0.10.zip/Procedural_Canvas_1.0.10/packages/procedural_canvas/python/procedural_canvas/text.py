pass

from ._link import pull
pull(globals())




_URL_RE = re.compile(r'(https?://[^\s<>"]+|www\.[^\s<>"]+)')


def _marker(name):
    pass
    enum = getattr(QtGui.QTextBlockFormat, 'MarkerType', QtGui.QTextBlockFormat)
    return getattr(enum, name)


class VexHighlighter(QtGui.QSyntaxHighlighter):
    pass

    _TOKENS = re.compile(
        r'(?P<block>/\*)'
        r'|(?P<comment>//.*)'
        r'|(?P<string>"(?:\\.|[^"\\])*"?|\'(?:\\.|[^\'\\])*\'?)'
        r'|(?P<pre>^\s*#\s*\w+)'
        r'|(?P<attr>(?:[a-zA-Z0-9]\[\]|[a-zA-Z0-9])?@[A-Za-z_]\w*)'
        r'|(?P<number>\b0[xX][0-9a-fA-F]+\b|\b\d+\.?\d*(?:[eE][-+]?\d+)?\b|\.\d+\b)'
        r'|(?P<word>[A-Za-z_]\w*)(?P<call>\s*\()?')

    def __init__(self, document):
        super().__init__(document)
        self._formats = {}
        for name, color in VEX_COLORS.items():
            fmt = QtGui.QTextCharFormat()
            fmt.setForeground(QtGui.QColor(color))
            if name in ('keyword', 'type'):
                fmt.setFontWeight(_enum_int(QtGui.QFont.DemiBold))
            self._formats[name] = fmt

    def _paint(self, start, length, kind):
        self.setFormat(start, length, self._formats[kind])

    def highlightBlock(self, text):
        size = len(text)
        self._paint(0, size, 'default')
        self.setCurrentBlockState(0)
        pos = 0
        if self.previousBlockState() == 1:
            end = text.find('*/')
            if end < 0:
                self._paint(0, size, 'comment')
                self.setCurrentBlockState(1)
                return
            self._paint(0, end + 2, 'comment')
            pos = end + 2
        while pos < size:
            m = self._TOKENS.search(text, pos)
            if m is None:
                break
            start = m.start()
            if m.group('block'):
                end = text.find('*/', m.end())
                if end < 0:
                    self._paint(start, size - start, 'comment')
                    self.setCurrentBlockState(1)
                    return
                self._paint(start, end + 2 - start, 'comment')
                pos = end + 2
                continue
            if m.group('comment'):
                self._paint(start, size - start, 'comment')
                return
            if m.group('word'):
                word = m.group('word')
                if word in VEX_KEYWORDS:
                    kind = 'keyword'
                elif word in VEX_TYPES:
                    kind = 'type'
                elif m.group('call') and word in VEX_FUNCTIONS:
                    kind = 'function'
                else:
                    kind = None
                if kind:
                    self._paint(start, len(word), kind)
                pos = start + len(word)
                continue
            kind = next(k for k in ('string', 'pre', 'attr', 'number') if m.group(k))
            if kind == 'pre':
                self._paint(start, size - start, 'preprocessor')
                return
            self._paint(start, m.end() - start, 'attribute' if kind == 'attr' else kind)
            pos = max(m.end(), start + 1)


class TextNode(QtWidgets.QGraphicsTextItem):
    TYPE = 'text'

    def __init__(self, text="", x=0, y=0, is_sticky=False, is_code=False, houdini_path=None, houdini_abs_path=None,
                 uid=None, bg=None, text_width=-1):
        super().__init__()
        self.uid = uid or _new_id()
        self.is_sticky = is_sticky
        self.is_code = is_code
        self.houdini_path = houdini_path
        self.houdini_abs_path = houdini_abs_path
        self.bg = bg
        self.links = []
        self.last_selection = None
        self._html = None
        self._press_screen = None
        self.hover = HoverEffect(self)

        self._highlighter = VexHighlighter(self.document()) if is_code else None

        self._normalizing = False

        self.document().setIndentWidth(LIST_INDENT)
        self.setHtml(text)
        if is_code:

            option = QtGui.QTextOption(self.document().defaultTextOption())
            option.setWrapMode(QtGui.QTextOption.NoWrap)
            self.document().setDefaultTextOption(option)
            self.document().setDocumentMargin(4)
            self._normalize_code()
        else:
            if text_width and text_width > 0:
                self.setTextWidth(text_width)
            self._remember_font()
        self.setPos(x, y)
        self.setFlags(QtWidgets.QGraphicsItem.ItemIsSelectable | QtWidgets.QGraphicsItem.ItemIsMovable | QtWidgets.QGraphicsItem.ItemIsFocusable | QtWidgets.QGraphicsItem.ItemSendsGeometryChanges)
        self.setCacheMode(QtWidgets.QGraphicsItem.DeviceCoordinateCache)
        self.setAcceptHoverEvents(True)
        self.setTextInteractionFlags(QtCore.Qt.NoTextInteraction)
        self.apply_theme()
        self.setTransformOriginPoint(self.content_rect().center())
        self.grips = ItemGrips(self, rotate=True, width_handle=True)
        self.document().contentsChanged.connect(self._on_contents_changed)

    @classmethod
    def from_dict(cls, d, scene):
        item = cls(d.get('html', ''), is_sticky=d.get('sticky', False), is_code=d.get('code', False),
                   houdini_path=d.get('hpath'), houdini_abs_path=d.get('hpath_abs'), uid=d.get('id'),
                   bg=d.get('bg'), text_width=d.get('tw', -1))
        if d.get('html') is not None:
            item._html = d['html']
        _apply_base(item, d)
        return item

    def html(self):
        if self._html is None:
            self._html = self.toHtml()
        return self._html

    def to_dict(self):
        d = _base_dict(self)
        d.update(html=self.html(), sticky=self.is_sticky, code=self.is_code,
                 hpath=self.houdini_path, hpath_abs=self.houdini_abs_path)
        if self.bg:
            d['bg'] = self.bg
        if self.textWidth() > 0:
            d['tw'] = round(self.textWidth(), 2)
        return d

    def apply_dict(self, d):
        _apply_base(self, d)
        if d.get('bg') != self.bg:
            self.set_bg(d.get('bg'))
        tw = d.get('tw', -1)
        if abs(tw - self.textWidth()) > 0.01:
            self.setTextWidth(tw)
        html = d.get('html')
        if html is not None and html != self.html():
            self.setHtml(html)


            self._html = html
        _apply_base(self, d)
        self.grips.update()

    def apply_theme(self):
        if not self.is_sticky:
            self.setDefaultTextColor(QtGui.QColor(_theme()['note_text']))
        else:
            self.setDefaultTextColor(QtGui.QColor(20, 20, 20))

    def set_bg(self, color):
        self.bg = color
        self.update()

    def set_text_width(self, width):
        self.setTextWidth(width)
        self._after_geometry_change()
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.request_save.emit()

    def _after_geometry_change(self):
        _set_origin_keep_place(self, self.content_rect().center())
        self.grips.update()
        self.update()
        _geometry_changed(self)

    def refresh_render(self):
        pass

        self.prepareGeometryChange()
        self.document().markContentsDirty(0, max(0, self.document().characterCount()))
        mode = self.cacheMode()
        self.setCacheMode(QtWidgets.QGraphicsItem.NoCache)
        self.setCacheMode(mode)
        self._after_geometry_change()


    def _checkbox_block_at(self, pos):
        pass


        doc = self.document()
        layout = doc.documentLayout()
        block = doc.begin()
        while block.isValid():
            if block.blockFormat().marker() != _marker('NoMarker'):
                rect = layout.blockBoundingRect(block)
                if rect.top() - 2 <= pos.y() <= rect.bottom() + 2:
                    text_layout = block.layout()
                    text_x = text_layout.position().x()
                    if text_layout.lineCount():
                        text_x += text_layout.lineAt(0).x()
                    if pos.x() < text_x + 8:
                        return block
                    return None
            block = block.next()
        return None

    def toggle_checkbox(self, block):
        fmt = block.blockFormat()
        fmt.setMarker(_marker('Unchecked') if fmt.marker() == _marker('Checked') else _marker('Checked'))
        QtGui.QTextCursor(block).setBlockFormat(fmt)
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.canvas_changed.emit()

    def anchor_at(self, pos):
        return self.document().documentLayout().anchorAt(pos)

    def linkify(self):
        pass
        doc = self.document()
        for match in _URL_RE.finditer(doc.toPlainText()):
            cursor = QtGui.QTextCursor(doc)
            cursor.setPosition(match.start())
            cursor.setPosition(match.end(), QtGui.QTextCursor.KeepAnchor)
            if cursor.charFormat().isAnchor():
                continue
            url = match.group(0).rstrip('.,;:!?)')
            cursor.setPosition(match.start())
            cursor.setPosition(match.start() + len(url), QtGui.QTextCursor.KeepAnchor)
            fmt = QtGui.QTextCharFormat()
            fmt.setAnchor(True)
            fmt.setAnchorHref(url if url.startswith('http') else 'https://' + url)
            fmt.setForeground(QtGui.QColor('#4dabf7'))
            fmt.setFontUnderline(True)
            cursor.mergeCharFormat(fmt)

    def content_rect(self):
        return QtWidgets.QGraphicsTextItem.boundingRect(self)

    def corner_radius(self):
        return 8 if self.is_code else 0

    def is_node_ref(self):
        return bool(self.houdini_path or self.houdini_abs_path)

    def is_editing(self):
        return self.textInteractionFlags() == QtCore.Qt.TextEditorInteraction

    def _has_hover(self):
        return self.is_sticky or self.is_node_ref()

    def start_editing(self, cursor=None):
        self.setTextInteractionFlags(QtCore.Qt.TextEditorInteraction)

        self.setCacheMode(QtWidgets.QGraphicsItem.NoCache)
        self.grips.set_visible(False)
        scene = self.scene()
        if scene is not None:
            for view in scene.views():
                view.setFocus()
        self.setFocus()
        if cursor is not None:
            self.setTextCursor(cursor)

    def _normalize_code(self):
        pass


        if self._normalizing:
            return
        doc = self.document()
        probe = QtGui.QTextCursor(doc)
        probe.setPosition(min(1, max(0, doc.characterCount() - 1)))
        size = probe.charFormat().fontPointSize()
        if size <= 0:
            size = 12.0
        self._normalizing = True
        try:
            cursor = QtGui.QTextCursor(doc)
            cursor.joinPreviousEditBlock()
            cursor.select(QtGui.QTextCursor.Document)
            fmt = QtGui.QTextCharFormat()
            if hasattr(fmt, 'setFontFamilies'):
                fmt.setFontFamilies(VEX_FONTS)
            else:
                _set_font_family(fmt, VEX_FONTS[-1])
            fmt.setFontFixedPitch(True)
            fmt.setFontPointSize(size)
            fmt.setForeground(QtGui.QColor(VEX_COLORS['default']))
            cursor.setCharFormat(fmt)
            cursor.setBlockCharFormat(fmt)
            block = QtGui.QTextBlockFormat()
            block.setNonBreakableLines(True)
            cursor.setBlockFormat(block)
            cursor.endEditBlock()
        finally:
            self._normalizing = False

    def _on_contents_changed(self):
        if self.is_code and not self._normalizing:
            QtCore.QTimer.singleShot(0, self._normalize_code_safe)
        self._html = None
        old_rect = getattr(self, '_last_scene_rect', None)


        self._after_geometry_change()
        scene = self.scene()
        if isinstance(scene, CanvasScene):


            new_rect = self.sceneBoundingRect()
            scene.update(new_rect.united(old_rect) if old_rect is not None else new_rect)
            self._last_scene_rect = new_rect
            scene.request_save.emit()

    def _remember_font(self):
        pass

        doc = self.document()
        if doc.isEmpty():
            return
        probe = QtGui.QTextCursor(doc)
        probe.setPosition(1 if doc.characterCount() > 1 else 0)
        fmt = probe.charFormat()
        font = QtGui.QFont(self.font())


        has_family = any(fmt.hasProperty(getattr(QtGui.QTextFormat, name))
                         for name in ('FontFamilies', 'FontFamily') if hasattr(QtGui.QTextFormat, name))
        if has_family:
            font.setFamily(fmt.font().family())
        if fmt.fontPointSize() > 0:
            font.setPointSizeF(fmt.fontPointSize())
        if font != self.font():
            self.setFont(font)

    def _paste_plain(self):
        pass

        mime = QtWidgets.QApplication.clipboard().mimeData()
        if mime is None or not mime.hasText():
            return False
        text = mime.text().replace('\r\n', '\n').replace('\r', '\n')
        cursor = self.textCursor()
        cursor.insertText(text)
        self.setTextCursor(cursor)
        return True


    _AUTO_LIST = {'-': 'bullet', '*': 'bullet', '•': 'bullet', '[]': 'check', '[ ]': 'check'}

    def keyPressEvent(self, event):
        if self.is_editing() and not self.is_code and self._auto_list(event):
            event.accept()
            return
        if self.is_editing() and _ctrl_letter(event, 'V', shift=bool(event.modifiers() & QtCore.Qt.ShiftModifier)):
            if self._paste_plain():
                event.accept()
                return
        super().keyPressEvent(event)
        if event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):

            cursor = self.textCursor()
            fmt = cursor.blockFormat()
            if fmt.marker() == _marker('Checked'):
                fmt.setMarker(_marker('Unchecked'))
                cursor.setBlockFormat(fmt)

    def _auto_list(self, event):
        pass
        mods = event.modifiers()
        if mods & (QtCore.Qt.ControlModifier | QtCore.Qt.AltModifier):
            return False
        cursor = self.textCursor()
        if cursor.hasSelection():
            return False
        block = cursor.block()
        if event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):

            lst = block.textList()
            if lst is not None and not block.text().strip():
                lst.remove(block)
                fmt = cursor.blockFormat()
                fmt.setIndent(0)
                fmt.setMarker(_marker('NoMarker'))
                cursor.setBlockFormat(fmt)
                return True
            return False
        if event.key() != QtCore.Qt.Key_Space or block.textList() is not None:
            return False
        prefix = block.text()[:cursor.positionInBlock()]
        kind = self._AUTO_LIST.get(prefix)
        if kind is None and re.fullmatch(r'\d{1,3}[.)]', prefix):
            kind = 'number'
        if kind is None:
            return False
        cursor.beginEditBlock()
        cursor.movePosition(QtGui.QTextCursor.StartOfBlock, QtGui.QTextCursor.KeepAnchor)
        cursor.removeSelectedText()
        list_format = QtGui.QTextListFormat()
        list_format.setStyle(QtGui.QTextListFormat.ListDecimal if kind == 'number' else QtGui.QTextListFormat.ListDisc)
        list_format.setIndent(1)
        cursor.createList(list_format)
        fmt = cursor.blockFormat()
        fmt.setMarker(_marker('Unchecked') if kind == 'check' else _marker('NoMarker'))
        cursor.setBlockFormat(fmt)
        cursor.endEditBlock()
        self.setTextCursor(cursor)
        return True

    def _normalize_code_safe(self):
        try:
            self._normalize_code()
        except RuntimeError:
            pass

    def hoverEnterEvent(self, event):
        if self._has_hover() and not self.is_editing():
            self.hover.enter()
        super().hoverEnterEvent(event)

    def hoverMoveEvent(self, event):

        if not self.is_editing() and (self.anchor_at(event.pos()) or self._checkbox_block_at(event.pos()) is not None):
            self.setCursor(QtCore.Qt.PointingHandCursor)
        else:
            self.unsetCursor()
        super().hoverMoveEvent(event)

    def hoverLeaveEvent(self, event):
        if self._has_hover():
            self.hover.leave()
        self.unsetCursor()
        super().hoverLeaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            block = self._checkbox_block_at(event.pos())
            if block is not None:
                self.toggle_checkbox(block)
                event.accept()
                return
        self.hover.suspend()
        self._press_screen = event.screenPos()
        if not self.is_editing():
            self.last_selection = None
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)

        if (event.button() == QtCore.Qt.LeftButton and not self.is_editing() and self._press_screen is not None
                and QtCore.QLineF(QtCore.QPointF(self._press_screen), QtCore.QPointF(event.screenPos())).length() < 4):
            href = self.anchor_at(event.pos())
            if href:
                QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromUserInput(href))
        self._press_screen = None
        if self._has_hover() and not self.is_editing():
            self.hover.resume()

    def boundingRect(self):
        rect = super().boundingRect()
        if self.is_sticky or self.is_code:
            return rect.adjusted(-5, -5, 5, 5)
        return rect.adjusted(-2, -2, 2, 2)

    _FONT_PT_RE = re.compile(r'font-size:\s*([\d.]+)pt')

    def _max_font_px(self):
        pass
        html = self.html()
        if getattr(self, '_font_px_html', None) is not html:
            sizes = [float(s) for s in self._FONT_PT_RE.findall(html)]
            default = self.document().defaultFont().pointSizeF()
            self._font_px = max(sizes + [default if default > 0 else 12.0]) * 1.333
            self._font_px_html = html
        return self._font_px

    def paint(self, painter, option, widget):
        rect = super().boundingRect()
        if self.is_sticky:
            bg_color = QtGui.QColor(self.bg or ("#00b894" if self.is_node_ref() else STICKY_COLORS[0]))
            painter.setBrush(bg_color)
            painter.setPen(QtCore.Qt.NoPen)
            painter.drawRect(rect)

        lod =QtWidgets.QStyleOptionGraphicsItem.levelOfDetailFromTransform(painter.worldTransform())
        views = self.scene().views() if self.scene() is not None else []


        on_gpu = any(getattr(v, '_gpu', False) for v in views)
        if not on_gpu and not self.is_editing() and lod * self._max_font_px() < TEXT_LOD_MIN_PX:

            color = QtGui.QColor(self.defaultTextColor())
            color.setAlpha(55)
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(color)
            painter.drawRect(rect.adjusted(6, 6, -6, -6))
            return
        super().paint(painter, option, widget)

    def mouseDoubleClickEvent(self, event):
        if self.is_node_ref():
            scene = self.scene()
            node = scene.resolve_houdini_node(self.houdini_path, self.houdini_abs_path) if isinstance(scene, CanvasScene) else None
            if node is not None:
                _focus_network_editor(node)
            return
        if not self.is_editing():
            self.hover.suspend()
            self.start_editing()
        super().mouseDoubleClickEvent(event)

    def focusOutEvent(self, event):
        cursor = self.textCursor()


        self.last_selection = (cursor.anchor(), cursor.position()) if cursor.hasSelection() else None
        self.setTextInteractionFlags(QtCore.Qt.NoTextInteraction)
        cursor.clearSelection()
        self.setTextCursor(cursor)
        self.setCacheMode(QtWidgets.QGraphicsItem.DeviceCoordinateCache)
        for view in (self.scene().views() if self.scene() is not None else []):
            if hasattr(view, 'rest_cache'):
                view.rest_cache(self)
        super().focusOutEvent(event)
        if not self.is_code:
            self.linkify()
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.refresh_selection_ui()
            scene.canvas_changed.emit()

    def itemChange(self, change, value):
        value = _snap_position(self, change, value)
        if change == QtWidgets.QGraphicsItem.ItemSelectedHasChanged:
            if not self.isSelected():
                self.last_selection = None
        elif change in _GEOMETRY_CHANGES:
            _geometry_changed(self)
        return super().itemChange(change, value)
