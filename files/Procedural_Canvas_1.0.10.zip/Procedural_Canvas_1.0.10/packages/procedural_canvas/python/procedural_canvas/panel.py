pass

from ._link import pull
pull(globals())




class CanvasPanel(QtWidgets.QWidget):
    pass




    def __init__(self):
        super().__init__()
        self.editor = None
        self.node = None
        self._failed_session = None
        self.setStyleSheet(_style("background: %(canvas)s;"))
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.placeholder = QtWidgets.QLabel()
        self.placeholder.setAlignment(QtCore.Qt.AlignCenter)
        self.placeholder.setWordWrap(True)
        self.placeholder.setStyleSheet(_style("color: %(dim)s; font-size: 14px; padding: 30px;"))
        layout.addWidget(self.placeholder)
        self._set_placeholder('Select a node with a canvas to see its board here.')
        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(400)
        self._timer.timeout.connect(self._sync)
        self._timer.start()
        self._sync()

    @staticmethod
    def _is_canvas_node(node):
        try:
            return node.type().definition() is not None and node.parm(PARM_NAME) is not None
        except hou.Error:
            return False

    def _set_placeholder(self, text):
        self.placeholder.setText(text)
        self.placeholder.show()

    def _sync(self):
        try:
            node = next((n for n in hou.selectedNodes() if self._is_canvas_node(n)), None)
        except hou.Error:
            return
        if node is None:
            if self.editor is not None or self.node is None:
                return

            try:
                self.node.sessionId()
            except hou.ObjectWasDeleted:
                self.node = None
                return
            node = self.node
        if self.node is not None and node.sessionId() == self.node.sessionId() \
                and (self.editor is not None or self._failed_session == node.sessionId()):
            return
        self.show_node(node)

    def show_node(self, node):
        key = node.sessionId()
        other = _CANVAS_WINDOWS.get(key)
        if other is not None and other is not self.editor:
            try:
                separate = not other.embedded
            except RuntimeError:
                separate = None
            if separate:
                self._release_editor()
                self.node = node
                self._set_placeholder('"%s" is open in a separate window.\nClose it or press %s there to dock it here.'
                                      % (node.name(), '📌' if EMOJI_OK else 'Dock'))
                return
            if separate is False:



                try:
                    other.shutdown()
                except RuntimeError:
                    pass
            _CANVAS_WINDOWS.pop(key, None)
        self._release_editor()
        self.node = node
        try:
            editor = MiroCanvasWindow(node, embedded=True)
        except LicenseRequired:
            self._set_placeholder('Enter the license key to open the board (click Open Canvas on the node).')
            self._failed_session = key
            return
        except Exception:

            _log_error('Could not open the board of "%s" in the panel' % node.name())
            self._set_placeholder('Could not open the board of "%s".\nSee the Python console and the error log.' % node.name())
            self._failed_session = key
            return
        self._failed_session = None
        editor.on_shutdown = self._on_editor_shutdown
        _CANVAS_WINDOWS[key] = editor
        self.layout().addWidget(editor)
        self.placeholder.hide()
        self.editor = editor

    def _release_editor(self):
        editor, self.editor = self.editor, None
        if editor is not None:
            editor.on_shutdown = None
            editor.shutdown()
            editor.hide()
            editor.setParent(None)
            editor.deleteLater()

    def _on_editor_shutdown(self, editor):

        if editor is self.editor:
            self.editor = None
            self._set_placeholder('This board is no longer shown here. Select a node with a canvas.')
            QtCore.QTimer.singleShot(0, lambda: (editor.hide(), editor.setParent(None), editor.deleteLater()))

    def shutdown(self):
        self._timer.stop()
        self._release_editor()


def _panel_file():
    folder = os.path.join(hou.getenv('HOUDINI_USER_PREF_DIR') or hou.homeHoudiniDirectory(), 'python_panels')
    os.makedirs(folder, exist_ok=True)
    old = os.path.join(folder, 'project_canvas.pypanel')
    if os.path.exists(old):
        try:
            os.remove(old)
        except OSError:
            pass
    return os.path.join(folder, 'procedural_canvas.pypanel')


def install_panel():
    pass
    path = _panel_file()
    content = _PANEL_XML
    try:
        with open(path, 'r', encoding='utf-8') as f:
            current = f.read()
    except OSError:
        current = None
    if current != content:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
    hou.pypanel.installFile(path)
    return hou.pypanel.interfaceByName(PANEL_NAME)


def open_panel(node):
    pass
    try:
        interface = install_panel()
    except Exception:
        _log_error('Could not install the Procedural Canvas panel')
        return

    editor = _CANVAS_WINDOWS.get(node.sessionId())
    if editor is not None:
        try:
            if not editor.embedded:
                editor.close()
        except RuntimeError:
            _CANVAS_WINDOWS.pop(node.sessionId(), None)
    node.setSelected(True, clear_all_selected=True)

    for tab in hou.ui.paneTabs():
        if tab.type() == hou.paneTabType.PythonPanel:
            active = tab.activeInterface()
            if active is not None and active.name() == PANEL_NAME:
                tab.setIsCurrentTab()
                return
    anchor = hou.ui.paneTabOfType(hou.paneTabType.Parm) or hou.ui.paneTabOfType(hou.paneTabType.NetworkEditor)
    if anchor is None:
        hou.ui.displayMessage('Could not find a pane to dock the canvas into.')
        return
    tab = anchor.pane().createTab(hou.paneTabType.PythonPanel)
    tab.setActiveInterface(interface)
    try:
        tab.showToolbar(False)
    except (hou.Error, AttributeError):
        pass
    tab.setIsCurrentTab()


def _close_panel_tabs():
    pass

    for tab in hou.ui.paneTabs():
        try:
            if tab.type() != hou.paneTabType.PythonPanel:
                continue
            active = tab.activeInterface()
            if active is not None and active.name() == PANEL_NAME:
                tab.close()
        except (hou.Error, AttributeError):
            pass


def launch(node):
    ensure_loader_hda()
    key = node.sessionId()
    editor = _CANVAS_WINDOWS.get(key)
    if editor is not None:
        try:
            if editor.embedded:
                editor.request_close()

                QtCore.QTimer.singleShot(0, _close_panel_tabs)
            else:
                if editor.isMinimized():
                    editor.showNormal()
                editor.show()
                editor.raise_()
                editor.activateWindow()
                return
        except RuntimeError:
            pass
        _CANVAS_WINDOWS.pop(key, None)

    try:
        win = MiroCanvasWindow(node)
    except LicenseRequired:
        return
    _CANVAS_WINDOWS[key] = win
    win.show()










NODE_TYPE = 'Klym::procedural_canvas::1.0'
NODE_LABEL = 'Procedural Canvas'
LOADER_REVISION = 4
OLD_NODE_TYPES = ('Klim::procedural_canvas::1.1', 'Klim::procedural_canvas::1.0')
LOADER_CALLBACK = "import procedural_canvas; procedural_canvas.launch(kwargs['node'])"
LOADER_PYTHON_MODULE = '''# Procedural Canvas: the code lives in the Houdini package (packages/procedural_canvas.json).
# This node is only a loader: the Open Canvas button and the canvas_data parameter with the board.
try:
    from procedural_canvas import *  # noqa: F401,F403
except ImportError:
    import hou
    hou.ui.setStatusMessage('Procedural Canvas is not installed: add packages/procedural_canvas.json and restart Houdini.',
                            severity=hou.severityType.Error)
'''

LOADER_TOOLS_SHELF = '''<?xml version="1.0" encoding="UTF-8"?>
<shelfDocument>
  <tool name="$HDA_DEFAULT_TOOL" label="$HDA_LABEL" icon="$HDA_ICON">
    <script scriptType="python"><![CDATA[import procedural_canvas
procedural_canvas.create_canvas_tool(kwargs)]]></script>
  </tool>
</shelfDocument>
'''


def node_type():
    return hou.nodeType(hou.sopNodeTypeCategory(), NODE_TYPE)


def loader_hda_path():
    pass
    try:
        category = hou.licenseCategory().name()
    except (hou.Error, AttributeError):
        category = 'Indie'
    extension = {'Commercial': '.hda', 'Indie': '.hdalc'}.get(category, '.hdanc')
    folder = os.path.join(hou.getenv('HOUDINI_USER_PREF_DIR') or hou.homeHoudiniDirectory(), 'otls')
    return os.path.join(folder, 'sop_Klym.procedural_canvas.1.0' + extension)


def _package_icon():
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                        'icons', 'procedural_canvas.pic')
    try:
        with open(path, 'rb') as f:
            return f.read()
    except OSError:
        return None


def build_loader_hda(path):
    pass
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with hou.undos.disabler():
        geo = hou.node('/obj').createNode('geo', 'procedural_canvas_loader_build', run_init_scripts=False)
        try:
            sub = geo.createNode('subnet', 'procedural_canvas')
            node = sub.createDigitalAsset(name=NODE_TYPE, hda_file_name=path, description=NODE_LABEL,
                                          min_num_inputs=0, max_num_inputs=0)
            d = node.type().definition()
            ptg = hou.ParmTemplateGroup()
            ptg.append(hou.ButtonParmTemplate('Open_Canvas', 'Open Canvas', script_callback=LOADER_CALLBACK,
                                              script_callback_language=hou.scriptLanguage.Python,
                                              help='Open the board in a separate window'))
            data = hou.StringParmTemplate('canvas_data', 'canvas_data', 1, is_hidden=True)
            data.setTags({'editor': '1'})
            ptg.append(data)
            d.setParmTemplateGroup(ptg)
            d.addSection('PythonModule', LOADER_PYTHON_MODULE)
            d.setExtraFileOption('PythonModule/IsPython', True)
            d.setExtraFileOption('PythonModule/IsScript', False)
            d.setExtraFileOption('PythonModule/IsExpr', False)
            d.setExtraFileOption('PythonModule/Source', '')
            icon = _package_icon()
            if icon:
                d.addSection('IconImage', icon)
                d.setIcon('opdef:.?IconImage')
            d.addSection('Tools.shelf', LOADER_TOOLS_SHELF)
            d.setComment('Procedural Canvas loader, built on this computer')
            d.setVersion(str(LOADER_REVISION))
            d.save(path, node)
        finally:
            geo.destroy()
    backup = os.path.join(os.path.dirname(path), 'backup')
    if os.path.isdir(backup):
        for name in os.listdir(backup):
            if name.startswith('sop_Klym.procedural_canvas'):
                try:
                    os.remove(os.path.join(backup, name))
                except OSError:
                    pass
    return path


def refresh_loader_hda():
    pass

    t = node_type()
    d = t.definition() if t is not None else None
    if d is None:
        return
    icon = _package_icon()
    try:
        current_icon = d.sections()['IconImage'].binaryContents() if 'IconImage' in d.sections() else None
    except hou.Error:
        current_icon = None

    if d.version() == str(LOADER_REVISION) and (not icon or icon == current_icon):
        return
    try:
        if icon and icon != current_icon:
            d.addSection('IconImage', icon)
            d.setIcon('opdef:.?IconImage')
        d.addSection('PythonModule', LOADER_PYTHON_MODULE)
        d.addSection('Tools.shelf', LOADER_TOOLS_SHELF)
        d.setVersion(str(LOADER_REVISION))
        _log_info('Updated the %s node to revision %d' % (NODE_LABEL, LOADER_REVISION))
    except hou.Error:
        _log_error('Could not update the %s node' % NODE_LABEL)


def ensure_loader_hda():
    pass

    if node_type() is not None:
        refresh_loader_hda()
        return True
    path = loader_hda_path()
    try:
        if not os.path.exists(path):
            build_loader_hda(path)
            _log_info('Built the node %s in %s' % (NODE_TYPE, path))
        hou.hda.installFile(path)
    except Exception:
        _log_error('Could not build the %s node' % NODE_LABEL)
        return False
    return node_type() is not None


def create_canvas_tool(kwargs):
    pass
    if not ensure_loader_hda():
        hou.ui.displayMessage('Could not create the %s node. Details are in the error log (Settings > About).' % NODE_LABEL,
                              severity=hou.severityType.Error)
        return None
    import soptoolutils
    return soptoolutils.genericTool(kwargs, NODE_TYPE)





def upgrade_old_nodes():
    pass



    ensure_loader_hda()
    upgraded = []
    for node in hou.node('/').allSubChildren():
        try:
            if node.type().name() not in OLD_NODE_TYPES:
                continue
        except hou.Error:
            continue
        editor = _CANVAS_WINDOWS.get(node.sessionId())
        if editor is not None:
            try:
                editor.request_close()
            except RuntimeError:
                pass
        new = node.changeNodeType(NODE_TYPE, keep_name=True, keep_parms=True, keep_network_contents=False)
        upgraded.append(new.path())
    return upgraded
