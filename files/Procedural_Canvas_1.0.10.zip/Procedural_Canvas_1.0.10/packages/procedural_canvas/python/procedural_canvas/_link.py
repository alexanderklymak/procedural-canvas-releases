pass










import sys

ORDER = ('core', 'items_base', 'text', 'images', 'youtube', 'shapes', 'scene', 'widgets', 'licensing', 'view', 'window', 'panel')
PACKAGE = __name__.rpartition('.')[0]


def _modules():
    return [sys.modules[PACKAGE + '.' + name] for name in ORDER if PACKAGE + '.' + name in sys.modules]


def _public(module):
    return {k: v for k, v in vars(module).items() if not k.startswith('__') and k != 'pull'}


def pull(namespace):
    for module in _modules():
        if vars(module) is namespace:
            continue
        for key, value in _public(module).items():
            namespace.setdefault(key, value)


def finish():
    pass


    modules = _modules()
    for module in modules:
        own = vars(module)
        for other in modules:
            if other is module:
                continue
            for key, value in _public(other).items():
                if key in own and own[key] is not value:
                    raise ImportError('%s is defined in both %s and %s' % (key, module.__name__, other.__name__))
                own.setdefault(key, value)


def export(namespace):
    pass

    names = []
    for module in _modules():
        for key, value in _public(module).items():
            if key not in ORDER:
                namespace[key] = value
                names.append(key)
    namespace['__all__'] = sorted(set(names))
