pass

from ._link import pull
pull(globals())




class PathNode(QtWidgets.QGraphicsPathItem):
    TYPE = 'path'

    def __init__(self, path, color="#ff4757", width=3, x=0, y=0, is_highlighter=False, uid=None, dash='solid',
                 brush='smooth', alpha=None):
        super().__init__()
        self.uid = uid or _new_id()
        self.alpha = HIGHLIGHTER_ALPHA if alpha is None else alpha
        self.color_hex = color
        self.pen_width = width
        self.dash = dash
        self.is_highlighter = is_highlighter
        self.brush = brush if brush in BRUSH_STYLES else 'smooth'
        self.hover = _NO_HOVER
        self._elems = None
        self._shape = None
        self._lod_paths = {}
        self._outlines = {}
        self._apply_pen()
        self.setPath(path)
        self.setPos(x, y)
        self.setFlags(QtWidgets.QGraphicsItem.ItemIsSelectable | QtWidgets.QGraphicsItem.ItemIsMovable | QtWidgets.QGraphicsItem.ItemSendsGeometryChanges)

    @classmethod
    def from_dict(cls, d, scene):
        path = elems_to_path(d.get('elems', []))
        if path.elementCount() > PATH_SIMPLIFY_MIN_ELEMS:


            path = _simplify_path(path, 0.3)
        item = cls(path, color=d.get('color', '#ff4757'), width=d.get('width', 3),
                   is_highlighter=d.get('hi', False), uid=d.get('id'), dash=d.get('dash', 'solid'),
                   brush=d.get('brush', 'smooth'), alpha=d.get('alpha'))
        _apply_base(item, d)
        return item

    @staticmethod
    def _lod_key(lod):
        pass
        if lod >= 0.7:
            return 0
        return min(8, int(math.ceil(math.log(1.0 / max(lod, 1e-6), 2))))

    def _display_path(self, key):
        pass
        if key == 0:
            return self.path()
        path = self._lod_paths.get(key)
        if path is None:
            path = self._lod_paths[key] = _simplify_path(self.path(), 0.5 * (2 ** key))
        return path

    def _outline(self, key, width_mult=1.0):
        pass


        cache_key = key if width_mult == 1.0 else (key, width_mult)
        outline = self._outlines.get(cache_key)
        if outline is not None:
            return outline
        if width_mult == 1.0 and self.brush in ('ink', 'calligraphy') and not self.is_highlighter:
            outline = _ribbon_path(self._display_path(key), self.pen_width, self.brush)
        else:
            pen = self.pen()
            stroker = QtGui.QPainterPathStroker()
            stroker.setWidth(max(pen.widthF() * width_mult, 0.5))
            stroker.setCapStyle(pen.capStyle())
            stroker.setJoinStyle(pen.joinStyle())
            if width_mult == 1.0 and pen.style() == QtCore.Qt.CustomDashLine:
                stroker.setDashPattern(pen.dashPattern())
            outline = stroker.createStroke(self._display_path(key))
        self._outlines[cache_key] = outline
        return outline

    def paint(self, painter, option, widget=None):
        lod = QtWidgets.QStyleOptionGraphicsItem.levelOfDetailFromTransform(painter.worldTransform())
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        key = self._lod_key(lod)
        color = self.pen().color()
        style = 'smooth' if self.is_highlighter else self.brush
        if style == 'neon':


            painter.setPen(QtCore.Qt.NoPen)
            for mult, alpha in ((3.4, 30), (2.0, 65)):
                glow = QtGui.QColor(color)
                glow.setAlpha(alpha)
                painter.setBrush(glow)
                painter.drawPath(self._outline(key, mult))
            painter.setBrush(color.lighter(165))
        elif style == 'chalk':

            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(QtGui.QBrush(_chalk_texture(self.color_hex)))
        else:
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(color)
        painter.drawPath(self._outline(key))
        _draw_selection_rect(painter, option, self.boundingRect())

    def boundingRect(self):
        rect = super().boundingRect()
        if self.brush == 'neon' and not self.is_highlighter:
            m = self.pen_width * 1.8
            rect = rect.adjusted(-m, -m, m, m)
        return rect

    def _apply_pen(self):
        alpha = int(255 * self.alpha / 100.0) if self.is_highlighter else None
        self.setPen(_make_pen(self.color_hex, self.pen_width, self.dash, alpha))
        self._outlines = {}

    def set_style(self, color=None, width=None, dash=None, brush=None, alpha=None):
        self.prepareGeometryChange()
        if alpha is not None:
            self.alpha = alpha
        if color is not None:
            self.color_hex = color
        if width is not None:
            self.pen_width = width * (5 if self.is_highlighter else 1)
        if dash is not None:
            self.dash = dash
        if brush is not None and brush in BRUSH_STYLES:
            self.brush = brush
        self._apply_pen()
        self._shape = None
        self.update()

    def set_path(self, path):
        self.setPath(path)
        self._elems = None
        self._shape = None
        self._lod_paths = {}
        self._outlines = {}

    def elems(self):
        if self._elems is None:
            self._elems = path_to_elems(self.path())
        return self._elems

    def to_dict(self):
        d = _base_dict(self)
        d.update(elems=self.elems(), color=self.color_hex, width=self.pen_width, hi=self.is_highlighter)
        if self.dash != 'solid':
            d['dash'] = self.dash
        if self.brush != 'smooth':
            d['brush'] = self.brush
        if self.is_highlighter and self.alpha != HIGHLIGHTER_ALPHA:
            d['alpha'] = self.alpha
        return d

    def apply_dict(self, d):
        _apply_base(self, d)
        if (d.get('color'), d.get('width'), d.get('dash', 'solid'), d.get('brush', 'smooth'),
                d.get('alpha', HIGHLIGHTER_ALPHA)) != (self.color_hex, self.pen_width, self.dash, self.brush, self.alpha):
            self.prepareGeometryChange()
            self.color_hex, self.pen_width, self.dash = d.get('color', '#ff4757'), d.get('width', 3), d.get('dash', 'solid')
            self.brush = d.get('brush', 'smooth')
            self.alpha = d.get('alpha', HIGHLIGHTER_ALPHA)
            self._apply_pen()
            self._shape = None
        elems = d.get('elems', [])
        if elems != self.elems():
            self.set_path(elems_to_path(elems))

    def erase_at(self, scene_pos, radius):
        pass

        local = self.mapFromScene(scene_pos)
        r = radius / max(1e-6, self.scale()) + self.pen_width / 2.0
        if not self.path().boundingRect().adjusted(-r, -r, r, r).contains(local):
            return True
        step = max(1.0, r / 2.0)
        pieces, changed = [], False
        for poly in self.path().toSubpathPolygons():
            pts = [QtCore.QPointF(p) for p in poly]
            dense = []
            for a, b in zip(pts, pts[1:]):
                n = max(1, int(QtCore.QLineF(a, b).length() / step))
                dense.extend(a + (b - a) * (k / float(n)) for k in range(n))
            if pts:
                dense.append(pts[-1])
            current = []
            for p in dense:
                if QtCore.QLineF(p, local).length() <= r:
                    changed = True
                    if len(current) >= 2:
                        pieces.append(current)
                    current = []
                else:
                    current.append(p)
            if len(current) >= 2:
                pieces.append(current)
        if not changed:
            return True
        if not pieces:
            return False
        path = QtGui.QPainterPath()
        for piece in pieces:
            path.moveTo(piece[0])
            last = piece[0]
            for p in piece[1:-1]:
                if QtCore.QLineF(last, p).length() >= 2.0:
                    path.lineTo(p)
                    last = p
            path.lineTo(piece[-1])
        self.set_path(path)
        return True

    def shape(self):
        if self._shape is None:
            self._shape = _stroke_shape(self.path(), self.pen_width)
        return self._shape

    def itemChange(self, change, value):
        value = _snap_position(self, change, value)
        if change in _GEOMETRY_CHANGES:
            _geometry_changed(self)
        return super().itemChange(change, value)


class ShapeNode(QtWidgets.QGraphicsItem):
    TYPE = 'shape'

    def __init__(self, shape_type, rect, color="#ff4757", width=3, uid=None, dash='solid', fill=None, fill_alpha=100,
                 points=None):
        super().__init__()
        self.uid = uid or _new_id()
        self.shape_type = shape_type
        self.geom_rect = rect

        self.points = [QtCore.QPointF(x, y) for x, y in (points or [])]
        self._drag_point = None
        self.color_hex = color
        self.pen_width = width
        self.dash = dash
        self.fill = fill
        self.fill_alpha = fill_alpha
        self.links = []
        self.hover = _NO_HOVER
        self._shape = None
        self.setFlags(QtWidgets.QGraphicsItem.ItemIsSelectable | QtWidgets.QGraphicsItem.ItemIsMovable | QtWidgets.QGraphicsItem.ItemSendsGeometryChanges)
        self.pen = _make_pen(color, width, dash)
        self.setTransformOriginPoint(rect.normalized().center())

        self.grips = ArrowGrips(self) if shape_type == 'arrow' else ItemGrips(self, rotate=True)

    @classmethod
    def from_dict(cls, d, scene):
        r = d['rect']
        item = cls(d['stype'], QtCore.QRectF(r[0], r[1], r[2], r[3]), color=d.get('color', '#ff4757'),
                   width=d.get('width', 3), uid=d.get('id'), dash=d.get('dash', 'solid'),
                   fill=d.get('fill'), fill_alpha=d.get('fill_alpha', 100), points=d.get('pts'))
        _apply_base(item, d)
        return item

    def to_dict(self):
        d = _base_dict(self)
        r = self.geom_rect
        d.update(stype=self.shape_type, rect=[r.x(), r.y(), r.width(), r.height()], color=self.color_hex, width=self.pen_width)
        if self.dash != 'solid':
            d['dash'] = self.dash
        if self.fill:
            d['fill'] = self.fill
            d['fill_alpha'] = self.fill_alpha
        if self.points:
            d['pts'] = [[round(p.x(), 2), round(p.y(), 2)] for p in self.points]
        return d

    def apply_dict(self, d):
        r = d['rect']
        points = [QtCore.QPointF(x, y) for x, y in (d.get('pts') or [])]
        if points != self.points:
            self.prepareGeometryChange()
            self.points = points
        self.set_rect(QtCore.QRectF(r[0], r[1], r[2], r[3]))
        self.set_style(color=d.get('color', '#ff4757'), width=d.get('width', 3), dash=d.get('dash', 'solid'),
                       fill=d.get('fill'), fill_alpha=d.get('fill_alpha', 100))
        _apply_base(self, d)

    _KEEP = object()

    def set_style(self, color=None, width=None, dash=None, fill=_KEEP, fill_alpha=None):
        self.prepareGeometryChange()
        if color is not None:
            self.color_hex = color
        if width is not None:
            self.pen_width = width
        if dash is not None:
            self.dash = dash
        if fill is not ShapeNode._KEEP:
            self.fill = fill
        if fill_alpha is not None:
            self.fill_alpha = fill_alpha
        self.pen = _make_pen(self.color_hex, self.pen_width, self.dash)
        self._shape = None
        self.grips.update()
        self.update()

    def grip_rect(self):
        return self.geom_rect.normalized()

    def set_rect(self, rect):
        self.prepareGeometryChange()
        self.geom_rect = rect
        self._shape = None
        if self.rotation() == 0 and self.scale() == 1:
            self.setTransformOriginPoint(rect.normalized().center())
        if hasattr(self, 'grips'):
            self.grips.update()
        _geometry_changed(self)

    def _arrow_len(self):
        return max(14.0, self.pen_width * 3.2)

    def _arrow_path(self):
        pass
        return _smooth_through([self.geom_rect.topLeft()] + self.points + [self.geom_rect.bottomRight()])

    def _arrow_head(self):
        p2 = self.geom_rect.bottomRight()
        arrow_len = self._arrow_len()
        if self.points:
            path = self._arrow_path()
            length = path.length()
            p1 = path.pointAtPercent(path.percentAtLength(max(0.0, length - arrow_len * 0.6)))
        else:
            p1 = self.geom_rect.topLeft()
        angle = math.atan2(p2.y() - p1.y(), p2.x() - p1.x())
        ap1 = p2 - QtCore.QPointF(math.cos(angle + math.pi / 7) * arrow_len, math.sin(angle + math.pi / 7) * arrow_len)
        ap2 = p2 - QtCore.QPointF(math.cos(angle - math.pi / 7) * arrow_len, math.sin(angle - math.pi / 7) * arrow_len)
        return QtGui.QPolygonF([p2, ap1, ap2])

    def _arrow_shaft_end(self):
        pass
        p1, p2 = self.geom_rect.topLeft(), self.geom_rect.bottomRight()
        length = QtCore.QLineF(p1, p2).length()
        cut = self._arrow_len() * 0.75
        if length <= cut:
            return p1
        return p2 + (p1 - p2) * (cut / length)

    def boundingRect(self):
        r = self.geom_rect.normalized()
        if self.points:
            r = r.united(self._arrow_path().boundingRect())
        padding = self.pen_width + 30
        return r.adjusted(-padding, -padding, padding, padding)

    def shape(self):

        if self._shape is None:
            outline = QtGui.QPainterPath()
            if self.shape_type == 'rect':
                outline.addRect(self.geom_rect.normalized())
            elif self.shape_type == 'ellipse':
                outline.addEllipse(self.geom_rect.normalized())
            else:
                outline = self._arrow_path()
            shape = _stroke_shape(outline, self.pen_width)
            if self.shape_type == 'arrow':
                shape.addPolygon(self._arrow_head())
                shape.closeSubpath()
            elif self.fill:
                shape = shape.united(outline)
            self._shape = shape
        if self.shape_type != 'arrow' or not self.isSelected():
            return self._shape
        shape = QtGui.QPainterPath(self._shape)
        r = 10.0 / _view_lod(self)
        for p in self.points + self._arrow_mids():
            shape.addEllipse(p, r, r)
        return shape


    def _arrow_mids(self):
        pass
        if self.points:
            return []
        return _path_mids(self._arrow_path())

    def _point_at(self, pos):
        if self.shape_type != 'arrow' or not self.isSelected():
            return None
        r = 10.0 / _view_lod(self)
        candidates = [(QtCore.QLineF(p, pos).length(), ('point', i)) for i, p in enumerate(self.points)]
        candidates += [(QtCore.QLineF(p, pos).length(), ('mid', i)) for i, p in enumerate(self._arrow_mids())]
        candidates = [c for c in candidates if c[0] <= r]
        return min(candidates, key=lambda c: c[0])[1] if candidates else None

    def _set_points(self, points):


        self.prepareGeometryChange()
        self.points = points
        self._shape = None
        self.update()

    def mousePressEvent(self, event):
        hit = self._point_at(event.pos()) if event.button() == QtCore.Qt.LeftButton else None
        if hit is None:
            super().mousePressEvent(event)
            return
        kind, index = hit
        if kind == 'mid':
            self._set_points([QtCore.QPointF(event.pos())])
            index = 0
        self._drag_point = index
        event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_point is None:
            super().mouseMoveEvent(event)
            return
        point = event.scenePos()
        scene = self.scene()
        if isinstance(scene, CanvasScene) and scene.snap_to_grid:
            g = SETTINGS['grid_size']
            point = QtCore.QPointF(round(point.x() / g) * g, round(point.y() / g) * g)
        points = list(self.points)
        points[self._drag_point] = self.mapFromScene(point)
        self._set_points(points)
        event.accept()

    def mouseReleaseEvent(self, event):
        if self._drag_point is None:
            super().mouseReleaseEvent(event)
            return
        self._drag_point = None
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.canvas_changed.emit()
        event.accept()

    def mouseDoubleClickEvent(self, event):
        hit = self._point_at(event.pos())
        if hit is not None and hit[0] == 'point':
            self._set_points([p for i, p in enumerate(self.points) if i != hit[1]])
            scene = self.scene()
            if isinstance(scene, CanvasScene):
                scene.canvas_changed.emit()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def _fill_brush(self):
        if not self.fill or self.shape_type == 'arrow':
            return QtGui.QBrush(QtCore.Qt.NoBrush)
        color = QtGui.QColor(self.fill)
        color.setAlpha(int(255 * self.fill_alpha / 100.0))
        return QtGui.QBrush(color)

    def paint(self, painter, option, widget):
        painter.setPen(self.pen)
        painter.setBrush(self._fill_brush())
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        if self.shape_type == 'rect':
            painter.drawRect(self.geom_rect)
        elif self.shape_type == 'ellipse':
            painter.drawEllipse(self.geom_rect)
        elif self.shape_type == 'arrow':
            if self.points:
                painter.setBrush(QtCore.Qt.NoBrush)
                painter.drawPath(_trimmed_path(self._arrow_path(), 0.0, self._arrow_len() * 0.75))
            else:
                painter.drawLine(self.geom_rect.topLeft(), self._arrow_shaft_end())
            painter.setPen(QtGui.QPen(QtGui.QColor(self.color_hex), 1, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin))
            painter.setBrush(QtGui.QBrush(QtGui.QColor(self.color_hex)))
            painter.drawPolygon(self._arrow_head())
            if self.isSelected():
                lod = QtWidgets.QStyleOptionGraphicsItem.levelOfDetailFromTransform(painter.worldTransform())
                _draw_point_handles(painter, self.points, self._arrow_mids(), lod)

    def itemChange(self, change, value):
        value = _snap_position(self, change, value)
        if change in _GEOMETRY_CHANGES:
            _geometry_changed(self)
        return super().itemChange(change, value)


class ArrowEndHandle(QtWidgets.QGraphicsEllipseItem):
    pass

    def __init__(self, arrow, role):
        super().__init__(arrow)
        self.role = role
        size = HANDLE_SIZE
        self.setRect(-size / 2, -size / 2, size, size)
        self.setBrush(QtGui.QBrush(QtGui.QColor(*GLOW_COLOR)))
        self.setPen(QtGui.QPen(QtCore.Qt.white, 2))
        self.setZValue(10)
        self.setFlag(QtWidgets.QGraphicsItem.ItemIgnoresTransformations)
        self.setCursor(QtCore.Qt.SizeAllCursor)

    def mousePressEvent(self, event):
        event.accept()

    def mouseMoveEvent(self, event):
        arrow = self.parentItem()
        point = event.scenePos()
        view = _first_view(self)
        if view is not None:
            point = view.snap_point(point, view._snap_exclude(arrow))
        p = arrow.mapFromScene(point)
        r = arrow.geom_rect
        fixed = r.bottomRight() if self.role == 'start' else r.topLeft()
        if event.modifiers() & QtCore.Qt.ShiftModifier:
            line = QtCore.QLineF(fixed, p)
            line.setAngle(round(line.angle() / 45.0) * 45.0)
            p = line.p2()
        arrow.set_rect(QtCore.QRectF(p, fixed) if self.role == 'start' else QtCore.QRectF(fixed, p))
        event.accept()

    def mouseReleaseEvent(self, event):
        view = _first_view(self)
        if view is not None:
            view.clear_guides()
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.canvas_changed.emit()
        event.accept()


class ArrowGrips(object):
    def __init__(self, arrow):
        self.arrow = arrow
        self.handles = [ArrowEndHandle(arrow, 'start'), ArrowEndHandle(arrow, 'end')]
        self.update()
        self.set_visible(False)

    def update(self):
        r = self.arrow.geom_rect
        self.handles[0].setPos(r.topLeft())
        self.handles[1].setPos(r.bottomRight())

    def set_visible(self, visible):
        for handle in self.handles:
            handle.setVisible(visible)


_FRAME_HANDLE_CURSORS = {'tl': QtCore.Qt.SizeFDiagCursor, 'br': QtCore.Qt.SizeFDiagCursor,
                         'tr': QtCore.Qt.SizeBDiagCursor, 'bl': QtCore.Qt.SizeBDiagCursor,
                         't': QtCore.Qt.SizeVerCursor, 'b': QtCore.Qt.SizeVerCursor,
                         'l': QtCore.Qt.SizeHorCursor, 'r': QtCore.Qt.SizeHorCursor}


class FrameResizeHandle(QtWidgets.QGraphicsRectItem):
    pass

    MIN_W, MIN_H = 80.0, 60.0

    def __init__(self, frame, role):
        super().__init__(frame)
        self.role = role
        _style_handle(self, 'br', LINK_COLOR)
        if len(role) == 1:
            size = HANDLE_SIZE * 0.75
            self.setRect(-size / 2, -size / 2, size, size)
        self.setCursor(_FRAME_HANDLE_CURSORS[role])

    def mousePressEvent(self, event):
        frame = self.parentItem()
        self._start_rect = frame.mapRectToScene(frame.frame_rect)
        self._start_pos = event.scenePos()
        event.accept()

    def mouseMoveEvent(self, event):
        frame = self.parentItem()
        d = event.scenePos() - self._start_pos
        r = QtCore.QRectF(self._start_rect)
        k = max(1e-6, frame.scale())
        min_w, min_h = self.MIN_W * k, self.MIN_H * k
        if 'l' in self.role:
            r.setLeft(min(r.left() + d.x(), r.right() - min_w))
        if 'r' in self.role:
            r.setRight(max(r.right() + d.x(), r.left() + min_w))
        if 't' in self.role:
            r.setTop(min(r.top() + d.y(), r.bottom() - min_h))
        if 'b' in self.role:
            r.setBottom(max(r.bottom() + d.y(), r.top() + min_h))
        frame.setPos(frame.pos() + (r.topLeft() - frame.mapToScene(frame.frame_rect.topLeft())))
        frame.set_frame_rect(QtCore.QRectF(0, 0, r.width() / k, r.height() / k))
        event.accept()

    def mouseReleaseEvent(self, event):
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.canvas_changed.emit()
        event.accept()


class FrameGrips(object):
    pass

    def __init__(self, frame):
        self.frame = frame
        self.handles = [FrameResizeHandle(frame, role) for role in ('tl', 't', 'tr', 'r', 'br', 'b', 'bl', 'l')]
        self.update()
        self.set_visible(False)

    def update(self):
        r = self.frame.frame_rect
        c = r.center()
        points = {'tl': r.topLeft(), 't': QtCore.QPointF(c.x(), r.top()), 'tr': r.topRight(),
                  'r': QtCore.QPointF(r.right(), c.y()), 'br': r.bottomRight(),
                  'b': QtCore.QPointF(c.x(), r.bottom()), 'bl': r.bottomLeft(), 'l': QtCore.QPointF(r.left(), c.y())}
        for handle in self.handles:
            handle.setPos(points[handle.role])

    def set_visible(self, visible):
        for handle in self.handles:
            handle.setVisible(visible and not self.frame.collapsed)


class FrameNode(QtWidgets.QGraphicsItem):
    pass

    TYPE = 'frame'

    TOGGLE_W = 22

    def __init__(self, rect, title='Frame', color=LINK_COLOR, uid=None):
        super().__init__()
        self.uid = uid or _new_id()
        self.frame_rect = QtCore.QRectF(rect)
        self.title = title
        self.color_hex = color
        self.links = []
        self.collapsed = False
        self.hidden_ids = []
        self.hover = _NO_HOVER
        self._shape = None
        self._child_starts = None
        self._press_pos = None
        self.setFlags(QtWidgets.QGraphicsItem.ItemIsSelectable | QtWidgets.QGraphicsItem.ItemIsMovable | QtWidgets.QGraphicsItem.ItemSendsGeometryChanges)
        self.grips = FrameGrips(self)

    @classmethod
    def from_dict(cls, d, scene):
        w, h = d.get('rect', [400, 300])
        item = cls(QtCore.QRectF(0, 0, w, h), title=d.get('title', 'Frame'), color=d.get('color', LINK_COLOR), uid=d.get('id'))
        item.collapsed = d.get('collapsed', False)
        item.hidden_ids = list(d.get('hidden', []))
        _apply_base(item, d)
        return item

    def to_dict(self):
        d = _base_dict(self)
        d.update(rect=[self.frame_rect.width(), self.frame_rect.height()], title=self.title, color=self.color_hex)
        if self.collapsed:
            d['collapsed'] = True
            d['hidden'] = list(self.hidden_ids)
        return d

    def apply_dict(self, d):
        w, h = d.get('rect', [400, 300])
        self.set_frame_rect(QtCore.QRectF(0, 0, w, h))
        if d.get('title', 'Frame') != self.title or d.get('color', LINK_COLOR) != self.color_hex:
            self.title = d.get('title', 'Frame')
            self.color_hex = d.get('color', LINK_COLOR)
            self.update()
        self.prepareGeometryChange()
        self.collapsed = d.get('collapsed', False)
        self.hidden_ids = list(d.get('hidden', []))
        self._shape = None
        _apply_base(self, d)

    def set_frame_rect(self, rect):
        self.prepareGeometryChange()
        self.frame_rect = QtCore.QRectF(rect)
        self._shape = None
        self.grips.update()
        _geometry_changed(self)

    def _header_rect(self):
        return QtCore.QRectF(0, -FRAME_HEADER, self.frame_rect.width(), FRAME_HEADER)

    def body_scene_rect(self):
        return self.mapRectToScene(self.frame_rect)

    def boundingRect(self):
        if self.collapsed:
            return self._header_rect().adjusted(-2, -2, 2, 2)
        return self.frame_rect.adjusted(-2, -FRAME_HEADER - 2, 2, 2)

    def shape(self):
        if self._shape is None:
            if self.collapsed:
                shape = QtGui.QPainterPath()
                shape.addRect(self._header_rect())
            else:
                outline = QtGui.QPainterPath()
                outline.addRect(self.frame_rect)
                shape = _stroke_shape(outline, 2)
                shape.addRect(self._header_rect())
            self._shape = shape
        return self._shape

    def paint(self, painter, option, widget):
        color = QtGui.QColor(self.color_hex)
        fill = QtGui.QColor(color)
        fill.setAlpha(22)
        border = QtGui.QColor(color)
        border.setAlpha(200 if self.isSelected() else 140)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setPen(QtGui.QPen(border, 0))
        if self.collapsed:
            bar = QtGui.QColor(color)
            bar.setAlpha(60)
            painter.setBrush(bar)
            painter.drawRoundedRect(self._header_rect(), 6, 6)
        else:
            painter.setBrush(fill)
            painter.drawRoundedRect(self.frame_rect, 6, 6)
        painter.setFont(_ui_font(15, bold=True))
        painter.setPen(color.lighter(130))
        header = self._header_rect()
        painter.drawText(QtCore.QRectF(header.left(), header.top(), self.TOGGLE_W, header.height()),
                         QtCore.Qt.AlignCenter, '▸' if self.collapsed else '▾')
        title = self.title + ('   (%d hidden)' % len(self.hidden_ids) if self.collapsed and self.hidden_ids else '')
        painter.drawText(header.adjusted(self.TOGGLE_W, 0, 0, 0), QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter, title)

    def contained_items(self):
        scene = self.scene()
        if scene is None:
            return []
        if self.collapsed:
            ids = set(self.hidden_ids)
            return [i for i in scene.canvas_items() if i.uid in ids]
        body = self.body_scene_rect()
        return [i for i in scene.canvas_items() if i is not self and body.contains(i.sceneBoundingRect())]

    def toggle_collapse(self):
        pass
        items = self.contained_items()
        self.prepareGeometryChange()
        if self.collapsed:
            self.collapsed = False
            self.hidden_ids = []
            for item in items:
                item.setVisible(True)
        else:
            self.collapsed = True
            self.hidden_ids = [i.uid for i in items]
            for item in items:
                item.setSelected(False)
                item.setVisible(False)
        self._shape = None
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.sync_link_visibility()
            scene.canvas_changed.emit()

    def fit_to_content(self, padding=40):
        items = [i for i in self.contained_items() if i.isVisible()]
        if not items or self.collapsed:
            return False
        rect = _items_rect(items).adjusted(-padding, -padding, padding, padding)
        self.setPos(rect.topLeft())
        self.set_frame_rect(QtCore.QRectF(0, 0, rect.width() / max(1e-6, self.scale()), rect.height() / max(1e-6, self.scale())))
        return True

    def mousePressEvent(self, event):
        header = self._header_rect()
        if event.button() == QtCore.Qt.LeftButton and header.contains(event.pos()) and event.pos().x() < header.left() + self.TOGGLE_W:
            self.toggle_collapse()
            event.accept()
            return
        self._press_pos = self.pos()
        if getattr(self, '_skip_children_once', False):
            self._skip_children_once = False
            children = [i for i in self.contained_items() if not i.isVisible()]
        else:
            children = self.contained_items()
        self._child_starts = [(i, i.pos()) for i in children]
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        self._child_starts = None

    def mouseDoubleClickEvent(self, event):
        if not self._header_rect().contains(event.pos()):
            return super().mouseDoubleClickEvent(event)
        views = self.scene().views() if self.scene() else []
        parent = views[0].window() if views else None
        text, ok = QtWidgets.QInputDialog.getText(parent, 'Frame', 'Title:', QtWidgets.QLineEdit.Normal, self.title)
        if ok and text.strip() and text.strip() != self.title:
            self.title = text.strip()
            self.update()
            scene = self.scene()
            if isinstance(scene, CanvasScene):
                scene.canvas_changed.emit()
        event.accept()

    def itemChange(self, change, value):
        value = _snap_position(self, change, value)
        if change == QtWidgets.QGraphicsItem.ItemPositionHasChanged and self._child_starts:
            delta = self.pos() - self._press_pos
            for item, start in self._child_starts:
                if not item.isSelected():
                    item.setPos(start + delta)
        if change in _GEOMETRY_CHANGES:
            _geometry_changed(self)
        return super().itemChange(change, value)


CANVAS_TYPES = (TextNode, ImageNode, PathNode, ShapeNode, FrameNode, YouTubeNode)
LINKABLE_TYPES = (TextNode, ImageNode, ShapeNode, FrameNode, YouTubeNode)
ITEM_CLASSES = {cls.TYPE: cls for cls in CANVAS_TYPES}


def _canvas_target(item):
    pass
    while item is not None and not isinstance(item, CANVAS_TYPES + (LinkNode,)):
        item = item.parentItem()
    return item
