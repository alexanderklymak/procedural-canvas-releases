pass












import shutil
import zipfile

from ._link import pull
pull(globals())

GUMROAD_PRODUCT_ID = 'EUHrg9JcXx3evN8FYa2GbQ=='
GUMROAD_VERIFY_URL = 'https://alexanderklymak.com/api/licenses/verify'
PRODUCT_URL = 'https://alexanderklymak.com/tools/procedural-canvas/'
MAX_ACTIVATIONS = 3
LICENSE_RECHECK_DAYS = 7
RELEASES_REPO = 'alexanderklymak/procedural-canvas-releases'
UPDATE_URL = 'https://raw.githubusercontent.com/%s/main/latest.json' % RELEASES_REPO
UPDATE_CHECK_HOURS = 4

_STATE = {'checked': False, 'update': None, 'installing': False, 'installed': None}



class LicenseRequired(Exception):
    pass


def _license_path():
    return _pref_path('procedural_canvas_license.json')


def _read_license():
    try:
        with open(_license_path(), 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) and data.get('key') else None
    except (OSError, ValueError):
        return None


def _write_license(data):
    try:
        if data is None:
            if os.path.exists(_license_path()):
                os.remove(_license_path())
            return
        with open(_license_path(), 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    except OSError:
        _log_error('Could not save the license file')


def _http_json(url, data=None, timeout=10):
    pass
    body = urllib.parse.urlencode(data).encode('ascii') if data is not None else None
    request = urllib.request.Request(url, data=body, headers={'User-Agent': '%s/%s' % (PLUGIN_NAME, PLUGIN_VERSION)})
    try:
        with open_url(request, timeout=timeout) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        raw = exc.read()
    return json.loads(raw.decode('utf-8'))


def verify_key(key, activate):
    pass

    key = (key or '').strip()
    if not key:
        return False, 'Enter the license key from your purchase email.', {}
    try:
        data = _http_json(GUMROAD_VERIFY_URL, {'product_id': GUMROAD_PRODUCT_ID, 'license_key': key,
                                               'increment_uses_count': 'true' if activate else 'false'})
    except (OSError, ValueError) as exc:
        return False, 'Could not reach the license server to check the key: %s\nCheck the internet connection and try again.' % exc, {}
    if not data.get('success'):
        return False, data.get('message') or 'This key is not valid for %s.' % PLUGIN_NAME, data
    purchase = data.get('purchase') or {}
    if purchase.get('refunded') or purchase.get('chargebacked') or purchase.get('disputed'):
        return False, 'This purchase was refunded, so the key is no longer active.', data
    uses = int(data.get('uses') or 0)
    if activate and uses > MAX_ACTIVATIONS:
        return False, ('This key is already active on %d computers (the limit is %d).\n'
                       'Write to %s if you reinstalled or changed computers.' % (uses - 1, MAX_ACTIVATIONS, SUPPORT_CONTACT or 'support')), data
    return True, 'Activated for %s.' % (purchase.get('email') or 'this purchase'), data


def license_required():
    pass

    if not GUMROAD_PRODUCT_ID:
        return False
    return not is_dev_install() or bool(os.environ.get('PROCEDURAL_CANVAS_TEST_LICENSE'))


def licensed():
    pass
    return not license_required() or _read_license() is not None


def ensure_licensed(parent=None):
    pass

    if not license_required():
        return True
    if _read_license() is not None:
        return True
    dialog = LicenseDialog(parent)
    return dialog.exec() == QtWidgets.QDialog.Accepted and _read_license() is not None


def activate(key):
    ok, message, data = verify_key(key, activate=True)
    if ok:
        purchase = data.get('purchase') or {}
        _write_license({'key': key.strip(), 'email': purchase.get('email', ''), 'product': GUMROAD_PRODUCT_ID,
                        'activated_at': time.time(), 'checked_at': time.time(), 'version': PLUGIN_VERSION})
    return ok, message


class _Fetcher(QtCore.QObject):
    pass
    done = QtCore.Signal(object)

    def start(self, work):
        def run():
            try:
                result = work()
            except Exception as exc:
                result = exc
            self.done.emit(result)
        threading.Thread(target=run, daemon=True).start()


_FETCHERS = []


def _fetch(work, on_done):
    fetcher = _Fetcher()
    _FETCHERS.append(fetcher)

    def finished(result):
        if fetcher in _FETCHERS:
            _FETCHERS.remove(fetcher)
        try:
            on_done(result)
        except Exception:
            _log_error('Background check failed')
    fetcher.done.connect(finished)
    fetcher.start(work)


def recheck_later():
    pass
    if not GUMROAD_PRODUCT_ID:
        return
    data = _read_license()
    if data is None or time.time() - float(data.get('checked_at') or 0) < LICENSE_RECHECK_DAYS * 86400:
        return
    key = data['key']

    def work():
        return verify_key(key, activate=False)

    def on_done(result):
        if isinstance(result, Exception):
            return
        ok, message, response = result
        if ok:
            data['checked_at'] = time.time()
            _write_license(data)
        elif response:
            _write_license(None)
            _log_info('License check failed: %s' % message)
    _fetch(work, on_done)



def _version_tuple(text):
    parts = []
    for piece in str(text).split('.'):
        digits = ''.join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def newer(candidate, current=None):
    return _version_tuple(candidate) > _version_tuple(current or PLUGIN_VERSION)


def included_in_license(candidate, current=None):
    pass

    return _version_tuple(candidate)[:1] == _version_tuple(current or PLUGIN_VERSION)[:1]


def available_update():
    pass
    return _STATE['update']


def check_updates(on_found=None, on_installed=None):
    pass

    if not UPDATE_URL:
        return
    if _STATE['checked']:
        if _STATE['installed']:
            if on_installed:
                on_installed(_STATE['installed'], _STATE['update'][2] if _STATE['update'] else '')
        elif _STATE['update'] and on_found and not _STATE['installing']:
            on_found(*_STATE['update'])
        if time.time() - float(SETTINGS.values.get('update_checked_at') or 0) < UPDATE_CHECK_HOURS * 3600:
            return
    _STATE['checked'] = True

    def work():
        return _http_json(UPDATE_URL)

    def on_done(result):
        if isinstance(result, Exception) or not isinstance(result, dict):
            return
        SETTINGS.values['update_checked_at'] = time.time()
        SETTINGS.save()
        version = str(result.get('version') or '')
        if version and newer(version):
            _STATE['update'] = (version, str(result.get('url') or PRODUCT_URL), str(result.get('notes') or ''))
            if auto_update_allowed() and result.get('zip') and included_in_license(version):
                _start_install(result, on_found, on_installed)
            elif on_found:
                on_found(*_STATE['update'])
    _fetch(work, on_done)



def package_root():
    pass
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def is_dev_install():
    pass
    return os.path.isdir(os.path.join(os.path.dirname(package_root()), '.git'))


def auto_update_allowed():
    if os.environ.get('PROCEDURAL_CANVAS_NO_AUTOUPDATE'):
        return False
    return bool(SETTINGS.values.get('auto_update', True)) and not is_dev_install()


def _start_install(info, on_found, on_installed):
    version = str(info.get('version'))
    if _STATE['installing'] or _STATE['installed'] == version:
        return
    _STATE['installing'] = True

    def done(result):
        _STATE['installing'] = False
        if isinstance(result, Exception):
            _log_error('Automatic update to %s failed: %s' % (version, result))
            if on_found:
                on_found(*_STATE['update'])
            return
        _STATE['installed'] = version
        _log_info('Updated to %s (active after Houdini restart)' % version)
        if on_installed:
            on_installed(version, str(info.get('notes') or ''))
    _fetch(lambda: install_update(info), done)


def _download(url, path, timeout=120):
    request = urllib.request.Request(url, headers={'User-Agent': '%s/%s' % (PLUGIN_NAME, PLUGIN_VERSION)})
    with open_url(request, timeout=timeout) as response, open(path, 'wb') as out:
        shutil.copyfileobj(response, out)


def _same_file(a, b):
    with open(a, 'rb') as fa, open(b, 'rb') as fb:
        return fa.read() == fb.read()


def _copy_with_retries(src, dst, attempts=10):
    for attempt in range(attempts):
        try:
            shutil.copy2(src, dst)
            return
        except OSError:
            if attempt == attempts - 1:
                raise
            time.sleep(0.5)


def _sync_tree(src, dst):
    pass

    wanted = set()
    for folder, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d != '__pycache__']
        rel = os.path.relpath(folder, src)
        os.makedirs(os.path.join(dst, rel), exist_ok=True)
        for name in files:
            if name.endswith('.pyc'):
                continue
            wanted.add(os.path.normcase(os.path.normpath(os.path.join(rel, name))))
            _copy_with_retries(os.path.join(folder, name), os.path.join(dst, rel, name))
    for folder, dirs, files in os.walk(dst):
        for name in files:
            rel = os.path.normcase(os.path.normpath(os.path.relpath(os.path.join(folder, name), dst)))
            if rel not in wanted and '__pycache__' not in rel.split(os.sep):
                try:
                    os.remove(os.path.join(folder, name))
                except OSError:
                    pass
        for name in [d for d in dirs if d == '__pycache__']:
            shutil.rmtree(os.path.join(folder, name), ignore_errors=True)


def install_update(info, root=None):
    pass


    root = root or package_root()
    version = str(info['version'])
    work = tempfile.mkdtemp(prefix='procedural_canvas_update_')
    try:
        archive = os.path.join(work, 'update.zip')
        _download(info['zip'], archive)
        expected = str(info.get('sha256') or '').lower()
        if expected:
            digest = hashlib.sha256()
            with open(archive, 'rb') as f:
                for chunk in iter(lambda: f.read(1 << 20), b''):
                    digest.update(chunk)
            if digest.hexdigest() != expected:
                raise ValueError('checksum mismatch for %s' % version)
        staging = os.path.join(work, 'new')
        marker = 'packages/procedural_canvas/'
        with zipfile.ZipFile(archive) as zf:
            names = [n for n in zf.namelist() if not n.endswith('/')]
            prefix = next((n[:n.index(marker) + len(marker)] for n in names
                           if n.endswith(marker + 'python/procedural_canvas/__init__.py')), None)
            if prefix is None:
                raise ValueError('the archive has no packages/procedural_canvas')
            for name in names:
                if not name.startswith(prefix):
                    continue
                rel = os.path.normpath(name[len(prefix):])
                if rel.startswith('..') or os.path.isabs(rel):
                    raise ValueError('unsafe path in the archive: %s' % name)
                target = os.path.join(staging, rel)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with zf.open(name) as src, open(target, 'wb') as dst:
                    shutil.copyfileobj(src, dst)
        new_python = os.path.join(staging, 'python')
        for folder, _, files in os.walk(new_python):
            for name in files:
                if name.endswith('.py'):
                    path = os.path.join(folder, name)
                    with open(path, 'r', encoding='utf-8') as f:
                        compile(f.read(), path, 'exec')



        current, previous = os.path.join(root, 'python'), os.path.join(root, '_previous_python')
        shutil.rmtree(os.path.join(root, '_incoming_python'), ignore_errors=True)
        shutil.rmtree(previous, ignore_errors=True)
        shutil.copytree(current, previous, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        try:
            _sync_tree(new_python, current)
        except OSError:
            _sync_tree(previous, current)
            raise


        for name in os.listdir(staging):
            src, dst = os.path.join(staging, name), os.path.join(root, name)
            try:
                if name == 'python':
                    continue
                if os.path.isdir(src):
                    _sync_tree(src, dst)
                elif not os.path.exists(dst) or not _same_file(src, dst):
                    _copy_with_retries(src, dst)
            except OSError:
                _log_info('Could not update %s now, it will be updated next time' % name)
        return version
    finally:
        shutil.rmtree(work, ignore_errors=True)


class LicenseDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('%s — License key' % PLUGIN_NAME)
        self.setMinimumWidth(460)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(10)
        title = QtWidgets.QLabel('<b style="font-size:15px">Enter your license key</b>')
        layout.addWidget(title)
        hint = QtWidgets.QLabel('The key is in the email you received after the purchase. '
                                'One key works on up to %d of your computers.' % MAX_ACTIVATIONS)
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.edit = QtWidgets.QLineEdit()
        self.edit.setPlaceholderText('XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX')
        self.edit.setFont(_ui_font(13, kind='mono'))
        layout.addWidget(self.edit)
        self.status = QtWidgets.QLabel('')
        self.status.setWordWrap(True)
        self.status.setObjectName('hint')
        layout.addWidget(self.status)
        buttons = QtWidgets.QHBoxLayout()
        if PRODUCT_URL:
            buy = QtWidgets.QPushButton('Buy a license…')
            buy.clicked.connect(lambda: QtGui.QDesktopServices.openUrl(QtCore.QUrl(PRODUCT_URL)))
            buttons.addWidget(buy)
        buttons.addStretch(1)
        cancel = QtWidgets.QPushButton('Cancel')
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        self.activate_btn = QtWidgets.QPushButton('Activate')
        self.activate_btn.setDefault(True)
        self.activate_btn.clicked.connect(self._activate)
        buttons.addWidget(self.activate_btn)
        layout.addLayout(buttons)
        self.edit.returnPressed.connect(self._activate)

    def _activate(self):
        self.activate_btn.setEnabled(False)
        self.status.setText('Checking the key…')
        QtWidgets.QApplication.processEvents()
        ok, message = activate(self.edit.text())
        self.status.setText(message)
        self.activate_btn.setEnabled(True)
        if ok:
            QtCore.QTimer.singleShot(600, self.accept)
