pass

from ._link import pull
pull(globals())




class MiniMap(QtWidgets.QWidget):
    pass

    def __init__(self, main_view, parent=None):
        super().__init__(parent or main_view)
        self.main_view = main_view
        self.setFixedSize(200, 150)
        self.setCursor(QtCore.Qt.PointingHandCursor)
        self._pixmap = None
        self._mapping = None
        self.overview = None

    def refresh(self):
        pass

        rect = self.main_view.scene().itemsBoundingRect()
        if rect.isEmpty():
            self._pixmap = None
            self._mapping = None
            self.overview = None
            self.update()
            return
        rect = rect.adjusted(-50, -50, 50, 50)
        scale = min(1.0, math.sqrt(OVERVIEW_MAX_PIXELS / max(1.0, rect.width() * rect.height())))
        overview = QtGui.QPixmap(max(1, int(rect.width() * scale)), max(1, int(rect.height() * scale)))
        overview.fill(QtCore.Qt.transparent)
        painter = QtGui.QPainter(overview)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        self.main_view.scene().render(painter, QtCore.QRectF(overview.rect()), rect)
        painter.end()
        self.overview = (overview, QtCore.QRectF(rect))
        pad = 6
        w, h = self.width() - 2 * pad, self.height() - 2 * pad
        s = min(w / rect.width(), h / rect.height())
        ox = pad + (w - rect.width() * s) / 2
        oy = pad + (h - rect.height() * s) / 2
        pixmap = QtGui.QPixmap(self.size())
        pixmap.fill(QtCore.Qt.transparent)
        painter = QtGui.QPainter(pixmap)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        board = QtCore.QRectF(ox, oy, rect.width() * s, rect.height() * s)
        painter.fillRect(board, QtGui.QColor(_canvas_bg()))
        painter.drawPixmap(board, overview, QtCore.QRectF(overview.rect()))
        painter.end()
        self._pixmap = pixmap
        self._mapping = (rect, s, ox, oy)
        self.update()

    def _to_widget(self, p):
        rect, s, ox, oy = self._mapping
        return QtCore.QPointF(ox + (p.x() - rect.left()) * s, oy + (p.y() - rect.top()) * s)

    def _to_scene(self, p):
        rect, s, ox, oy = self._mapping
        return QtCore.QPointF(rect.left() + (p.x() - ox) / s, rect.top() + (p.y() - oy) / s)

    SIZES = {'S': (150, 112), 'M': (200, 150), 'L': (280, 210)}

    def apply_settings(self):
        pass
        w, h = self.SIZES.get(SETTINGS['minimap_size'], self.SIZES['M'])
        if (w, h) != (self.width(), self.height()):
            self.setFixedSize(w, h)
            self.refresh()
        area = self.parentWidget()
        corner = SETTINGS['minimap_corner']
        x = 20 if corner in ('bl', 'tl') else area.width() - w - 20
        y = 20 if corner in ('tl', 'tr') else area.height() - h - 20
        self.move(x, y)
        self.setVisible(SETTINGS['minimap_visible'])

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        theme = _theme()
        painter.setPen(QtGui.QPen(QtGui.QColor(theme['panel_border']), 2))
        background = QtGui.QColor(theme['panel'])
        background.setAlpha(215)
        painter.setBrush(background)
        painter.drawRoundedRect(QtCore.QRectF(self.rect()).adjusted(1, 1, -1, -1), 8, 8)
        if self._pixmap is None:
            return
        painter.drawPixmap(0, 0, self._pixmap)

        visible = self.main_view.mapToScene(self.main_view.viewport().rect()).boundingRect()
        painter.setClipRect(self.rect().adjusted(2, 2, -2, -2))
        painter.setPen(QtGui.QPen(QtGui.QColor(*GLOW_COLOR), 1))
        painter.setBrush(QtGui.QColor(*GLOW_COLOR, 40))
        painter.drawRect(QtCore.QRectF(self._to_widget(visible.topLeft()), self._to_widget(visible.bottomRight())))

    def _jump(self, event):
        if self._mapping is not None:
            self.main_view.centerOn(self._to_scene(_event_pos(event)))
            self.update()

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self._jump(event)
        event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() & QtCore.Qt.LeftButton:
            self._jump(event)
        event.accept()

    def mouseReleaseEvent(self, event):
        event.accept()

    def wheelEvent(self, event):
        event.accept()




class FontPickerPopup(QtWidgets.QFrame):
    pass

    previewed = QtCore.Signal(str)
    picked = QtCore.Signal(str)
    closed = QtCore.Signal()

    def __init__(self, parent, current):
        super().__init__(parent, QtCore.Qt.Popup)
        self.setObjectName('fontPopup')
        self.setStyleSheet(_style("""
            QFrame#fontPopup { background: %(panel)s; border: 1px solid %(panel_border)s; border-radius: 8px; }
            QLineEdit { background: %(input)s; color: %(text)s; border: 1px solid %(panel_border)s; border-radius: 5px;
                        padding: 5px 8px; font-size: 13px; }
            QListWidget { background: transparent; color: %(text)s; border: none; outline: none; }
            QListWidget::item { padding: 4px 6px; border-radius: 4px; }
            QListWidget::item:hover { background: %(btn_hover)s; }
            QListWidget::item:selected { background: %(accent_strong)s; color: #ffffff; }
        """))
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText('Type a font name…')
        self.list = QtWidgets.QListWidget()
        self.list.setMouseTracking(True)
        self.list.setFixedSize(280, 340)
        layout.addWidget(self.search)
        layout.addWidget(self.list)
        current_row = 0
        for k, family in enumerate(_font_families()):
            item = QtWidgets.QListWidgetItem(family)
            item.setFont(QtGui.QFont(family, 11))
            self.list.addItem(item)
            if family == current:
                current_row = k
        self.list.setCurrentRow(current_row)
        self.list.itemEntered.connect(lambda item: self.previewed.emit(item.text()))
        self.list.itemClicked.connect(lambda item: self._pick(item.text()))
        self.search.textChanged.connect(self._filter)
        self.search.returnPressed.connect(self._pick_current)
        self.search.installEventFilter(self)

    def _visible_rows(self):
        return [r for r in range(self.list.count()) if not self.list.item(r).isHidden()]

    def _filter(self, text):
        text = text.strip().lower()
        starts, contains = [], []
        for r in range(self.list.count()):
            name = self.list.item(r).text().lower()
            hit = not text or text in name
            self.list.item(r).setHidden(not hit)
            if hit:
                (starts if name.startswith(text) else contains).append(r)
        best = (starts or contains or [None])[0]
        if best is not None:
            self.list.setCurrentRow(best)
            self.list.scrollToItem(self.list.item(best))
            if text:
                self.previewed.emit(self.list.item(best).text())

    def _pick_current(self):
        item = self.list.currentItem()
        if item is not None and not item.isHidden():
            self._pick(item.text())

    def _pick(self, family):
        self.picked.emit(family)
        self.hide()

    def eventFilter(self, obj, event):

        if obj is self.search and event.type() == QtCore.QEvent.KeyPress and event.key() in (QtCore.Qt.Key_Up, QtCore.Qt.Key_Down):
            rows = self._visible_rows()
            if rows:
                row = self.list.currentRow()
                pos = rows.index(row) if row in rows else 0
                pos = max(0, min(len(rows) - 1, pos + (1 if event.key() == QtCore.Qt.Key_Down else -1)))
                self.list.setCurrentRow(rows[pos])
                self.previewed.emit(self.list.item(rows[pos]).text())
            return True
        return super().eventFilter(obj, event)

    def _dispose(self):
        if not self.isVisible() and not getattr(self, '_busy', False):
            self.deleteLater()

    def hideEvent(self, event):
        super().hideEvent(event)
        QtCore.QTimer.singleShot(0, self._dispose)
        self.closed.emit()

    def popup_below(self, widget):
        self.adjustSize()
        self.move(widget.mapToGlobal(QtCore.QPoint(0, widget.height() + 4)))
        self.show()
        self.search.setFocus()
        item = self.list.currentItem()
        if item is not None:
            self.list.scrollToItem(item, QtWidgets.QAbstractItemView.PositionAtCenter)


class FontPickerButton(QtWidgets.QToolButton):
    pass
    picked = QtCore.Signal(str)
    previewed = QtCore.Signal(str)
    preview_ended = QtCore.Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._family = QtGui.QFont().family()
        self._popup = None
        self.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)
        self.setCursor(QtCore.Qt.PointingHandCursor)
        self.clicked.connect(self.open_popup)
        self._update_text()

    def currentFont(self):
        return QtGui.QFont(self._family)

    def setCurrentFont(self, font):
        self._family = font.family()
        self._update_text()

    def _update_text(self):
        metrics = QtGui.QFontMetrics(self.font())
        self.setText(metrics.elidedText(self._family, QtCore.Qt.ElideRight, max(40, self.width() - 16)) + '  ▾')

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_text()

    def open_popup(self):
        popup = FontPickerPopup(self.window(), self._family)
        popup.previewed.connect(self.previewed.emit)
        popup.picked.connect(self._on_picked)
        popup.closed.connect(self.preview_ended.emit)
        self._popup = popup
        popup.popup_below(self)

    def _on_picked(self, family):
        self.setCurrentFont(QtGui.QFont(family))
        self.picked.emit(family)


class FontSizePopup(QtWidgets.QFrame):
    pass

    previewed = QtCore.Signal(int)
    picked = QtCore.Signal(int)
    closed = QtCore.Signal()

    def __init__(self, parent, value, low, high):
        super().__init__(parent, QtCore.Qt.Popup)
        self._initial = value
        self.setObjectName('sizePopup')
        self.setStyleSheet(_style("""
            QFrame#sizePopup { background: %(panel)s; border: 1px solid %(panel_border)s; border-radius: 8px; }
            QLabel { color: %(dim)s; font-size: 12px; }
            QSpinBox { background: %(input)s; color: %(text)s; border: 1px solid %(panel_border)s; border-radius: 4px;
                       padding: 2px 4px; font-size: 13px; }
            QSlider::groove:horizontal { height: 4px; background: %(panel_border)s; border-radius: 2px; }
            QSlider::handle:horizontal { width: 14px; margin: -6px 0; border-radius: 7px; background: %(accent)s; }
        """))
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)
        layout.addWidget(QtWidgets.QLabel('Size'))
        self.slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider.setRange(low, min(high, 120))
        self.slider.setFixedWidth(200)
        self.slider.setValue(value)
        self.spin = QtWidgets.QSpinBox()
        self.spin.setRange(low, high)
        self.spin.setSuffix(' pt')
        self.spin.setValue(value)
        self.spin.setFixedWidth(72)
        layout.addWidget(self.slider, 1)
        layout.addWidget(self.spin)
        self.slider.valueChanged.connect(self._on_slider)
        self.spin.valueChanged.connect(self._on_spin)
        self.spin.lineEdit().returnPressed.connect(self.hide)

    def value(self):
        return self.spin.value()

    def _on_slider(self, value):
        if self.spin.value() != value:
            self.spin.blockSignals(True)
            self.spin.setValue(value)
            self.spin.blockSignals(False)
        self.previewed.emit(value)

    def _on_spin(self, value):
        if self.slider.value() != value:
            self.slider.blockSignals(True)
            self.slider.setValue(value)
            self.slider.blockSignals(False)
        self.previewed.emit(value)

    def _dispose(self):
        if not self.isVisible() and not getattr(self, '_busy', False):
            self.deleteLater()

    def hideEvent(self, event):
        super().hideEvent(event)
        QtCore.QTimer.singleShot(0, self._dispose)
        if self.value() != self._initial:
            self.picked.emit(self.value())
        self.closed.emit()

    def popup_below(self, widget):
        self.adjustSize()
        self.move(widget.mapToGlobal(QtCore.QPoint(0, widget.height() + 4)))
        self.show()
        self.slider.setFocus()


class FontSizeButton(QtWidgets.QToolButton):
    pass
    valueChanged = QtCore.Signal(int)
    previewed = QtCore.Signal(int)
    preview_ended = QtCore.Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._value = 16
        self._low, self._high = 8, 300
        self._popup = None
        self.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)
        self.setCursor(QtCore.Qt.PointingHandCursor)
        self.clicked.connect(self.open_popup)
        self._update_text()

    def setRange(self, low, high):
        self._low, self._high = low, high

    def value(self):
        return self._value

    def setValue(self, value):
        value = max(self._low, min(self._high, int(value)))
        if value == self._value:
            return
        self._value = value
        self._update_text()
        self.valueChanged.emit(value)

    def _update_text(self):
        self.setText('%d' % self._value)

    def open_popup(self):
        popup = FontSizePopup(self.window(), self._value, self._low, self._high)
        popup.previewed.connect(self.previewed.emit)
        popup.picked.connect(self.setValue)
        popup.closed.connect(self.preview_ended.emit)
        self._popup = popup
        popup.popup_below(self)


class _Swatch(QtWidgets.QToolButton):
    hovered = QtCore.Signal(str)

    def __init__(self, color, parent=None):
        super().__init__(parent)
        self.color = color
        self.setFixedSize(24, 24)
        self.setCursor(QtCore.Qt.PointingHandCursor)
        self.setToolTip(color)
        self.setStyleSheet("QToolButton { background: %s; border: 1px solid #1a1a1a; border-radius: 5px; }"
                           "QToolButton:hover { border: 2px solid #ffffff; }" % color)

    def enterEvent(self, event):
        self.hovered.emit(self.color)
        super().enterEvent(event)


class ColorPopup(QtWidgets.QFrame):
    pass

    PALETTE = ['#ffffff', '#d1d8e0', '#a5b1c2', '#778ca3', '#4b6584', '#2d3436', '#141414', '#000000',
               '#ff4757', '#ff6b81', '#e17055', '#ffa502', '#eccc68', '#ffeb3b', '#7bed9f', '#2ed573',
               '#00b894', '#00cec9', '#1e90ff', '#70a1ff', '#5352ed', '#6c5ce7', '#a29bfe', '#fd79a8']
    hovered = QtCore.Signal(str)
    picked = QtCore.Signal(str)
    closed = QtCore.Signal()
    opacity_changed = QtCore.Signal(int)

    def __init__(self, parent, current, recent, title, none_label=None, opacity=None, palette=None):
        super().__init__(parent, QtCore.Qt.Popup)
        self._current = current or '#ffffff'
        self._title = title
        self.setObjectName('colorPopup')
        self.setStyleSheet(_style("""
            QFrame#colorPopup { background: %(panel)s; border: 1px solid %(panel_border)s; border-radius: 8px; }
            QLabel { color: %(dim)s; font-size: 12px; }
            QLineEdit { background: %(input)s; color: %(text)s; border: 1px solid %(panel_border)s; border-radius: 4px; padding: 3px 6px; }
            QPushButton { background: %(btn)s; color: %(text)s; border: 1px solid %(panel_border)s; border-radius: 4px; padding: 3px 10px; }
            QPushButton:hover { background: %(btn_hover)s; }
            QSlider::groove:horizontal { height: 4px; background: %(panel_border)s; border-radius: 2px; }
            QSlider::handle:horizontal { width: 14px; margin: -6px 0; border-radius: 7px; background: %(accent)s; }
        """))
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        if none_label:
            none_btn = QtWidgets.QPushButton('∅  ' + none_label)
            none_btn.clicked.connect(lambda: self._pick(''))
            layout.addWidget(none_btn)
        layout.addLayout(self._grid(palette or self.PALETTE))
        if recent:
            layout.addWidget(QtWidgets.QLabel('Recent'))
            layout.addLayout(self._grid(recent))
        if opacity is not None:
            row = QtWidgets.QHBoxLayout()
            row.addWidget(QtWidgets.QLabel('Opacity'))
            slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
            slider.setRange(0, 100)
            slider.setValue(opacity)
            value_label = QtWidgets.QLabel('%d%%' % opacity)
            value_label.setFixedWidth(36)
            slider.valueChanged.connect(lambda v: (value_label.setText('%d%%' % v), self.opacity_changed.emit(v)))
            row.addWidget(slider, 1)
            row.addWidget(value_label)
            layout.addLayout(row)
        bottom = QtWidgets.QHBoxLayout()
        self.hex_edit = QtWidgets.QLineEdit(current or '')
        self.hex_edit.setPlaceholderText('#RRGGBB')
        self.hex_edit.setFixedWidth(100)
        self.hex_edit.textEdited.connect(self._on_hex_edited)
        self.hex_edit.returnPressed.connect(self._on_hex_return)
        custom = QtWidgets.QPushButton('Custom…')
        custom.clicked.connect(self._open_dialog)
        bottom.addWidget(self.hex_edit)
        bottom.addStretch()
        bottom.addWidget(custom)
        layout.addLayout(bottom)

    def _grid(self, colors):
        grid = QtWidgets.QGridLayout()
        grid.setSpacing(4)
        for k, color in enumerate(colors):
            swatch = _Swatch(color, self)
            swatch.hovered.connect(self.hovered.emit)
            swatch.clicked.connect(lambda checked=False, c=color: self._pick(c))
            grid.addWidget(swatch, k // 8, k % 8)
        return grid

    def _pick(self, color):
        self.picked.emit(color)
        self.hide()

    def _on_hex_edited(self, text):
        text = text.strip()
        if text.startswith('#') and len(text) in (4, 7) and QtGui.QColor(text).isValid():
            self.hovered.emit(QtGui.QColor(text).name())

    def _on_hex_return(self):
        color = QtGui.QColor(self.hex_edit.text().strip())
        if color.isValid():
            self._pick(color.name())

    def _open_dialog(self):
        self._busy = True
        self.hide()
        color = QtWidgets.QColorDialog.getColor(QtGui.QColor(self._current), self.parentWidget(), self._title)
        if color.isValid():
            self.picked.emit(color.name())
        self._busy = False
        self._dispose()

    def _dispose(self):
        if not self.isVisible() and not getattr(self, '_busy', False):
            self.deleteLater()

    def hideEvent(self, event):
        super().hideEvent(event)
        QtCore.QTimer.singleShot(0, self._dispose)
        self.closed.emit()

    def popup_below(self, widget):
        self.adjustSize()
        self.move(widget.mapToGlobal(QtCore.QPoint(0, widget.height() + 4)))
        self.show()


_PANEL_TEMPLATE = """
    QLabel { color: %(text)s; font-size: 13px; background: transparent; border: none; }
    QLineEdit { background: %(input)s; color: %(text)s; border: 1px solid %(panel_border)s; border-radius: 4px; padding: 4px 8px; font-size: 13px; }
    QPushButton { background: %(btn)s; color: %(text)s; border: 1px solid %(panel_border)s; border-radius: 5px; padding: 5px 12px; font-size: 13px; }
    QPushButton:hover { background: %(btn_hover)s; }
    QPushButton:disabled { color: %(caption)s; border-color: %(group_border)s; }
    QPushButton#primary { background: %(accent_strong)s; color: #ffffff; border-color: %(accent)s; }
    QPushButton#primary:hover { background: %(accent_hover)s; }
    QPushButton#flat { background: transparent; border: none; color: %(dim)s; padding: 2px 6px; }
    QPushButton#flat:hover { color: %(text)s; }
"""


def _panel_style():
    return _style(_PANEL_TEMPLATE)


class FlowLayout(QtWidgets.QLayout):
    pass



    def __init__(self, parent=None, spacing=8):
        super().__init__(parent)
        self._items = []
        self.setSpacing(spacing)

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, index):
        return self._items[index] if 0 <= index < len(self._items) else None

    def takeAt(self, index):
        return self._items.pop(index) if 0 <= index < len(self._items) else None

    def expandingDirections(self):
        return getattr(QtCore.Qt, 'Orientations', QtCore.Qt.Orientation)(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._do_layout(QtCore.QRect(0, 0, width, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do_layout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QtCore.QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        m = self.contentsMargins()
        return size + QtCore.QSize(m.left() + m.right(), m.top() + m.bottom())

    def _do_layout(self, rect, test_only):
        m = self.contentsMargins()
        area = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        spacing = self.spacing()

        lines, line, line_w = [], [], 0
        for item in self._items:
            if item.isEmpty():
                continue
            w = item.sizeHint().width()
            if line and line_w + spacing + w > area.width():
                lines.append(line)
                line, line_w = [], 0
            line_w += (spacing if line else 0) + w
            line.append(item)
        if line:
            lines.append(line)

        y = area.y()
        for line in lines:
            hints = [item.sizeHint() for item in line]
            used = sum(h.width() for h in hints) + spacing * (len(line) - 1)
            extra = max(0, area.width() - used)
            gap = spacing + (extra / (len(line) - 1) if len(line) > 1 else 0)
            line_h = max(h.height() for h in hints)
            x = float(area.x())
            for item, hint in zip(line, hints):
                if not test_only:
                    item.setGeometry(QtCore.QRect(int(x), y + (line_h - hint.height()) // 2, hint.width(), hint.height()))
                x += hint.width() + gap
            y += line_h + spacing
        return y - spacing - rect.y() + m.bottom() if lines else m.top() + m.bottom()


class SettingsDialog(QtWidgets.QDialog):
    pass
    changed = QtCore.Signal()


    HIDDEN_KEYS = ('zoom_speed', 'zoom_smooth', 'hover_strength', 'hover_open_ms', 'node_summary',
                   'gpu', 'gpu_docked', 'gpu_vsync', 'gpu_samples', 'frame_stats', 'zoom_proxy')

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle('Procedural Canvas — Settings')
        self.setObjectName('settingsDialog')
        self.setMinimumWidth(500)
        self.setStyleSheet(_style("""
            QDialog#settingsDialog { background: %(panel)s; }
            QTabWidget::pane { border: 1px solid %(group_border)s; border-radius: 6px; top: -1px; }
            QTabBar::tab { background: %(group)s; color: %(dim)s; padding: 6px 14px; border: 1px solid %(group_border)s;
                           border-bottom: none; border-top-left-radius: 6px; border-top-right-radius: 6px; margin-right: 2px; }
            QTabBar::tab:selected { background: %(panel)s; color: %(text)s; }
            QSpinBox, QFontComboBox, QComboBox { background: %(input)s; color: %(text)s; border: 1px solid %(panel_border)s;
                                      border-radius: 4px; padding: 3px 6px; min-height: 22px; font-size: 13px; }
            QCheckBox { color: %(text)s; font-size: 13px; }
            QLabel#hint { color: %(caption)s; font-size: 11px; }
            QSlider::groove:horizontal { height: 4px; background: %(panel_border)s; border-radius: 2px; }
            QSlider::handle:horizontal { width: 14px; margin: -6px 0; border-radius: 7px; background: %(accent)s; }
        """) + _panel_style())
        tabs = QtWidgets.QTabWidget()


        look = QtWidgets.QFormLayout()
        look.setSpacing(10)
        self.theme = QtWidgets.QComboBox()
        self.theme.addItem('Dark', 'dark')
        self.theme.addItem('Light', 'light')
        look.addRow('Theme', self.theme)
        self.canvas_bg = self._color_button('Theme default')
        look.addRow('Canvas background', self._with_reset(self.canvas_bg))
        self.accent = self._color_button(None)
        look.addRow('Accent color', self.accent)
        self.grid_style = QtWidgets.QComboBox()
        self.grid_style.addItem('Lines', 'lines')
        self.grid_style.addItem('Dots', 'dots')
        look.addRow('Grid style', self.grid_style)
        self.grid_default = QtWidgets.QCheckBox('Turn the grid on when a board opens')
        look.addRow('', self.grid_default)
        self.grid = QtWidgets.QSpinBox()
        self.grid.setRange(10, 200)
        self.grid.setSuffix(' px')
        look.addRow('Grid spacing', self.grid)
        corner_row, self.corner = self._slider_row(0, 50, ' %')
        look.addRow('Image corner radius', corner_row)
        self.minimap_visible = QtWidgets.QCheckBox('Show the minimap')
        look.addRow('', self.minimap_visible)

        font_row = QtWidgets.QHBoxLayout()
        self.font = QtWidgets.QFontComboBox()
        self.system_font = QtWidgets.QCheckBox('System')
        self.system_font.toggled.connect(lambda on: self.font.setEnabled(not on))
        font_row.addWidget(self.font, 1)
        font_row.addWidget(self.system_font)
        look.addRow('Default font', font_row)
        self.font_size = QtWidgets.QSpinBox()
        self.font_size.setRange(8, 300)
        self.font_size.setSuffix(' pt')
        look.addRow('Default font size', self.font_size)
        self.minimap_corner = QtWidgets.QComboBox()
        for label, value in (('Bottom right', 'br'), ('Bottom left', 'bl'), ('Top right', 'tr'), ('Top left', 'tl')):
            self.minimap_corner.addItem(label, value)
        look.addRow('Minimap corner', self.minimap_corner)
        self.minimap_size = QtWidgets.QComboBox()
        for label, value in (('Small', 'S'), ('Medium', 'M'), ('Large', 'L')):
            self.minimap_size.addItem(label, value)
        look.addRow('Minimap size', self.minimap_size)
        tabs.addTab(self._page(look), 'Appearance')

        tabs.addTab(self._about_page(), 'About')

        self._kept = {key: SETTINGS[key] for key in self.HIDDEN_KEYS}

        hint = QtWidgets.QLabel('Saved for your user on this computer and used in every project:\n' + CanvasSettings.path())
        hint.setObjectName('hint')
        hint.setWordWrap(True)

        buttons = QtWidgets.QHBoxLayout()
        reset = QtWidgets.QPushButton('Reset to defaults')
        reset.clicked.connect(lambda: self._fill(CanvasSettings.DEFAULTS))
        cancel = QtWidgets.QPushButton('Cancel')
        cancel.clicked.connect(self.reject)
        save = QtWidgets.QPushButton('Save')
        save.setObjectName('primary')
        save.setDefault(True)
        save.clicked.connect(self.accept)
        buttons.addWidget(reset)
        buttons.addStretch()
        buttons.addWidget(cancel)
        buttons.addWidget(save)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(14)
        layout.addWidget(tabs)
        layout.addWidget(hint)
        layout.addLayout(buttons)
        self._fill(SETTINGS.values)
        for signal in (self.theme.currentIndexChanged, self.grid_style.currentIndexChanged, self.grid_default.toggled,
                       self.grid.valueChanged, self.corner.valueChanged, self.minimap_visible.toggled,
                       self.minimap_corner.currentIndexChanged, self.minimap_size.currentIndexChanged,
                       self.font.currentFontChanged, self.system_font.toggled, self.font_size.valueChanged):
            signal.connect(lambda *_: self.changed.emit())

    def _about_page(self):
        form = QtWidgets.QFormLayout()
        form.setSpacing(8)
        title = QtWidgets.QLabel('<b style="font-size:16px">%s</b>' % PLUGIN_NAME)
        form.addRow(title)
        form.addRow('Version', QtWidgets.QLabel(PLUGIN_VERSION))
        update = available_update()
        if _STATE.get('installed'):
            form.addRow('Update', QtWidgets.QLabel('%s is installed — restart Houdini to use it' % _STATE['installed']))
        elif update:
            link = QtWidgets.QLabel('<a href="%s">Update %s is available</a>' % (update[1], update[0]))
            link.setOpenExternalLinks(True)
            form.addRow('Update', link)
        auto = QtWidgets.QCheckBox('Install updates automatically')
        auto.setChecked(bool(SETTINGS.values.get('auto_update', True)))
        if is_dev_install():
            auto.setEnabled(False)
            auto.setToolTip('Developer copy (git repository): updates come from git, not from the update server')

        def toggle_auto(on):
            SETTINGS.values['auto_update'] = bool(on)
            SETTINGS.save()
        auto.toggled.connect(toggle_auto)
        form.addRow('', auto)
        if GUMROAD_PRODUCT_ID:
            data = _read_license() or {}
            form.addRow('License', QtWidgets.QLabel(data.get('email') or 'not activated'))
        form.addRow('Author', QtWidgets.QLabel(PLUGIN_AUTHOR))
        if SUPPORT_CONTACT:
            contact = QtWidgets.QLabel(SUPPORT_CONTACT)
            contact.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            form.addRow('Support', contact)
        info = QtWidgets.QLabel(_system_info().replace(' | ', '\n'))
        info.setObjectName('hint')
        info.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        form.addRow('System', info)
        log = QtWidgets.QLabel(_log_path())
        log.setObjectName('hint')
        log.setWordWrap(True)
        log.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        form.addRow('Error log', log)
        row = QtWidgets.QHBoxLayout()
        copy = QtWidgets.QPushButton('Copy system info')
        copy.clicked.connect(lambda: QtWidgets.QApplication.clipboard().setText(_system_info()))
        open_log = QtWidgets.QPushButton('Open log folder')

        def show_log_folder():
            folder = os.path.dirname(_log_path())
            os.makedirs(folder, exist_ok=True)
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(folder))
        open_log.clicked.connect(show_log_folder)
        guide_path = os.path.join(package_root(), 'USER_GUIDE.html')
        if os.path.isfile(guide_path):
            guide = QtWidgets.QPushButton('User guide')
            guide.clicked.connect(lambda: QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(guide_path)))
            row.addWidget(guide)
        row.addWidget(copy)
        row.addWidget(open_log)
        row.addStretch()
        form.addRow(row)
        hint = QtWidgets.QLabel(('Found a problem? E-mail %s with a short description of what happened, '
                                 'and attach the error log file (Open log folder) and the system info '
                                 '(Copy system info).' % SUPPORT_CONTACT) if SUPPORT_CONTACT else
                                'When reporting a problem, attach the log file and the system info.')
        hint.setObjectName('hint')
        hint.setWordWrap(True)
        form.addRow(hint)
        return self._page(form)


    @staticmethod
    def _page(form):
        page = QtWidgets.QWidget()
        page.setLayout(form)
        form.setContentsMargins(14, 14, 14, 14)
        return page

    @staticmethod
    def _slider_row(low, high, suffix):
        row = QtWidgets.QHBoxLayout()
        slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        slider.setRange(low, high)
        spin = QtWidgets.QSpinBox()
        spin.setRange(low, high)
        spin.setSuffix(suffix)
        slider.valueChanged.connect(spin.setValue)
        spin.valueChanged.connect(slider.setValue)
        row.addWidget(slider, 1)
        row.addWidget(spin)
        return row, spin

    def _color_button(self, empty_text):
        button = QtWidgets.QPushButton()
        button.color = ''
        button.empty_text = empty_text

        def pick():
            color = QtWidgets.QColorDialog.getColor(QtGui.QColor(button.color or _canvas_bg()), self, 'Color')
            if color.isValid():
                self._set_button_color(button, color.name())
                self.changed.emit()

        button.clicked.connect(pick)
        return button

    def _with_reset(self, button):
        row = QtWidgets.QHBoxLayout()
        reset = QtWidgets.QPushButton('Reset')
        reset.setObjectName('flat')

        def clear():
            self._set_button_color(button, '')
            self.changed.emit()

        reset.clicked.connect(clear)
        row.addWidget(button, 1)
        row.addWidget(reset)
        return row

    @staticmethod
    def _set_button_color(button, color):
        button.color = color
        if color:
            text_color = '#000000' if QtGui.QColor(color).lightness() > 140 else '#ffffff'
            button.setText(color)
            button.setStyleSheet('QPushButton { background: %s; color: %s; }' % (color, text_color))
        else:
            button.setText(button.empty_text or '')
            button.setStyleSheet('')

    @staticmethod
    def _select_data(combo, value):
        index = combo.findData(value)
        combo.setCurrentIndex(max(0, index))

    def _fill(self, values):
        self._select_data(self.theme, values['theme'])
        self._set_button_color(self.canvas_bg, values['canvas_bg'])
        self._set_button_color(self.accent, values['accent'])
        self._select_data(self.grid_style, values['grid_style'])
        self.grid_default.setChecked(values['grid_default'])
        self.grid.setValue(values['grid_size'])
        self.corner.setValue(values['image_corner'])
        self.minimap_visible.setChecked(values['minimap_visible'])
        self._select_data(self.minimap_corner, values['minimap_corner'])
        self._select_data(self.minimap_size, values['minimap_size'])
        family = values['font_family']
        self.system_font.setChecked(not family)
        self.font.setEnabled(bool(family))
        if family:
            self.font.setCurrentFont(QtGui.QFont(family))
        self.font_size.setValue(values['font_size'])
        self._kept = {key: values[key] for key in self.HIDDEN_KEYS}
        self.changed.emit()

    def values(self):
        return dict(self._kept, **{
            'theme': self.theme.currentData(),
            'canvas_bg': self.canvas_bg.color,
            'accent': self.accent.color or CanvasSettings.DEFAULTS['accent'],
            'grid_style': self.grid_style.currentData(),
            'grid_default': self.grid_default.isChecked(),
            'grid_size': self.grid.value(),
            'image_corner': self.corner.value(),
            'minimap_visible': self.minimap_visible.isChecked(),
            'minimap_corner': self.minimap_corner.currentData(),
            'minimap_size': self.minimap_size.currentData(),
            'font_family': '' if self.system_font.isChecked() else self.font.currentFont().family(),
            'font_size': self.font_size.value(),
        })


class SearchBar(QtWidgets.QFrame):
    pass


    def __init__(self, view, parent=None):
        super().__init__(parent or view)
        self.view = view
        self.matches = []
        self.index = -1
        self.setObjectName('searchBar')
        self.apply_theme()
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        self.edit = QtWidgets.QLineEdit()
        self.edit.setPlaceholderText('Search notes and frames…')
        self.edit.setFixedWidth(260)
        self.edit.textChanged.connect(self._update_matches)
        self.edit.installEventFilter(self)
        self.count = QtWidgets.QLabel('')
        self.count.setMinimumWidth(70)
        layout.addWidget(self.edit)
        layout.addWidget(self.count)
        for text, tip, cb in (('↑', 'Previous (Shift+Enter)', lambda: self.step(-1)),
                              ('↓', 'Next (Enter)', lambda: self.step(1)),
                              ('✕', 'Close (Esc)', self.close_bar)):
            btn = QtWidgets.QPushButton(text)
            btn.setObjectName('flat')
            btn.setToolTip(tip)
            btn.clicked.connect(cb)
            layout.addWidget(btn)
        self.hide()

    def apply_theme(self):
        self.setStyleSheet(_style("QFrame#searchBar { background: %(panel)s; border: 1px solid %(panel_border)s; "
                                  "border-radius: 8px; }") + _panel_style())

    def open_bar(self):
        self.show()
        self.raise_()
        self.place()
        self.edit.setFocus()
        self.edit.selectAll()
        self._update_matches(self.edit.text())

    def close_bar(self):
        self.hide()
        self.view.setFocus()

    def place(self):
        self.adjustSize()
        self.move((self.parentWidget().width() - self.width()) // 2, 12)

    def _update_matches(self, text):
        text = text.strip().lower()
        self.matches = []
        self.index = -1
        if not text:
            self.count.setText('')
            return
        for item in self.view.scene().canvas_items():
            if isinstance(item, TextNode):
                haystack = item.toPlainText()
            elif isinstance(item, FrameNode):
                haystack = item.title
            else:
                continue
            if text in haystack.lower():
                self.matches.append(item)

        self.matches.sort(key=lambda i: (round(i.sceneBoundingRect().top() / 50.0), i.sceneBoundingRect().left()))
        if self.matches:
            self.step(1)
        else:
            self.count.setText('No results')

    def step(self, direction):
        if not self.matches:
            return
        self.index = (self.index + direction) % len(self.matches)
        self.view.reveal(self.matches[self.index])
        self.count.setText('%d / %d' % (self.index + 1, len(self.matches)))

    def eventFilter(self, obj, event):
        if obj is self.edit and event.type() == QtCore.QEvent.KeyPress:
            if event.key() == QtCore.Qt.Key_Escape:
                self.close_bar()
                return True
            if event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
                self.step(-1 if event.modifiers() & QtCore.Qt.ShiftModifier else 1)
                return True
        return super().eventFilter(obj, event)


class TutorialCard(QtWidgets.QFrame):
    def __init__(self, parent):
        super().__init__(parent)
        self.setObjectName('tutorialCard')
        self.setFixedWidth(330)
        self.setStyleSheet(_style("QFrame#tutorialCard { background: %(panel)s; border: 1px solid %(accent)s; "
                                  "border-radius: 10px; }") + _panel_style())
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)
        top = QtWidgets.QHBoxLayout()
        self.title = QtWidgets.QLabel()
        self.title.setStyleSheet(_style("color: %(text)s; font-size: 15px; font-weight: bold;"))
        self.close_btn = QtWidgets.QPushButton('✕')
        self.close_btn.setObjectName('flat')
        self.close_btn.setToolTip('Close tutorial (Esc)')
        top.addWidget(self.title)
        top.addStretch()
        top.addWidget(self.close_btn)
        self.text = QtWidgets.QLabel()
        self.text.setWordWrap(True)
        bottom = QtWidgets.QHBoxLayout()
        self.counter = QtWidgets.QLabel()
        self.counter.setStyleSheet(_style("color: %(caption)s; font-size: 12px;"))
        self.back_btn = QtWidgets.QPushButton('Back')
        self.next_btn = QtWidgets.QPushButton('Next')
        self.next_btn.setObjectName('primary')
        bottom.addWidget(self.counter)
        bottom.addStretch()
        bottom.addWidget(self.back_btn)
        bottom.addWidget(self.next_btn)
        layout.addLayout(top)
        layout.addWidget(self.text)
        layout.addLayout(bottom)

    def set_content(self, title, text, index, total):
        self.title.setText(title)
        self.text.setText(text)
        self.counter.setText('%d of %d' % (index + 1, total))
        self.back_btn.setEnabled(index > 0)
        self.next_btn.setText('Finish' if index == total - 1 else 'Next')
        self.adjustSize()


class TutorialOverlay(QtWidgets.QWidget):
    pass



    def __init__(self, window, steps):
        super().__init__(window)
        self.window_widget = window
        self.steps = steps
        self.index = 0
        self._hole = QtCore.QRectF()
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.card = TutorialCard(self)
        self.card.back_btn.clicked.connect(self.back)
        self.card.next_btn.clicked.connect(self.next)
        self.card.close_btn.clicked.connect(self.finish)
        self._hole_anim = QtCore.QVariantAnimation(self)
        self._hole_anim.setDuration(350)
        self._hole_anim.setEasingCurve(QtCore.QEasingCurve.OutCubic)
        self._hole_anim.valueChanged.connect(self._set_hole)
        self._card_anim = QtCore.QPropertyAnimation(self.card, b"pos", self)
        self._card_anim.setDuration(350)
        self._card_anim.setEasingCurve(QtCore.QEasingCurve.OutCubic)
        window.installEventFilter(self)

    def start(self):
        self.setGeometry(self.window_widget.rect())
        self.show()
        self.raise_()
        self.setFocus()
        self._go(0, animate=False)

    def _target_rect(self, step):
        widget = step['widget']()
        top_left = widget.mapTo(self.window_widget, QtCore.QPoint(0, 0))
        return QtCore.QRectF(QtCore.QRect(top_left, widget.size())).adjusted(-8, -8, 8, 8)

    def _card_pos(self, hole):
        cw, ch = self.card.width(), self.card.height()
        gap, pad = 14, 10
        if hole.bottom() + gap + ch <= self.height() - pad:
            y = hole.bottom() + gap
        else:
            y = hole.top() - gap - ch
        x = hole.center().x() - cw / 2
        x = max(pad, min(x, self.width() - cw - pad))
        y = max(pad, min(y, self.height() - ch - pad))
        return QtCore.QPoint(int(x), int(y))

    def _go(self, index, animate=True):
        self.index = index
        step = self.steps[index]
        target = self._target_rect(step)
        self.card.set_content(step['title'], step['text'], index, len(self.steps))
        card_pos = self._card_pos(target)
        if animate and not self._hole.isNull():
            self._hole_anim.stop()
            self._hole_anim.setStartValue(QtCore.QRectF(self._hole))
            self._hole_anim.setEndValue(target)
            self._hole_anim.start()
            self._card_anim.stop()
            self._card_anim.setStartValue(self.card.pos())
            self._card_anim.setEndValue(card_pos)
            self._card_anim.start()
        else:
            self._set_hole(target)
            self.card.move(card_pos)

    def _set_hole(self, rect):
        self._hole = QtCore.QRectF(rect)
        self.update()

    def next(self):
        if self.index < len(self.steps) - 1:
            self._go(self.index + 1)
        else:
            self.finish()

    def back(self):
        if self.index > 0:
            self._go(self.index - 1)

    def finish(self):
        self.window_widget.removeEventFilter(self)
        self.hide()
        self.deleteLater()
        self.window_widget.setFocus()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        shade = QtGui.QPainterPath()
        shade.addRect(QtCore.QRectF(self.rect()))
        shade.addRoundedRect(self._hole, 10, 10)
        painter.fillPath(shade, QtGui.QColor(0, 0, 0, 150))
        painter.setPen(QtGui.QPen(QtGui.QColor(*GLOW_COLOR), 2))
        painter.setBrush(QtCore.Qt.NoBrush)
        painter.drawRoundedRect(self._hole, 10, 10)

    def mousePressEvent(self, event):
        event.accept()

    def keyPressEvent(self, event):
        key = event.key()
        if key == QtCore.Qt.Key_Escape:
            self.finish()
        elif key in (QtCore.Qt.Key_Right, QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
            self.next()
        elif key == QtCore.Qt.Key_Left:
            self.back()
        event.accept()

    def eventFilter(self, obj, event):
        if obj is self.window_widget and event.type() == QtCore.QEvent.Resize:
            self.setGeometry(self.window_widget.rect())
            self._hole_anim.stop()
            self._card_anim.stop()
            self._go(self.index, animate=False)
        return False
