pass

from ._link import pull
pull(globals())




_SOFT_CACHE = {}
_SOFT_SCALE = 0.25


def _soft_pixmap(w, h, radius, blur, rgba):
    pass
    key = (int(w), int(h), int(radius), int(blur), rgba)
    cached = _SOFT_CACHE.get(key)
    if cached is not None:
        return cached
    if len(_SOFT_CACHE) > 64:
        _SOFT_CACHE.clear()
    s = _SOFT_SCALE
    margin = blur * 2
    sw, sh = max(1, int((w + 2 * margin) * s)), max(1, int((h + 2 * margin) * s))
    image = QtGui.QImage(sw, sh, QtGui.QImage.Format_ARGB32_Premultiplied)
    image.fill(QtCore.Qt.transparent)
    path = QtGui.QPainterPath()
    path.addRoundedRect(QtCore.QRectF(margin * s, margin * s, w * s, h * s), radius * s, radius * s)
    tmp_scene = QtWidgets.QGraphicsScene()
    shape = QtWidgets.QGraphicsPathItem(path)
    shape.setBrush(QtGui.QColor(*rgba))
    shape.setPen(QtGui.QPen(QtCore.Qt.NoPen))
    blur_effect = QtWidgets.QGraphicsBlurEffect()
    blur_effect.setBlurRadius(blur * s)
    shape.setGraphicsEffect(blur_effect)
    tmp_scene.addItem(shape)
    painter = QtGui.QPainter(image)
    tmp_scene.render(painter, QtCore.QRectF(0, 0, sw, sh), QtCore.QRectF(0, 0, sw, sh))
    painter.end()
    result = (QtGui.QPixmap.fromImage(image), margin)
    _SOFT_CACHE[key] = result
    return result


class HoverHalo(QtWidgets.QGraphicsItem):
    pass



    def __init__(self, parent):
        super().__init__(parent)
        self.setFlag(QtWidgets.QGraphicsItem.ItemStacksBehindParent)
        self.setAcceptedMouseButtons(QtCore.Qt.NoButton)
        self.value = 0.0
        self._rect = QtCore.QRectF()
        self._glow = None
        self._shadow = None
        self.setVisible(False)

    def refresh(self):
        parent = self.parentItem()
        rect = parent.content_rect()
        if rect == self._rect and self._glow is not None and getattr(self, '_color', None) == tuple(GLOW_COLOR):
            return
        self._color = tuple(GLOW_COLOR)
        self.prepareGeometryChange()
        self._rect = rect
        radius = parent.corner_radius()
        self._glow = _soft_pixmap(rect.width(), rect.height(), radius, GLOW_BLUR, (*GLOW_COLOR, GLOW_ALPHA))
        self._shadow = _soft_pixmap(rect.width(), rect.height(), radius, SHADOW_BLUR, (0, 0, 0, SHADOW_ALPHA))

    def set_value(self, value):
        self.value = value
        self.setVisible(value > 0)
        self.update()

    def boundingRect(self):
        m = max(GLOW_BLUR, SHADOW_BLUR) * 2 + SHADOW_OFFSET
        return self._rect.adjusted(-m, -m, m, m)

    def shape(self):
        return QtGui.QPainterPath()

    def paint(self, painter, option, widget):
        if self.value <= 0 or self._glow is None:
            return
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        for (pixmap, margin), offset in ((self._shadow, SHADOW_OFFSET * self.value), (self._glow, 0)):
            painter.setOpacity(self.value)
            target = self._rect.adjusted(-margin, -margin, margin, margin).translated(0, offset)
            painter.drawPixmap(target, pixmap, QtCore.QRectF(pixmap.rect()))


class HoverEffect(object):
    pass


    def __init__(self, item):
        self.item = item
        self.halo = None
        self.timeline = QtCore.QTimeLine(160)
        self.timeline.setUpdateInterval(16)
        self.timeline.valueChanged.connect(self._set)
        self.timeline.finished.connect(self._on_finished)

    def enter(self):
        if _mouse_pressed() or SETTINGS['hover_strength'] <= 0:
            return
        try:


            if self.item.isSelected():
                return
            if self.halo is None:
                self.halo = HoverHalo(self.item)
            self.halo.refresh()
        except RuntimeError:
            return
        self._run(QtCore.QTimeLine.Forward)

    def leave(self):
        if self.halo is not None and (self.halo.value > 0 or self.timeline.state() == QtCore.QTimeLine.Running):
            self._run(QtCore.QTimeLine.Backward)

    def suspend(self):
        self.timeline.stop()
        self._set(0.0)

    def resume(self):
        try:
            if self.item.isUnderMouse():
                self.enter()
        except RuntimeError:
            pass

    def _run(self, direction):
        self.timeline.setDirection(direction)
        if self.timeline.state() != QtCore.QTimeLine.Running:
            self.timeline.start()

    def _on_finished(self):
        if self.timeline.direction() == QtCore.QTimeLine.Backward:
            self._set(0.0)

    def _set(self, value):
        try:
            value *= SETTINGS['hover_strength'] / 100.0
            if self.halo is not None:
                self.halo.set_value(value)
            s = 1.0 + (HOVER_SCALE - 1.0) * value
            if value <= 0:
                self.item.setTransform(QtGui.QTransform())
            else:
                c = self.item.boundingRect().center()
                self.item.setTransform(QtGui.QTransform().translate(c.x(), c.y()).scale(s, s).translate(-c.x(), -c.y()))
        except RuntimeError:
            self.timeline.stop()


_GEOMETRY_CHANGES = (
    QtWidgets.QGraphicsItem.ItemPositionHasChanged,
    QtWidgets.QGraphicsItem.ItemScaleHasChanged,
    QtWidgets.QGraphicsItem.ItemRotationHasChanged,
    QtWidgets.QGraphicsItem.ItemTransformHasChanged,
)




class LinkNode(QtWidgets.QGraphicsPathItem):
    LABEL_FONT_PX = 13

    HANDLE_PX = 6

    def __init__(self, item_start, item_end, color=LINK_COLOR, width=3, uid=None, start_side='auto', end_side='auto',
                 label='', dash='solid', arrows=0, flow=False, points=None):
        super().__init__()
        self.uid = uid or _new_id()
        self.flow = flow

        self.waypoints = [QtCore.QPointF(x, y) for x, y in (points or [])]
        self._drag_index = None
        self._drag_end = None
        self._last_centers = None
        self._flow_phase = None
        self._flow_last = []
        self._drag_end_pos = QtCore.QPointF()
        self._trimmed = None
        self.item_start = item_start
        self.item_end = item_end
        self.start_side = start_side
        self.end_side = end_side
        self.color_hex = color
        self.pen_width = width
        self.dash = dash
        self.arrows = arrows
        self.label = label
        self._shape = None
        self.setZValue(-1)

        self.setFlag(QtWidgets.QGraphicsItem.ItemIsSelectable)
        self.setPen(_make_pen(self.color_hex, self.pen_width, self.dash))
        item_start.links.append(self)
        item_end.links.append(self)
        self.update_path()

    def set_style(self, color=None, width=None, dash=None, arrows=None):
        self.prepareGeometryChange()
        if color is not None:
            self.color_hex = color
        if width is not None:
            self.pen_width = width
        if dash is not None:
            self.dash = dash
        if arrows is not None:
            self.arrows = arrows
        self.setPen(_make_pen(self.color_hex, self.pen_width, self.dash))
        self._shape = None
        self._trimmed = None
        self.update()

    def _head_size(self):
        return max(10.0, self.pen_width * 3.2)

    def _drawn_path(self):
        pass

        if self.arrows <= 0:
            return self.path()
        if self._trimmed is None:
            cut = self._head_size() * 0.75
            self._trimmed = _trimmed_path(self.path(), cut if self.arrows >= 2 else 0.0, cut)
        return self._trimmed

    def _arrow_heads(self):
        path = self.path()
        if self.arrows <= 0 or path.isEmpty():
            return []
        size = self._head_size()
        heads = []
        length = path.length()

        back_len = min(size * 0.6, length * 0.5)
        ends = [(1.0, path.percentAtLength(length - back_len))]
        if self.arrows >= 2:
            ends.append((0.0, path.percentAtLength(back_len)))
        for tip_t, back_t in ends:
            tip = path.pointAtPercent(tip_t)
            back = path.pointAtPercent(back_t)
            angle = math.atan2(tip.y() - back.y(), tip.x() - back.x())
            left = tip - QtCore.QPointF(math.cos(angle - math.pi / 7) * size, math.sin(angle - math.pi / 7) * size)
            right = tip - QtCore.QPointF(math.cos(angle + math.pi / 7) * size, math.sin(angle + math.pi / 7) * size)
            heads.append(QtGui.QPolygonF([tip, left, right]))
        return heads

    def detach(self):
        for item in (self.item_start, self.item_end):
            if item is not None and self in item.links:
                item.links.remove(self)

    def update_path(self):
        if self.item_start is None or self.item_end is None:
            return
        self._shape = None
        self._trimmed = None
        self.prepareGeometryChange()
        r1, s1 = _link_rect(self.item_start), self.start_side
        r2, s2 = _link_rect(self.item_end), self.end_side


        centers = (r1.center(), r2.center())
        last = self._last_centers
        if (last is not None and self.waypoints and self._drag_end is None and self._drag_index is None
                and self.item_start.isSelected() and self.item_end.isSelected()):
            shift = ((centers[0] - last[0]) + (centers[1] - last[1])) / 2.0
            if abs(shift.x()) > 1e-9 or abs(shift.y()) > 1e-9:
                self.waypoints = [p + shift for p in self.waypoints]
        self._last_centers = centers

        if self._drag_end == 'start':
            r1, s1 = QtCore.QRectF(self._drag_end_pos, QtCore.QSizeF(0, 0)), 'auto'
        elif self._drag_end == 'end':
            r2, s2 = QtCore.QRectF(self._drag_end_pos, QtCore.QSizeF(0, 0)), 'auto'
        self.setPath(_link_path(r1, s1, r2, s2, self.waypoints))


    def _segment_mids(self):
        pass
        return _path_mids(self.path())

    def _ends(self):
        path = self.path()
        if path.isEmpty():
            return []
        return [path.pointAtPercent(0.0), path.pointAtPercent(1.0)]

    def _handle_at(self, pos):
        pass

        if not self.isSelected():
            return None


        r = (self.HANDLE_PX + 4) / _view_lod(self)
        candidates = [(QtCore.QLineF(p, pos).length(), ('end', role)) for role, p in zip(('start', 'end'), self._ends())]
        candidates += [(QtCore.QLineF(p, pos).length(), ('point', i)) for i, p in enumerate(self.waypoints)]
        candidates += [(QtCore.QLineF(p, pos).length(), ('mid', i)) for i, p in enumerate(self._segment_mids())]
        candidates = [c for c in candidates if c[0] <= r]
        return min(candidates, key=lambda c: c[0])[1] if candidates else None

    def _snap(self, p):
        scene = self.scene()
        if isinstance(scene, CanvasScene) and scene.snap_to_grid:
            g = SETTINGS['grid_size']
            return QtCore.QPointF(round(p.x() / g) * g, round(p.y() / g) * g)
        return QtCore.QPointF(p)

    def remove_point_at(self, scene_pos):
        hit = self._handle_at(scene_pos)
        if hit is None or hit[0] != 'point':
            return False
        del self.waypoints[hit[1]]
        self.update_path()
        return True

    def itemChange(self, change, value):
        if change == QtWidgets.QGraphicsItem.ItemSelectedChange:
            self.prepareGeometryChange()
            self._shape = None
        return super().itemChange(change, value)

    def mousePressEvent(self, event):
        hit = self._handle_at(event.pos()) if event.button() == QtCore.Qt.LeftButton else None
        if hit is None:
            super().mousePressEvent(event)
            return
        kind, index = hit
        if kind == 'end':
            self._drag_end, self._drag_end_pos = index, QtCore.QPointF(event.pos())
            self.update_path()
            event.accept()
            return
        if kind == 'mid':
            self.waypoints.insert(index, self._snap(event.pos()))
        self._drag_index = index
        self.update_path()
        event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_end is not None:
            self._drag_end_pos = QtCore.QPointF(event.pos())
            self.update_path()
            event.accept()
            return
        if self._drag_index is None:
            super().mouseMoveEvent(event)
            return
        self.waypoints[self._drag_index] = self._snap(event.pos())
        self.update_path()
        event.accept()

    def _finish_end_drag(self, scene_pos):
        pass
        role, self._drag_end = self._drag_end, None
        view = _first_view(self)
        keep = self.item_end if role == 'start' else self.item_start
        old = self.item_start if role == 'start' else self.item_end
        target = view._linkable_at(view.mapFromScene(scene_pos), exclude=keep) if view is not None else None
        changed = False
        if target is not None and target is not old:
            if any((l.item_start is keep and l.item_end is target) or (l.item_start is target and l.item_end is keep)
                   for l in keep.links if l is not self):
                if view is not None:
                    view.show_toast('These are already linked')
            else:
                if self in old.links:
                    old.links.remove(self)
                target.links.append(self)
                side = _side_at(_link_rect(target), scene_pos)
                if role == 'start':
                    self.item_start, self.start_side = target, side
                else:
                    self.item_end, self.end_side = target, side
                changed = True
        elif target is old:
            side = _side_at(_link_rect(old), scene_pos)
            if role == 'start':
                self.start_side = side
            else:
                self.end_side = side
            changed = True
        self.update_path()
        return changed

    def mouseReleaseEvent(self, event):
        if self._drag_end is not None:
            if self._finish_end_drag(event.scenePos()):
                scene = self.scene()
                if isinstance(scene, CanvasScene):
                    scene.canvas_changed.emit()
            event.accept()
            return
        if self._drag_index is None:
            super().mouseReleaseEvent(event)
            return
        self._drag_index = None
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.canvas_changed.emit()
        event.accept()

    def set_label(self, text):
        self.prepareGeometryChange()
        self.label = text
        self._shape = None
        self.update()

    def _label_font(self):
        return _ui_font(self.LABEL_FONT_PX, bold=True)

    def _label_rect(self):
        if not self.label:
            return QtCore.QRectF()
        metrics = QtGui.QFontMetricsF(self._label_font())
        w = metrics.horizontalAdvance(self.label) if hasattr(metrics, 'horizontalAdvance') else metrics.width(self.label)
        rect = QtCore.QRectF(0, 0, w + 16, metrics.height() + 8)
        rect.moveCenter(self.path().pointAtPercent(0.5))
        return rect

    def boundingRect(self):
        m = max(12.0, self.pen_width * 3.5)
        if self.isSelected():
            m = max(m, 60.0)
        return super().boundingRect().adjusted(-m, -m, m, m).united(self._label_rect())

    def shape(self):
        if self._shape is None:
            shape = _stroke_shape(self.path(), self.pen_width)
            if self.label:
                shape.addRect(self._label_rect())
            self._shape = shape
        if not self.isSelected():
            return self._shape
        shape = QtGui.QPainterPath(self._shape)
        r = (self.HANDLE_PX + 4) / _view_lod(self)
        for p in self.waypoints + self._segment_mids() + self._ends():
            shape.addEllipse(p, r, r)
        return shape

    def paint(self, painter, option, widget):
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        if self.isSelected():
            glow = QtGui.QPen(QtGui.QColor(*GLOW_COLOR, 110), self.pen_width + 8, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap)
            painter.setPen(glow)
            painter.setBrush(QtCore.Qt.NoBrush)
            painter.drawPath(self._drawn_path())
        painter.setPen(self.pen())
        painter.setBrush(QtCore.Qt.NoBrush)
        painter.drawPath(self._drawn_path())
        heads = self._arrow_heads()
        if heads:
            painter.setPen(QtGui.QPen(QtGui.QColor(self.color_hex), 1, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin))
            painter.setBrush(QtGui.QColor(self.color_hex))
            for head in heads:
                painter.drawPolygon(head)
        if self.flow:
            self._paint_flow(painter)
        if self.isSelected():
            lod = QtWidgets.QStyleOptionGraphicsItem.levelOfDetailFromTransform(painter.worldTransform())
            _draw_point_handles(painter, self.waypoints, self._segment_mids(), lod, ends=self._ends())
        if not self.label:
            return
        rect = self._label_rect()
        painter.setPen(QtGui.QPen(QtGui.QColor(self.color_hex), 1.5))
        painter.setBrush(QtGui.QColor(_theme()['panel']))
        painter.drawRoundedRect(rect, rect.height() / 2, rect.height() / 2)
        painter.setFont(self._label_font())
        painter.setPen(QtGui.QColor(_theme()['text']))
        painter.drawText(rect, QtCore.Qt.AlignCenter, self.label)

    def _flow_halo(self):
        return max(0.9, self.pen_width * 0.3) * 2.8

    def _flow_points(self, phase):
        pass
        path = self.path()
        length = path.length()
        if length < 1:
            return []
        spacing = max(LINK_FLOW_SPACING, self.pen_width * 12)
        d = phase % spacing
        points = []
        while d < length:
            fade = max(0.0, min(1.0, d / spacing, (length - d) / spacing))
            points.append((path.pointAtPercent(path.percentAtLength(d)), fade))
            d += spacing
        return points

    def flow_update(self, phase):
        pass


        points = self._flow_points(phase)
        h = self._flow_halo() + 2
        for p in self._flow_last + [p for p, _ in points]:
            self.update(QtCore.QRectF(p.x() - h, p.y() - h, 2 * h, 2 * h))
        self._flow_phase = phase
        self._flow_last = [p for p, _ in points]

    def _paint_flow(self, painter):
        pass
        phase = self._flow_phase if self._flow_phase is not None else time.monotonic() * LINK_FLOW_SPEED
        halo = self._flow_halo()
        core = QtGui.QColor(self.color_hex).lighter(170)
        painter.setPen(QtCore.Qt.NoPen)
        for p, fade in self._flow_points(phase):
            gradient = QtGui.QRadialGradient(p, halo)
            for stop, color, alpha in ((0.0, QtGui.QColor('#ffffff'), 255), (0.3, core, 230), (1.0, core, 0)):
                c = QtGui.QColor(color)
                c.setAlpha(int(alpha * fade))
                gradient.setColorAt(stop, c)
            painter.setBrush(QtGui.QBrush(gradient))
            painter.drawEllipse(p, halo, halo)

    def to_dict(self):
        d = {'id': self.uid, 'from': self.item_start.uid, 'to': self.item_end.uid,
             'from_side': self.start_side, 'to_side': self.end_side,
             'color': self.color_hex, 'width': self.pen_width}
        if self.label:
            d['label'] = self.label
        if self.dash != 'solid':
            d['dash'] = self.dash
        if self.arrows:
            d['arrows'] = self.arrows
        if self.flow:
            d['flow'] = True
        if self.waypoints:
            d['pts'] = [[round(p.x(), 2), round(p.y(), 2)] for p in self.waypoints]
        return d




_OPPOSITE_CORNER = {'tl': 'bottomRight', 'tr': 'bottomLeft', 'bl': 'topRight', 'br': 'topLeft'}
_CORNER_POINT = {'tl': 'topLeft', 'tr': 'topRight', 'bl': 'bottomLeft', 'br': 'bottomRight'}


def _style_handle(handle, corner, color):
    size = HANDLE_SIZE
    handle.setRect(-size / 2, -size / 2, size, size)
    handle.setBrush(QtGui.QBrush(QtGui.QColor(color)))
    handle.setPen(QtGui.QPen(QtCore.Qt.white, 2))
    handle.setZValue(10)
    handle.setFlag(QtWidgets.QGraphicsItem.ItemIgnoresTransformations)
    handle.setCursor(QtCore.Qt.SizeFDiagCursor if corner in ('tl', 'br') else QtCore.Qt.SizeBDiagCursor)


class RotateHandle(QtWidgets.QGraphicsEllipseItem):
    OFFSET = 30

    def __init__(self, parent):
        super().__init__(parent)
        size = HANDLE_SIZE

        self.setRect(-size / 2, -size / 2 - self.OFFSET, size, size)
        self.setBrush(QtGui.QBrush(QtGui.QColor("#00b894")))
        self.setPen(QtGui.QPen(QtCore.Qt.white, 2))
        self.setZValue(10)
        self.setFlag(QtWidgets.QGraphicsItem.ItemIgnoresTransformations)
        self.setCursor(QtCore.Qt.OpenHandCursor)

    def mousePressEvent(self, event):
        self.setCursor(QtCore.Qt.ClosedHandCursor)
        parent = self.parentItem()
        parent.hover.suspend()

        _set_origin_keep_place(parent, _grip_rect(parent).center())
        self._start_angle = parent.rotation()
        self._center = parent.mapToScene(_grip_rect(parent).center())
        self._start_pos = event.scenePos()
        event.accept()

    def mouseMoveEvent(self, event):
        line1 = QtCore.QLineF(self._center, self._start_pos)
        line2 = QtCore.QLineF(self._center, event.scenePos())
        new_angle = self._start_angle - line1.angleTo(line2)
        if event.modifiers() & QtCore.Qt.ShiftModifier:
            new_angle = round(new_angle / 45.0) * 45.0
        elif event.modifiers() & QtCore.Qt.ControlModifier:
            new_angle = round(new_angle / 15.0) * 15.0
        self.parentItem().setRotation(new_angle)
        event.accept()

    def mouseReleaseEvent(self, event):
        self.setCursor(QtCore.Qt.OpenHandCursor)
        self.parentItem().hover.resume()
        event.accept()

    def mouseDoubleClickEvent(self, event):
        self.parentItem().setRotation(0)
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.canvas_changed.emit()
        event.accept()


class ResizeHandle(QtWidgets.QGraphicsRectItem):
    def __init__(self, parent, corner):
        super().__init__(parent)
        self.corner = corner
        _style_handle(self, corner, "#ff4757")

    def _anchor_in_scene(self):
        parent = self.parentItem()
        return parent.mapToScene(getattr(_grip_rect(parent), _OPPOSITE_CORNER[self.corner])())

    def mousePressEvent(self, event):
        parent = self.parentItem()
        parent.hover.suspend()
        self._start_pos = event.scenePos()
        self._start_scale = parent.scale()
        self._anchor_pt = self._anchor_in_scene()
        self._corner0 = parent.mapToScene(getattr(_grip_rect(parent), _CORNER_POINT[self.corner])())
        event.accept()

    def mouseMoveEvent(self, event):
        parent = self.parentItem()
        orig_dist = QtCore.QLineF(self._anchor_pt, self._start_pos).length()
        new_dist = QtCore.QLineF(self._anchor_pt, event.scenePos()).length()
        if orig_dist > 0:
            scale = self._start_scale * (new_dist / orig_dist)
            view = _first_view(self)
            if view is not None and parent.rotation() == 0:

                scale = view.snap_resize(parent, self._anchor_pt, self._corner0, self._start_scale, scale)
            parent.setScale(max(0.05, min(scale, 50.0)))

            parent.setPos(parent.pos() + (self._anchor_pt - self._anchor_in_scene()))
        event.accept()

    def mouseReleaseEvent(self, event):
        self.parentItem().hover.resume()
        view = _first_view(self)
        if view is not None:
            view.clear_guides()
        event.accept()


def _grip_rect(item):
    pass
    return item.grip_rect() if hasattr(item, 'grip_rect') else item.boundingRect()


class WidthHandle(QtWidgets.QGraphicsRectItem):
    pass

    def __init__(self, parent):
        super().__init__(parent)
        self.setRect(-4, -11, 8, 22)
        self.setBrush(QtGui.QBrush(QtGui.QColor(*GLOW_COLOR)))
        self.setPen(QtGui.QPen(QtCore.Qt.white, 1.5))
        self.setZValue(10)
        self.setFlag(QtWidgets.QGraphicsItem.ItemIgnoresTransformations)
        self.setCursor(QtCore.Qt.SizeHorCursor)
        self.setToolTip('Drag to set the text width')

    def mousePressEvent(self, event):
        self.parentItem().hover.suspend()
        event.accept()

    def mouseMoveEvent(self, event):
        parent = self.parentItem()
        x = parent.mapFromScene(event.scenePos()).x()
        parent.set_text_width(max(60.0, x))
        event.accept()

    def mouseReleaseEvent(self, event):
        self.parentItem().hover.resume()
        event.accept()


class ItemGrips(object):
    pass

    def __init__(self, parent, rotate, width_handle=False):
        self.parent = parent
        self.corners = [ResizeHandle(parent, c) for c in ('tl', 'tr', 'bl', 'br')]
        self.rotator = RotateHandle(parent) if rotate else None
        self.width_handle = WidthHandle(parent) if width_handle else None
        self.update()
        self.set_visible(False)

    def _all(self):
        return self.corners + [h for h in (self.rotator, self.width_handle) if h is not None]

    def update(self):
        rect = _grip_rect(self.parent)
        for handle, point in zip(self.corners, (rect.topLeft(), rect.topRight(), rect.bottomLeft(), rect.bottomRight())):
            handle.setPos(point)
        if self.rotator:
            self.rotator.setPos(rect.center().x(), rect.top())
        if self.width_handle:
            self.width_handle.setPos(rect.right(), rect.center().y())

    def set_visible(self, visible):
        for handle in self._all():
            handle.setVisible(visible)


class GroupResizeHandle(QtWidgets.QGraphicsRectItem):
    pass

    def __init__(self, box, corner):
        super().__init__(box)
        self.corner = corner
        _style_handle(self, corner, LINK_COLOR)

    def mousePressEvent(self, event):
        box = self.parentItem()
        self._anchor = getattr(box.box_rect, _OPPOSITE_CORNER[self.corner])()
        self._start_pos = event.scenePos()
        self._start = []
        for item in box.targets:
            if _is_locked(item):
                continue
            hover = getattr(item, 'hover', None)
            if hover is not None:
                hover.suspend()
            origin = item.transformOriginPoint()

            self._start.append((item, item.scale(), item.mapToScene(origin), origin))
        self._k_range = (max([0.05 / s for _, s, _, _ in self._start] or [0.05]),
                         min([50.0 / s for _, s, _, _ in self._start] or [50.0]))
        event.accept()

    def mouseMoveEvent(self, event):
        d0 = QtCore.QLineF(self._anchor, self._start_pos).length()
        if d0 <= 0:
            return
        k = QtCore.QLineF(self._anchor, event.scenePos()).length() / d0
        k = max(self._k_range[0], min(k, self._k_range[1]))
        for item, s0, origin_scene, origin_local in self._start:
            item.setScale(s0 * k)
            item.setPos(self._anchor + (origin_scene - self._anchor) * k - origin_local)
        event.accept()

    def mouseReleaseEvent(self, event):
        for item, _, _, _ in self._start:
            hover = getattr(item, 'hover', None)
            if hover is not None:
                hover.resume()
        event.accept()


class SelectionBox(QtWidgets.QGraphicsItem):
    pass

    def __init__(self):
        super().__init__()
        self.setZValue(1e6)
        self.setAcceptedMouseButtons(QtCore.Qt.NoButton)
        self.box_rect = QtCore.QRectF()
        self.targets = []
        self.corners = [GroupResizeHandle(self, c) for c in ('tl', 'tr', 'bl', 'br')]

    def refresh(self, targets):
        self.targets = targets
        rect = _items_rect(targets)
        self.prepareGeometryChange()
        self.box_rect = rect
        for handle, point in zip(self.corners, (rect.topLeft(), rect.topRight(), rect.bottomLeft(), rect.bottomRight())):
            handle.setPos(point)

    def boundingRect(self):
        return self.box_rect.adjusted(-2, -2, 2, 2) if not self.box_rect.isNull() else QtCore.QRectF()

    def shape(self):
        return QtGui.QPainterPath()

    def paint(self, painter, option, widget):
        painter.setPen(QtGui.QPen(QtGui.QColor(*GLOW_COLOR), 0, QtCore.Qt.DashLine))
        painter.setBrush(QtCore.Qt.NoBrush)
        painter.drawRect(self.box_rect)
