pass

from ._link import pull
pull(globals())




def _order_mode_for(event):
    pass
    if not event.modifiers() & QtCore.Qt.ControlModifier:
        return None
    shift = bool(event.modifiers() & QtCore.Qt.ShiftModifier)
    if _key_is(event, ']'):
        return 'front' if shift else 'forward'
    if _key_is(event, '['):
        return 'back' if shift else 'backward'
    return None


_CURSOR_CACHE = {}


def _tool_cursor(tool):
    pass
    if tool in _CURSOR_CACHE:
        return _CURSOR_CACHE[tool]
    if tool in ('select',):
        cursor = QtGui.QCursor(QtCore.Qt.ArrowCursor)
    elif tool in ('arrow', 'rect', 'ellipse', 'frame', 'link'):
        cursor = QtGui.QCursor(QtCore.Qt.CrossCursor)
    else:
        size = 32
        pixmap = QtGui.QPixmap(size, size)
        pixmap.fill(QtCore.Qt.transparent)
        p = QtGui.QPainter(pixmap)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        hot = (size // 2, size // 2)
        if tool in ('pen', 'highlighter'):
            for color, width in (('#000000', 3), ('#ffffff', 1.5)):
                p.setPen(QtGui.QPen(QtGui.QColor(color), width))
                p.drawEllipse(QtCore.QPointF(16, 16), 5, 5)
            p.setPen(QtGui.QPen(QtGui.QColor('#ffffff'), 1))
            p.drawPoint(16, 16)
        elif tool == 'eraser':
            for color, width in (('#000000', 3), ('#ffffff', 1.5)):
                p.setPen(QtGui.QPen(QtGui.QColor(color), width))
                p.drawEllipse(QtCore.QPointF(16, 16), 11, 11)
        else:
            emoji = {'eyedropper': '💧', 'sticky': '📝', 'code': '⌨️'}.get(tool, '✚')
            if EMOJI_OK:
                p.setFont(_ui_font(20, kind='emoji'))
                p.drawText(QtCore.QRectF(8, 0, 24, 24), QtCore.Qt.AlignCenter, emoji)
            p.setPen(QtGui.QPen(QtGui.QColor('#ffffff'), 2))
            p.drawLine(1, 9, 9, 9)
            p.drawLine(5, 5, 5, 13)
            hot = (5, 9)
        p.end()
        cursor = QtGui.QCursor(pixmap, hot[0], hot[1])
    _CURSOR_CACHE[tool] = cursor
    return cursor


class Toast(QtWidgets.QLabel):
    pass

    def __init__(self, parent):
        super().__init__(parent)
        self.setAlignment(QtCore.Qt.AlignCenter)
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)
        self._effect = QtWidgets.QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self._effect)
        self._fade = QtCore.QPropertyAnimation(self._effect, b"opacity", self)
        self._fade.setDuration(250)
        self._hide_timer = QtCore.QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._fade_out)

        self._hidden_timer = QtCore.QTimer(self)
        self._hidden_timer.setSingleShot(True)
        self._hidden_timer.setInterval(260)
        self._hidden_timer.timeout.connect(self.hide)
        self.hide()

    def show_text(self, text, ms=1800):
        self.setStyleSheet(_style("QLabel { background: %(panel)s; color: %(text)s; border: 1px solid %(accent)s; "
                                  "border-radius: 14px; padding: 6px 16px; font-size: 13px; }"))
        self.setText(text)
        self.adjustSize()
        self.place()
        self.show()
        self.raise_()
        self._fade.stop()
        self._fade.setStartValue(self._effect.opacity() if self.isVisible() else 0.0)
        self._fade.setEndValue(1.0)
        self._fade.start()
        self._hidden_timer.stop()
        self._hide_timer.start(ms)

    def place(self):
        parent = self.parentWidget()
        self.move((parent.width() - self.width()) // 2, parent.height() - self.height() - 28)

    def _fade_out(self):
        self._fade.stop()
        self._fade.setStartValue(1.0)
        self._fade.setEndValue(0.0)
        self._fade.start()
        self._hidden_timer.start()


class AreaPicker(QtWidgets.QWidget):
    pass

    picked = QtCore.Signal(QtCore.QRect)

    def __init__(self, view):
        super().__init__(view.viewport())
        self._start = None
        self._rect = QtCore.QRect()
        self.setCursor(QtCore.Qt.CrossCursor)
        self.setMouseTracking(True)
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)

    def start(self):
        self.setGeometry(self.parentWidget().rect())
        self.show()
        self.raise_()
        self.setFocus()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        shade = QtGui.QColor(0, 0, 0, 120)
        full = QtGui.QPainterPath()
        full.addRect(QtCore.QRectF(self.rect()))
        rect = self._rect.normalized()
        if not rect.isEmpty():
            hole = QtGui.QPainterPath()
            hole.addRect(QtCore.QRectF(rect))
            full = full.subtracted(hole)
        painter.fillPath(full, shade)
        accent = QtGui.QColor(*GLOW_COLOR)
        painter.setFont(_ui_font(13))
        if not rect.isEmpty():
            painter.setPen(QtGui.QPen(accent, 2))
            painter.setBrush(QtCore.Qt.NoBrush)
            painter.drawRect(QtCore.QRectF(rect).adjusted(-1, -1, 1, 1))
            zoom = max(1e-6, self.parentWidget().parentWidget().transform().m11())
            text = '%d × %d' % (round(rect.width() / zoom), round(rect.height() / zoom))
            label = QtCore.QRectF(rect.left(), rect.bottom() + 6, 110, 22)
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(accent.darker(140))
            painter.drawRoundedRect(label, 5, 5)
            painter.setPen(QtGui.QColor('#ffffff'))
            painter.drawText(label, QtCore.Qt.AlignCenter, text)
        hint = QtCore.QRectF(0, 14, self.width(), 30)
        painter.setPen(QtGui.QColor('#ffffff'))
        painter.drawText(hint, QtCore.Qt.AlignCenter, 'Drag to choose the area to export  ·  Esc to cancel')

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self._start = event.pos()
            self._rect = QtCore.QRect(self._start, self._start)
            self.update()
        else:
            self.close()

    def mouseMoveEvent(self, event):
        if self._start is not None:
            self._rect = QtCore.QRect(self._start, event.pos())
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() != QtCore.Qt.LeftButton or self._start is None:
            return
        rect = QtCore.QRect(self._start, event.pos()).normalized()
        self._start = None
        if rect.width() < 8 or rect.height() < 8:
            self._rect = QtCore.QRect()
            self.update()
            return
        self.hide()
        self.picked.emit(rect)
        self.close()

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()
        else:
            event.accept()


class MiroView(QtWidgets.QGraphicsView):
    tool_finished = QtCore.Signal()
    present_requested = QtCore.Signal()
    view_changed = QtCore.Signal()
    help_requested = QtCore.Signal()
    color_picked = QtCore.Signal(str)
    brush_size_requested = QtCore.Signal(int)

    def __init__(self, scene):
        super().__init__(scene)
        self.setRenderHint(QtGui.QPainter.Antialiasing)
        self.setDragMode(QtWidgets.QGraphicsView.RubberBandDrag)

        self.setTransformationAnchor(QtWidgets.QGraphicsView.NoAnchor)


        self.setSceneRect(-SCENE_HALF, -SCENE_HALF, 2 * SCENE_HALF, 2 * SCENE_HALF)

        self.setCacheMode(QtWidgets.QGraphicsView.CacheBackground)
        self._zoom_cached = None
        self._proxy = None
        self._full_frames = []
        self._grid_tile = None
        self.setAcceptDrops(True)

        self.grid_enabled = False
        self.grid_visible = False
        self.current_tool = 'select'
        self.pen_color = "#ff4757"
        self.pen_width = 3
        self.text_family = SETTINGS['font_family'] or None
        self.text_size = SETTINGS['font_size']
        self.fill_color = None
        self.fill_alpha = 100
        self.line_dash = 'solid'
        self.link_arrows = 0
        self.link_flow = False
        self.brush_style = 'smooth'
        self.highlighter_alpha = HIGHLIGHTER_ALPHA
        self.sticky_color = None

        self._space_held = False
        self._drag_starts = None
        self._press_scene = None
        self._alt_copies = None
        self._alt_press = None

        self.drawing_item = None
        self._drawing_tool = None
        self._stroke_moved = False
        self._stroke_points = []
        self._smooth_pos = None


        self._unlock_item = None
        self._unlock_started = 0.0
        self._badge_hover = False
        self._unlock_timer = _precise(QtCore.QTimer(self))
        self._unlock_timer.setInterval(16)
        self._unlock_timer.timeout.connect(self._unlock_tick)
        self.start_link_item = None
        self.start_link_side = 'auto'
        self.current_path = None
        self.start_pos = None
        self._pan_start = None


        self._zoom_target = 1.0
        self._zoom_anchor_view = QtCore.QPointF()
        self._zoom_anchor_scene = QtCore.QPointF()
        self._zoom_timer = _precise(QtCore.QTimer(self))
        self._zoom_timer.setInterval(16)
        self._zoom_timer.timeout.connect(self._zoom_tick)


        self._wheel_timer = QtCore.QTimer(self)
        self._wheel_timer.setSingleShot(True)
        self._wheel_timer.setInterval(400)
        self._wheel_timer.timeout.connect(self._emit_changed)




        self.minimap = MiniMap(self, self.viewport())
        self._minimap_timer = QtCore.QTimer(self)
        self._minimap_timer.setSingleShot(True)
        self._minimap_timer.setInterval(300)
        self._minimap_timer.timeout.connect(self._refresh_minimap)
        self._minimap_frame_timer = QtCore.QTimer(self)
        self._minimap_frame_timer.setSingleShot(True)
        self._minimap_frame_timer.setInterval(40)
        self._minimap_frame_timer.timeout.connect(self.minimap.update)
        scene.canvas_changed.connect(self.schedule_minimap)
        scene.items_changed.connect(self.schedule_minimap)
        scene.request_save.connect(self.schedule_minimap_later)


        self._hint_shown = None
        scene.canvas_changed.connect(self._check_empty_hint)
        scene.request_save.connect(self._check_empty_hint)


        scene.items_changed.connect(self._check_empty_hint)
        scene.items_changed.connect(self._schedule_rest_caches)


        self._had_locked = False
        scene.selectionChanged.connect(self._on_selection_for_badges)
        self.horizontalScrollBar().valueChanged.connect(lambda *_: self._on_view_changed())
        self.verticalScrollBar().valueChanged.connect(lambda *_: self._on_view_changed())

        self.search_bar = SearchBar(self, self.viewport())
        self.toast = Toast(self.viewport())
        self._nav_anim = None
        self._guides = []

        self._nudge_timer = QtCore.QTimer(self)
        self._nudge_timer.setSingleShot(True)
        self._nudge_timer.setInterval(500)
        self._nudge_timer.timeout.connect(self._emit_changed)
        self._downloads = 0


        self.fast_paint = False
        self._fast_timer = _precise(QtCore.QTimer(self))
        self._fast_timer.setSingleShot(True)
        self._fast_timer.setInterval(FAST_PAINT_HOLD_MS)
        self._fast_timer.timeout.connect(self._end_fast_paint)


    def _begin_zoom_cache(self):
        pass


        if self._zoom_cached is not None:
            return
        self._zoom_cached = []
        if getattr(self, '_gpu', False):
            return


        self.setViewportUpdateMode(QtWidgets.QGraphicsView.FullViewportUpdate)
        self.setCacheMode(QtWidgets.QGraphicsView.CacheNone)
        if self._proxy_wanted():
            self._capture_proxy()
        for item in self.scene().canvas_items():
            if isinstance(item, (TextNode, YouTubeNode)) and item.cacheMode() != QtWidgets.QGraphicsItem.NoCache:
                if isinstance(item, TextNode) and item.is_editing():
                    continue
                self._zoom_cached.append((item, item.cacheMode()))
                item.setCacheMode(QtWidgets.QGraphicsItem.NoCache)

    def _end_zoom_cache(self):
        cached, self._zoom_cached = self._zoom_cached, None
        if cached is None:
            return
        if not getattr(self, '_gpu', False):
            self.setViewportUpdateMode(QtWidgets.QGraphicsView.MinimalViewportUpdate)
            self.setCacheMode(QtWidgets.QGraphicsView.CacheBackground)
        for item, mode in cached:
            try:
                item.setCacheMode(mode)
            except RuntimeError:
                pass
        if self._proxy is not None:
            self._proxy = None
            self.viewport().update()


    def _full_frame_ms(self):
        pass
        frames = sorted(self._full_frames)
        return frames[len(frames) // 2] if frames else None

    def _proxy_wanted(self):
        pass

        if not SETTINGS['zoom_proxy'] or getattr(self, '_gpu', False):
            return False
        ms = self._full_frame_ms()
        return ms is None or ms > ZOOM_DIRECT_MS

    def _capture_proxy(self):
        pass






        viewport = self.viewport()
        dpr = viewport.devicePixelRatioF()
        vp = QtCore.QRectF(viewport.rect())
        current = self.transform().m11()
        region = self.mapToScene(viewport.rect()).boundingRect()
        scale = current
        if self._zoom_timer.isActive():
            target = max(MIN_ZOOM, min(MAX_ZOOM, self._zoom_target))
            if target > current:
                scale = min(current * ZOOM_PROXY_OVERSAMPLE, target)
            else:


                future = max(current / ZOOM_PROXY_OVERSAMPLE, target)
                a, v = self._zoom_anchor_scene, self._zoom_anchor_view
                top_left = a + (vp.topLeft() - v) / future
                bottom_right = a + (vp.bottomRight() - v) / future
                region = QtCore.QRectF(top_left, bottom_right).united(region)
        pixmap = QtGui.QPixmap(max(1, int(region.width() * scale * dpr)), max(1, int(region.height() * scale * dpr)))
        pixmap.setDevicePixelRatio(dpr)
        pixmap.fill(QtCore.Qt.transparent)

        captured = QtGui.QTransform.fromTranslate(-region.left(), -region.top()) * QtGui.QTransform.fromScale(scale, scale)
        painter = QtGui.QPainter(pixmap)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.TextAntialiasing)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        logical = QtCore.QRectF(0, 0, pixmap.width() / dpr, pixmap.height() / dpr)
        self.scene().render(painter, logical, region)
        painter.end()
        self._proxy = (pixmap, captured, time.perf_counter(), QtCore.QRectF(region), ZOOM_PROXY_STRETCH)

    def _proxy_stale(self, next_scale):
        pixmap, captured, taken, region, allowed = self._proxy
        ratio = next_scale / max(1e-9, captured.m11())
        if ratio > allowed or ratio < ZOOM_PROXY_SHRINK:
            return True
        if time.perf_counter() - taken < ZOOM_PROXY_MIN_GAP_MS / 1000.0:
            return False
        visible = self.mapToScene(self.viewport().rect()).boundingRect()
        covered = visible.intersected(region)
        area = visible.width() * visible.height()
        return area > 0 and covered.width() * covered.height() / area < ZOOM_PROXY_COVERAGE

    def _paint_proxy(self, event):
        pixmap, captured = self._proxy[0], self._proxy[1]
        painter = QtGui.QPainter(self.viewport())

        self._draw_canvas_bg(painter, self.viewportTransform(), self.mapToScene(event.rect()).boundingRect(), tiled=False)
        inverted, ok = captured.inverted()
        if not ok:
            painter.end()
            return
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)

        to_screen = inverted * self.viewportTransform()
        logical = QtCore.QRectF(0, 0, pixmap.width() / pixmap.devicePixelRatio(), pixmap.height() / pixmap.devicePixelRatio())
        covered = to_screen.mapRect(logical).toAlignedRect()
        overview = self.minimap.overview
        if overview is not None and not covered.contains(self.viewport().rect()):

            painter.save()
            painter.setClipRegion(QtGui.QRegion(self.viewport().rect()).subtracted(QtGui.QRegion(covered)))
            painter.setTransform(self.viewportTransform())
            painter.drawPixmap(overview[1], overview[0], QtCore.QRectF(overview[0].rect()))
            painter.restore()
        painter.setTransform(to_screen)
        painter.drawPixmap(QtCore.QPointF(0, 0), pixmap)
        painter.end()


    def rest_cache(self, item):
        pass


        if isinstance(item, TextNode) and item.is_editing():
            return
        if item is self.drawing_item:
            return
        if getattr(self, '_gpu', False) and isinstance(item, (TextNode, PathNode, YouTubeNode)):
            if item.cacheMode() != QtWidgets.QGraphicsItem.NoCache:
                item.setCacheMode(QtWidgets.QGraphicsItem.NoCache)
            return
        if isinstance(item, (TextNode, YouTubeNode)):
            item.setCacheMode(QtWidgets.QGraphicsItem.DeviceCoordinateCache)

    def _apply_rest_caches(self):
        try:
            for item in self.scene().canvas_items():
                self.rest_cache(item)
        except RuntimeError:
            pass

    def _schedule_rest_caches(self):
        pass
        if getattr(self, '_gpu', False) and not getattr(self, '_rest_cache_pending', False):
            self._rest_cache_pending = True

            def run():
                self._rest_cache_pending = False
                self._apply_rest_caches()
            QtCore.QTimer.singleShot(0, run)


    def paintEvent(self, event):
        t0 = time.perf_counter()
        if self._proxy is not None:
            self._paint_proxy(event)
        else:
            super().paintEvent(event)
            if event.rect().contains(self.viewport().rect()):

                self._full_frames.append((time.perf_counter() - t0) * 1000.0)
                del self._full_frames[:-5]
        if SETTINGS['frame_stats']:
            stats = getattr(self, '_frame_stats', None)
            if stats is None:
                stats = self._frame_stats = []
            stats.append((t0, (time.perf_counter() - t0) * 1000.0))
            if len(stats) > 600:
                del stats[:300]

    def frame_report(self, window_sec=2.0):
        pass
        stats = getattr(self, '_frame_stats', None)
        if not stats:
            return None
        since = time.perf_counter() - window_sec
        recent = sorted(ms for t, ms in stats if t >= since)
        if not recent:
            return None
        n = len(recent)
        return {'frames': n, 'median': recent[n // 2], 'p95': recent[min(n - 1, int(n * 0.95))], 'max': recent[-1],
                'long': sum(1 for ms in recent if ms > 33.0), 'gpu': bool(getattr(self, '_gpu', False))}

    def _check_empty_hint(self):
        try:
            empty = not self.scene().canvas_items()
        except (RuntimeError, AttributeError):
            return
        if empty != self._hint_shown:
            self._hint_shown = empty
            self.viewport().update()

    def set_gpu(self, on):
        pass
        cls = None
        if on:
            cls = getattr(QtWidgets, 'QOpenGLWidget', None)
            if cls is None:
                try:
                    from PySide6.QtOpenGLWidgets import QOpenGLWidget as cls
                except ImportError:
                    cls = None
        on = cls is not None
        if on == getattr(self, '_gpu', False):
            return
        self._gpu = on
        self._attach_overlays(self)
        if on:
            viewport = cls()
            fmt = QtGui.QSurfaceFormat()
            fmt.setSamples(int(SETTINGS['gpu_samples']))


            fmt.setSwapInterval(1 if SETTINGS['gpu_vsync'] else 0)
            viewport.setFormat(fmt)
            self.setViewport(viewport)
            self.setViewportUpdateMode(QtWidgets.QGraphicsView.FullViewportUpdate)


            self.setCacheMode(QtWidgets.QGraphicsView.CacheNone)
        else:
            self.setViewport(QtWidgets.QWidget())
            self.setViewportUpdateMode(QtWidgets.QGraphicsView.MinimalViewportUpdate)
            self.setCacheMode(QtWidgets.QGraphicsView.CacheBackground)
        self.viewport().setAcceptDrops(True)


        self._attach_overlays(self if on else self.viewport())
        self._update_cursor()
        self._apply_rest_caches()

    def _locked_selected(self):
        pass

        return [i for i in self.scene().selectedItems() if isinstance(i, CANVAS_TYPES) and _is_locked(i)]

    def _on_selection_for_badges(self):
        try:
            has_locked = bool(self._locked_selected())
        except (RuntimeError, AttributeError):
            return
        if has_locked or self._had_locked:
            self.viewport().update()
        self._had_locked = has_locked

    def _mark_interaction(self):
        if not self.fast_paint:
            self.fast_paint = True
        self._fast_timer.start()

    def _end_fast_paint(self):
        if _mouse_pressed():
            self._fast_timer.start()
            return
        self.fast_paint = False
        self._drop_far_image_caches()
        self.viewport().update()

    def _drop_far_image_caches(self):
        pass

        try:
            visible = self.mapToScene(self.viewport().rect()).boundingRect()
            keep = visible.adjusted(-visible.width(), -visible.height(), visible.width(), visible.height())
            for item in self.scene().canvas_items():
                if isinstance(item, ImageNode) and not item.sceneBoundingRect().intersects(keep):
                    item.drop_exact()
        except RuntimeError:
            pass

    def _emit_changed(self):
        self.scene().canvas_changed.emit()

    def _on_view_changed(self):
        self._mark_interaction()


        if not self._minimap_frame_timer.isActive():
            self._minimap_frame_timer.start()
        self.view_changed.emit()
        if self.current_tool in SIZED_CURSOR_TOOLS and not self._space_held:
            self._update_cursor()

    def show_toast(self, text):
        self.toast.show_text(text)


    def zoom_percent(self):
        return int(round(self.transform().m11() * 100))

    def zoom_to(self, zoom):
        pass
        vp = self.viewport().rect()
        center = self.mapToScene(vp.center())
        rect = QtCore.QRectF(0, 0, vp.width() / zoom, vp.height() / zoom)
        rect.moveCenter(center)
        self.animate_to(rect)

    def fit_all(self):
        items = [i for i in self.scene().canvas_items() if i.isVisible()]
        if items:
            self.animate_to(_items_rect(items).adjusted(-60, -60, 60, 60))

    def fit_selection(self):
        items = self.scene().selected_canvas_items()
        if items:
            self.animate_to(_items_rect(items).adjusted(-60, -60, 60, 60))
        else:
            self.fit_all()

    def schedule_minimap(self, *args):
        if not self._minimap_timer.isActive() or self._minimap_timer.remainingTime() > 300:
            self._minimap_timer.start(300)

    def schedule_minimap_later(self, *args):
        if not self._minimap_timer.isActive():
            self._minimap_timer.start(1500)

    def _refresh_minimap(self):
        if _mouse_pressed():
            self._minimap_timer.start(300)
            return
        self.minimap.refresh()


    def request_exact(self, item):
        pass


        queue = getattr(self, '_exact_queue', None)
        if queue is None:
            queue = self._exact_queue = []
        if not any(i is item for i in queue):
            queue.append(item)
        if not getattr(self, '_exact_running', False):
            self._exact_running = True
            QtCore.QTimer.singleShot(0, self._exact_step)

    def _exact_step(self):
        try:
            queue = self._exact_queue
            if self.fast_paint or self._zoom_cached is not None:
                QtCore.QTimer.singleShot(50, self._exact_step)
                return
            while queue:
                item = queue.pop(0)
                if item.scene() is self.scene() and item.build_exact(self):
                    item.update()
                    QtCore.QTimer.singleShot(0, self._exact_step)
                    return
            self._exact_running = False
        except RuntimeError:
            self._exact_running = False

    def _update_cursor(self):
        if self._space_held:
            self.viewport().setCursor(QtCore.Qt.OpenHandCursor)
        elif self.current_tool in SIZED_CURSOR_TOOLS:
            self.viewport().setCursor(self._brush_cursor())
        else:
            self.viewport().setCursor(_tool_cursor(self.current_tool))

    def _brush_diameter(self):
        pass

        if self.current_tool == 'eraser':
            return self._eraser_radius() * 2 * self.transform().m11()
        width = self.pen_width * (5 if self.current_tool == 'highlighter' else 1)
        return width * self.transform().m11()

    def _brush_cursor(self):
        pass
        d = int(round(max(4.0, min(BRUSH_CURSOR_MAX_PX, self._brush_diameter()))))
        if d > 40:
            d -= d % 4
        key = ('brush', d, self.current_tool)
        cursor = _CURSOR_CACHE.get(key)
        if cursor is None:
            size = d + 6
            pixmap = QtGui.QPixmap(size, size)
            pixmap.fill(QtCore.Qt.transparent)
            p = QtGui.QPainter(pixmap)
            p.setRenderHint(QtGui.QPainter.Antialiasing)
            c = QtCore.QPointF(size / 2.0, size / 2.0)
            for color, width in (('#000000', 2.5), ('#ffffff', 1.2)):
                p.setPen(QtGui.QPen(QtGui.QColor(color), width))
                p.drawEllipse(c, d / 2.0, d / 2.0)
            p.setPen(QtGui.QPen(QtGui.QColor('#ffffff'), 1))
            p.drawPoint(c)
            p.end()
            cursor = _CURSOR_CACHE[key] = QtGui.QCursor(pixmap, size // 2, size // 2)
        return cursor

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._place_overlays()
        self.minimap.update()

    def _overlays(self):
        return (self.minimap, self.search_bar, self.toast)

    def _place_overlays(self):
        self.minimap.apply_settings()
        if self.search_bar.isVisible():
            self.search_bar.place()
        if self.toast.isVisible():
            self.toast.place()

    def _attach_overlays(self, parent):
        for widget in self._overlays():
            visible = widget.isVisible()
            widget.setParent(parent)
            widget.setVisible(visible)
        self._place_overlays()

    def scrollContentsBy(self, dx, dy):
        batch = getattr(self, '_scroll_batch', None)
        if batch is not None:
            batch[0] += dx
            batch[1] += dy
            return
        super().scrollContentsBy(dx, dy)

        minimap = getattr(self, 'minimap', None)
        if minimap is not None and minimap.parentWidget() is self.viewport():
            self._place_overlays()

    def scroll_by(self, dx, dy):
        pass


        self._scroll_batch = [0, 0]
        try:
            self.horizontalScrollBar().setValue(self.horizontalScrollBar().value() + dx)
            self.verticalScrollBar().setValue(self.verticalScrollBar().value() + dy)
        finally:
            batch, self._scroll_batch = self._scroll_batch, None
        if batch != [0, 0]:
            self.scrollContentsBy(batch[0], batch[1])

    def drawBackground(self, painter, rect):
        super().drawBackground(painter, rect)






        self._draw_canvas_bg(painter, painter.worldTransform(), rect, tiled=False)

    def _draw_canvas_bg(self, painter, to_logical, scene_rect, tiled):
        pass

        dpr = painter.device().devicePixelRatioF()
        to_device = to_logical * QtGui.QTransform.fromScale(dpr, dpr)
        area = to_device.mapRect(scene_rect).toAlignedRect()
        painter.save()
        painter.setWorldTransform(QtGui.QTransform.fromScale(1.0 / dpr, 1.0 / dpr))
        painter.setRenderHint(QtGui.QPainter.Antialiasing, False)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform, False)
        painter.fillRect(area, QtGui.QColor(_canvas_bg()))
        if self.grid_visible:
            self._draw_grid(painter, area, to_device.map(QtCore.QPointF(0, 0)), to_device.m11(), dpr, tiled)
        painter.restore()

    def _draw_grid(self, painter, area, origin, zoom, dpr, tiled):
        pass
        step = SETTINGS['grid_size']
        while step * zoom < 12 * dpr:
            step *= 4
        cell = step * zoom
        dots = SETTINGS['grid_style'] == 'dots'
        color = QtGui.QColor(_theme()['grid'])
        if dots:
            color = color.lighter(130) if SETTINGS['theme'] == 'dark' else color.darker(115)
        ox, oy = origin.x(), origin.y()
        if tiled and cell < 128 * dpr:


            best_k, best_err = 1, abs(cell - round(cell))
            k = 1
            while (k + 1) * cell <= GRID_TILE_MAX_PX and best_err >= 0.01:
                k += 1
                err = abs(k * cell - round(k * cell))
                if err < best_err:
                    best_k, best_err = k, err
            k = best_k
            n = max(1, int(round(k * cell)))
            key = (n, k, dots, color.rgba(), round(dpr, 3))
            cached = self._grid_tile
            if cached is None or cached[0] != key:
                tile = QtGui.QPixmap(n, n)
                tile.fill(QtCore.Qt.transparent)
                p = QtGui.QPainter(tile)
                c = n / float(k)
                if dots:
                    p.setRenderHint(QtGui.QPainter.Antialiasing)
                    pen = QtGui.QPen(color, 2.5 * dpr)
                    pen.setCapStyle(QtCore.Qt.RoundCap)
                    p.setPen(pen)
                    p.drawPoints([QtCore.QPointF((i + 0.5) * c, (j + 0.5) * c) for i in range(k) for j in range(k)])
                else:
                    for i in range(k):
                        at = int(round(i * c))
                        p.fillRect(QtCore.QRect(at, 0, 1, n), color)
                        p.fillRect(QtCore.QRect(0, at, n, 1), color)
                p.end()
                cached = self._grid_tile = (key, tile)
            shift = n / float(k) * 0.5 if dots else 0.0
            off_x = int(round(area.left() - ox + shift)) % n
            off_y = int(round(area.top() - oy + shift)) % n
            painter.drawTiledPixmap(QtCore.QRectF(area), cached[1], QtCore.QPointF(off_x, off_y))
            return
        if dots and not tiled:

            n = max(4, int(round(cell)))
            key = (n, 'dot', color.rgba(), round(dpr, 3))
            cached = self._grid_tile
            if cached is None or cached[0] != key:
                tile = QtGui.QPixmap(n, n)
                tile.fill(QtCore.Qt.transparent)
                p = QtGui.QPainter(tile)
                p.setRenderHint(QtGui.QPainter.Antialiasing)
                pen = QtGui.QPen(color, 2.5 * dpr)
                pen.setCapStyle(QtCore.Qt.RoundCap)
                p.setPen(pen)
                p.drawPoint(QtCore.QPointF(n / 2.0, n / 2.0))
                p.end()
                cached = self._grid_tile = (key, tile)
            brush = QtGui.QBrush(cached[1])
            transform = QtGui.QTransform()
            transform.translate(ox - cell / 2.0, oy - cell / 2.0)
            transform.scale(cell / float(n), cell / float(n))
            brush.setTransform(transform)
            painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform, True)
            painter.fillRect(area, brush)
            return

        xs, ys = [], []
        x = ox + math.ceil((area.left() - 1 - ox) / cell) * cell
        while x <= area.right() + 1:
            xs.append(int(round(x)))
            x += cell
        y = oy + math.ceil((area.top() - 1 - oy) / cell) * cell
        while y <= area.bottom() + 1:
            ys.append(int(round(y)))
            y += cell
        if dots:
            painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
            pen = QtGui.QPen(color, 2.5 * dpr)
            pen.setCapStyle(QtCore.Qt.RoundCap)
            painter.setPen(pen)
            painter.drawPoints([QtCore.QPointF(px, py) for px in xs for py in ys])
            return
        for px in xs:
            painter.fillRect(QtCore.QRect(px, area.top(), 1, area.height()), color)
        for py in ys:
            painter.fillRect(QtCore.QRect(area.left(), py, area.width(), 1), color)


    def _zoom_tick(self):
        current = self.transform().m11()
        log_c, log_t = math.log(current), math.log(self._zoom_target)
        finished = abs(log_t - log_c) < 0.002
        now = time.perf_counter()
        elapsed = min(0.1, max(0.004, now - getattr(self, '_zoom_last_tick', now - 0.016)))
        self._zoom_last_tick = now
        if finished:
            new = self._zoom_target
            self._zoom_timer.stop()
        else:


            smoothing = _zoom_smoothing()
            share = 1.0 if smoothing >= 1.0 else 1.0 - (1.0 - smoothing) ** (elapsed / 0.016)
            new = math.exp(log_c + (log_t - log_c) * share)
        f = new / current
        if not finished:
            if self._proxy is not None:
                if self._proxy_stale(new):
                    self._capture_proxy()
            elif self._zoom_cached is not None and self._proxy_wanted() and (self._full_frame_ms() or 0.0) > ZOOM_DIRECT_TRIP_MS:
                self._capture_proxy()
        self.scale(f, f)


        drift = self.viewportTransform().map(self._zoom_anchor_scene) - self._zoom_anchor_view
        self.scroll_by(int(round(drift.x())), int(round(drift.y())))
        self._on_view_changed()
        if finished:
            self._end_zoom_cache()

    def animate_to(self, rect, keep_zoom=False):
        pass
        self._zoom_timer.stop()
        _stop_animation(self._nav_anim)
        self._begin_zoom_cache()
        self._nav_anim, self._zoom_target = _fly_to(self, rect, keep_zoom, on_step=self._on_view_changed)
        self._nav_anim.finished.connect(self._end_zoom_cache)

    def reveal(self, item):
        scene = self.scene()
        scene.clearSelection()
        item.setSelected(True)
        self.animate_to(item.sceneBoundingRect().adjusted(-80, -80, 80, 80), keep_zoom=True)


    def _linkable_at(self, pos, exclude=None):
        for item in self.items(pos):
            target = _canvas_target(item)
            if isinstance(target, LINKABLE_TYPES) and target is not exclude and target.isVisible():
                return target



        scene_pos = self.mapToScene(pos)
        tol = 6.0 / max(1e-6, self.transform().m11())
        candidates = [i for i in self.scene().canvas_items()
                      if isinstance(i, LINKABLE_TYPES) and i is not exclude and i.isVisible()
                      and _link_rect(i).adjusted(-tol, -tol, tol, tol).contains(scene_pos)]
        if not candidates:
            return None
        return min(candidates, key=lambda i: (_link_rect(i).width() * _link_rect(i).height(), -i.zValue()))


    def _lock_badge_rect(self, item):
        zoom = max(1e-6, self.transform().m11())
        size = LOCK_BADGE_PX / zoom
        r = item.sceneBoundingRect()
        return QtCore.QRectF(r.right() - size, r.top() - size - 6 / zoom, size, size)

    def _lock_badge_at(self, scene_pos):
        for item in self.scene().selected_canvas_items():
            if _is_locked(item) and self._lock_badge_rect(item).contains(scene_pos):
                return item
        return None

    def _cancel_unlock(self):
        if self._unlock_item is not None:
            self._unlock_item = None
            self._unlock_timer.stop()
            self.viewport().update()

    def _unlock_tick(self):
        item = self._unlock_item
        if item is None:
            self._unlock_timer.stop()
            return
        if time.monotonic() - self._unlock_started >= UNLOCK_HOLD_SEC:
            self._unlock_item = None
            self._unlock_timer.stop()
            _set_locked(item, False)
            self.scene().refresh_selection_ui()
            self.show_toast('Unlocked')
            self._emit_changed()
        self.viewport().update()

    def _eraser_radius(self):
        pass
        return self.pen_width * ERASER_SIZE_FACTOR / 2.0

    def _erase_at(self, pos):
        scene = self.scene()
        center = self.mapToScene(pos)
        radius = self._eraser_radius()

        area = QtGui.QPainterPath()
        area.addEllipse(center, radius, radius)
        strokes = []
        for item in scene.items(area):
            target = _canvas_target(item)
            if isinstance(target, PathNode) and not _is_locked(target) and target not in strokes:
                strokes.append(target)
        for stroke in strokes:
            if not stroke.erase_at(center, radius):
                scene.remove_canvas_item(stroke)
        if strokes:
            return

        target = _canvas_target(self.itemAt(pos))
        if target is not None and not _is_locked(target) and not isinstance(target, PathNode):
            scene.remove_canvas_item(target)


    def _apply_smart_guides(self):
        scene = self.scene()
        moving = [i for i in scene.selected_canvas_items() if not _is_locked(i)]
        if not moving:
            self._guides = []
            return
        rect = _items_rect(moving)
        tol = GUIDE_TOLERANCE_PX / max(1e-6, self.transform().m11())
        visible = self.mapToScene(self.viewport().rect()).boundingRect()
        xs, ys = [], []
        for item in scene.canvas_items():
            if item.isSelected():
                continue
            r = item.sceneBoundingRect()
            if not r.intersects(visible) or rect.contains(r):
                continue
            xs.extend((x, r) for x in (r.left(), r.center().x(), r.right()))
            ys.extend((y, r) for y in (r.top(), r.center().y(), r.bottom()))

        def best(own, candidates):
            found = None
            for value in own:
                for target, r in candidates:
                    d = target - value
                    if abs(d) <= tol and (found is None or abs(d) < abs(found[0])):
                        found = (d, target, r)
            return found

        bx = best((rect.left(), rect.center().x(), rect.right()), xs)
        by = best((rect.top(), rect.center().y(), rect.bottom()), ys)
        dx = bx[0] if bx else 0.0
        dy = by[0] if by else 0.0
        if dx or dy:
            for item in moving:
                item.setPos(item.pos() + QtCore.QPointF(dx, dy))
            rect.translate(dx, dy)
        guides = []
        if bx:
            r = bx[2]
            guides.append(QtCore.QLineF(bx[1], min(rect.top(), r.top()) - 12, bx[1], max(rect.bottom(), r.bottom()) + 12))
        if by:
            r = by[2]
            guides.append(QtCore.QLineF(min(rect.left(), r.left()) - 12, by[1], max(rect.right(), r.right()) + 12, by[1]))
        if guides or self._guides:
            self._guides = guides
            self.viewport().update()


    def _snap_candidates(self, exclude):
        pass
        visible = self.mapToScene(self.viewport().rect()).boundingRect()
        xs, ys = [], []
        for item in self.scene().canvas_items():
            if any(item is e for e in exclude) or not item.isVisible():
                continue
            r = _link_rect(item)
            if not r.intersects(visible):
                continue
            xs.extend((x, r) for x in (r.left(), r.center().x(), r.right()))
            ys.extend((y, r) for y in (r.top(), r.center().y(), r.bottom()))
        return xs, ys

    def _snap_exclude(self, item):
        group = getattr(item, 'group_id', None)
        return [item] + [i for i in self.scene().canvas_items()
                         if i.isSelected() or (group and getattr(i, 'group_id', None) == group)]

    def clear_guides(self):
        if self._guides:
            self._guides = []
            self.viewport().update()

    def snap_resize(self, item, anchor, corner0, start_scale, scale):
        pass
        point = anchor + (corner0 - anchor) * (scale / start_scale)
        tol = GUIDE_TOLERANCE_PX / max(1e-6, self.transform().m11())
        grid = self.grid_enabled
        if not grid:
            xs, ys = self._snap_candidates(self._snap_exclude(item))
        best = None
        for axis in (0, 1):
            value = point.x() if axis == 0 else point.y()
            base = anchor.x() if axis == 0 else anchor.y()
            span = (corner0.x() if axis == 0 else corner0.y()) - base
            if abs(span) < 1:
                continue
            if grid:
                g = SETTINGS['grid_size']
                targets = [(round(value / g) * g, None)]
            else:
                targets = [(t, r) for t, r in (xs if axis == 0 else ys) if abs(t - value) <= tol]
            for target, r in targets:
                new_scale = start_scale * (target - base) / span
                if new_scale <= 0:
                    continue
                delta = abs(target - value)
                if best is None or delta < best[0]:
                    guide = None
                    if r is not None:
                        lo = min(anchor.y() if axis == 0 else anchor.x(), r.top() if axis == 0 else r.left()) - 12
                        hi = max(point.y() if axis == 0 else point.x(), r.bottom() if axis == 0 else r.right()) + 12
                        guide = (QtCore.QLineF(target, lo, target, hi) if axis == 0 else QtCore.QLineF(lo, target, hi, target))
                    best = (delta, new_scale, guide)
        guides = [best[2]] if best is not None and best[2] is not None else []
        if guides or self._guides:
            self._guides = guides
            self.viewport().update()
        return best[1] if best is not None else scale

    def snap_point(self, point, exclude):
        pass
        if self.grid_enabled:
            g = SETTINGS['grid_size']
            return QtCore.QPointF(round(point.x() / g) * g, round(point.y() / g) * g)
        tol = GUIDE_TOLERANCE_PX / max(1e-6, self.transform().m11())
        xs, ys = self._snap_candidates(exclude)
        x, y, guides = point.x(), point.y(), []
        bx = min(((t, r) for t, r in xs if abs(t - x) <= tol), key=lambda c: abs(c[0] - x), default=None)
        by = min(((t, r) for t, r in ys if abs(t - y) <= tol), key=lambda c: abs(c[0] - y), default=None)
        if bx:
            x = bx[0]
            guides.append(QtCore.QLineF(x, min(y, bx[1].top()) - 12, x, max(y, bx[1].bottom()) + 12))
        if by:
            y = by[0]
            guides.append(QtCore.QLineF(min(x, by[1].left()) - 12, y, max(x, by[1].right()) + 12, y))
        if guides or self._guides:
            self._guides = guides
            self.viewport().update()
        return QtCore.QPointF(x, y)

    def drawForeground(self, painter, rect):
        super().drawForeground(painter, rect)
        if self._hint_shown is None:
            self._check_empty_hint()
        if self._hint_shown:
            painter.save()
            painter.resetTransform()
            vp = QtCore.QRectF(self.viewport().rect())
            painter.setFont(_ui_font(15))
            painter.setPen(QtGui.QColor(_theme()['caption']))
            painter.drawText(vp, QtCore.Qt.AlignCenter,
                             'Drop or paste images here  ·  Double-click to add a note\n'
                             'Press N for a sticky, F for a frame  ·  ? for all shortcuts')
            painter.restore()
        if self._guides:
            painter.setPen(QtGui.QPen(QtGui.QColor(GUIDE_COLOR), 0))
            painter.drawLines(self._guides)

        locked = self._locked_selected()
        if locked:
            zoom = max(1e-6, self.transform().m11())
            accent = QtGui.QColor(*GLOW_COLOR)
            font = _ui_font(max(1, int(13 / zoom)), kind='emoji')
            painter.save()
            painter.setRenderHint(QtGui.QPainter.Antialiasing)
            painter.setFont(font)
            for item in locked:
                badge = self._lock_badge_rect(item)
                holding = item is self._unlock_item
                painter.setPen(QtGui.QPen(accent if holding else QtGui.QColor(255, 255, 255, 90), 1.5 / zoom))
                painter.setBrush(QtGui.QColor(30, 30, 30, 230))
                painter.drawEllipse(badge)
                if holding:
                    progress = min(1.0, (time.monotonic() - self._unlock_started) / UNLOCK_HOLD_SEC)
                    pen = QtGui.QPen(accent, 3 / zoom)
                    pen.setCapStyle(QtCore.Qt.RoundCap)
                    painter.setPen(pen)
                    painter.setBrush(QtCore.Qt.NoBrush)
                    painter.drawArc(badge.adjusted(1.5 / zoom, 1.5 / zoom, -1.5 / zoom, -1.5 / zoom),
                                    90 * 16, -int(360 * 16 * progress))
                if EMOJI_OK:
                    painter.setPen(QtGui.QColor('#ffffff'))
                    painter.drawText(badge, QtCore.Qt.AlignCenter, '🔓' if holding else '🔒')
                else:
                    self._draw_padlock(painter, badge, zoom, holding)
            painter.restore()

    @staticmethod
    def _draw_padlock(painter, badge, zoom, opened):
        pass
        c, u = badge.center(), badge.width() / 24.0
        painter.setPen(QtGui.QPen(QtGui.QColor('#ffffff'), 1.6 / zoom))
        painter.setBrush(QtCore.Qt.NoBrush)
        shackle = QtCore.QRectF(c.x() - 3.5 * u, c.y() - 7 * u, 7 * u, 8 * u)
        if opened:
            shackle.translate(2.5 * u, -1.5 * u)
        painter.drawArc(shackle, 0, 180 * 16)
        painter.drawLine(QtCore.QPointF(shackle.right(), shackle.center().y()),
                         QtCore.QPointF(shackle.right(), c.y() - u))
        if not opened:
            painter.drawLine(QtCore.QPointF(shackle.left(), shackle.center().y()),
                             QtCore.QPointF(shackle.left(), c.y() - u))
        painter.setBrush(QtGui.QColor('#ffffff'))
        painter.drawRoundedRect(QtCore.QRectF(c.x() - 5 * u, c.y() - u, 10 * u, 7.5 * u), 1.2 * u, 1.2 * u)

    def _font_style(self, size=None):
        style = 'font-size:%dpt;' % (size or self.text_size)
        if self.text_family:
            style += " font-family:'%s';" % self.text_family.replace("'", "")
        return style

    def _add_text_node(self, html, pos, **kwargs):
        node = TextNode(html, pos.x(), pos.y(), **kwargs)
        self.scene().addItem(node)
        return node

    def _add_images(self, raws, center):
        scene = self.scene()
        items = []
        for raw in raws:
            item = ImageNode(scene, scene.add_asset(raw), 0, 0, rounded=True)
            scene.addItem(item)
            items.append(item)
        if len(items) > 1:
            _arrange_in_rows(items, QtCore.QPointF(0, 0))
        _move_group_center(items, center)
        return items

    def _insert_mime(self, mime, pos, allow_text_note=False):
        pass
        added = 0
        offset = QtCore.QPointF(30, 30)

        candidates = [u.toString() for u in mime.urls()] if mime.hasUrls() else []
        if mime.hasText():
            candidates += mime.text().split()
        videos = []
        for text in candidates:
            if _youtube_id(text) and _youtube_id(text) not in [_youtube_id(v) for v in videos]:
                videos.append(text)
        if videos:
            for k, url in enumerate(videos[:10]):
                self._add_youtube(url, pos + offset * k)
            self.show_toast('YouTube video added' if len(videos) == 1 else '%d YouTube videos added' % len(videos))
            return len(videos[:10])
        if mime.hasText():


            tokens = mime.text().split()
            nodes = [hou.node(t) for t in tokens if t.startswith('/')]
            if tokens and len(nodes) == len(tokens) and all(n is not None for n in nodes):
                for node in nodes:
                    rel_path, abs_path = self.scene().houdini_paths_for(node)
                    node_html = (f'<span style="font-size:14pt; color:#ffffff; font-family:\'{_font_family("mono")}\';">'
                                 f'<b>[NODE]</b> {node.name()}</span>')
                    self._add_text_node(node_html, pos + offset * added, is_sticky=True,
                                        houdini_path=rel_path, houdini_abs_path=abs_path)
                    added += 1
                return added

        raws = []
        web_urls = []
        if mime.hasUrls():
            for url in mime.urls():
                if url.isLocalFile():
                    raw = _image_bytes_from_file(url.toLocalFile())
                    if raw:
                        raws.append(raw)
                elif url.scheme() in ('http', 'https'):
                    web_urls.append(url)
        if not raws and mime.hasImage():
            image = mime.imageData()
            if isinstance(image, QtGui.QPixmap):
                image = image.toImage()
            if isinstance(image, QtGui.QImage) and not image.isNull():
                raws.append(_encode_image(image))
        if raws:
            return len(self._add_images(raws, pos))
        if not web_urls and mime.hasHtml():
            match = re.search(r'<img[^>]+src="(https?://[^"]+)"', mime.html())
            if match:
                web_urls.append(QtCore.QUrl(html_lib.unescape(match.group(1))))
        if web_urls:
            self._download_images(web_urls[:10], pos)
            return 0

        if allow_text_note and mime.hasText() and mime.text().strip():
            self._add_note_with_text(mime.text(), pos)
            return 1
        return 0

    def _add_youtube(self, url, pos):
        scene = self.scene()
        if not url.startswith('http'):
            url = 'https://' + url
        item = YouTubeNode(scene, url)
        item.setZValue(max([i.zValue() for i in scene.canvas_items()] or [0]) + 1)
        scene.addItem(item)
        _move_group_center([item], pos)
        scene.clearSelection()
        item.setSelected(True)
        item.fetch()
        return item

    def _add_note_with_text(self, text, pos):
        body = html_lib.escape(text).replace('\n', '<br>')
        node = self._add_text_node('<span style="%s">%s</span>' % (self._font_style(), body), pos)
        node.linkify()
        _move_group_center([node], pos)
        return node


    def _download_images(self, urls, pos):
        pass

        for url in urls:
            self._downloads += 1
            _http_get(url.toString(), lambda data, error, p=QtCore.QPointF(pos), u=url: self._on_download_finished(data, error, p, u))
        self.show_toast('Downloading image…')

    def _on_download_finished(self, data, error, pos, url):
        self._downloads -= 1
        raw = _image_bytes_from_data(data) if data and not error else None
        if raw:
            items = self._add_images([raw], pos)
            self.scene().clearSelection()
            for item in items:
                item.setSelected(True)
            self.show_toast('Image added')
        elif not error:
            self._add_note_with_text(url.toString(), pos)
            self.show_toast('Not an image — added the link as a note')
        else:
            _log_info('Download failed: %s — %s' % (url.toString(), error))
            self.show_toast('Could not download the image: %s' % error)
            return
        self._emit_changed()

    def _cursor_scene_pos(self):
        pos = self.viewport().mapFromGlobal(QtGui.QCursor.pos())
        if not self.viewport().rect().contains(pos):
            pos = self.viewport().rect().center()
        return self.mapToScene(pos)

    def paste_from_clipboard(self):
        mime = QtWidgets.QApplication.clipboard().mimeData()
        if mime is None:
            return
        if mime.hasFormat(FRAGMENT_MIME):
            try:
                fragment = json.loads(bytes(mime.data(FRAGMENT_MIME).data()).decode('utf-8'))
            except Exception:
                _log_error('Could not read copied canvas items')
                return
            created = self.scene().import_fragment(fragment, self._cursor_scene_pos())
            if created:
                self._emit_changed()
                self.show_toast('Pasted %d item%s' % (len(created), '' if len(created) == 1 else 's'))
            return
        added = self._insert_mime(mime, self._cursor_scene_pos(), allow_text_note=True)
        if added:
            self._emit_changed()
            self.show_toast('Pasted %d item%s' % (added, '' if added == 1 else 's'))

    def copy_selection(self, toast=True):
        items = self.scene().selected_canvas_items()
        if not items:
            return False
        mime = QtCore.QMimeData()
        mime.setData(FRAGMENT_MIME, QtCore.QByteArray(json.dumps(self.scene().export_fragment(items)).encode('utf-8')))
        QtWidgets.QApplication.clipboard().setMimeData(mime)
        if toast:
            self.show_toast('Copied %d item%s' % (len(items), '' if len(items) == 1 else 's'))
        return True

    def duplicate_selection(self):
        scene = self.scene()
        items = scene.selected_canvas_items()
        if not items:
            return
        center = _items_rect(items).center() + QtCore.QPointF(30, 30)
        if scene.import_fragment(scene.export_fragment(items), center):
            self._emit_changed()

    def select_all(self):
        scene = self.scene()
        for item in scene.canvas_items():
            if item.isVisible():
                item.setSelected(True)

    def nudge_selection(self, dx, dy):
        items = [i for i in self.scene().selected_canvas_items() if not _is_locked(i)]
        for item in items:
            item.setPos(item.pos() + QtCore.QPointF(dx, dy))
        if items:
            self._nudge_timer.start()

    def wrap_selection_in_frame(self):
        scene = self.scene()
        items = scene.selected_canvas_items()
        if not items:
            return
        count = sum(1 for i in scene.canvas_items() if isinstance(i, FrameNode))
        frame = scene.wrap_in_frame(items, 'Frame %d' % (count + 1), QtGui.QColor(*GLOW_COLOR).name())
        scene.clearSelection()
        frame.setSelected(True)
        self._emit_changed()
        self.show_toast('Frame created')

    def apply_style_to_selection(self, color=None, width=None, dash=None, arrows=None):
        pass
        changed = False
        for item in self.scene().selectedItems():
            if _is_locked(item):
                continue
            if isinstance(item, PathNode):
                item.set_style(color=color, width=width, dash=dash)
                changed = True
            elif isinstance(item, ShapeNode):
                item.set_style(color=color, width=width, dash=dash)
                changed = True
            elif isinstance(item, LinkNode):
                item.set_style(color=color, width=width, dash=dash, arrows=arrows)
                changed = True
        return changed

    def apply_fill_to_selection(self, fill=ShapeNode._KEEP, alpha=None):
        pass
        changed = False
        for item in self.scene().selected_canvas_items():
            if _is_locked(item):
                continue
            if isinstance(item, ShapeNode) and item.shape_type != 'arrow':
                item.set_style(fill=fill, fill_alpha=alpha)
                changed = True
            elif isinstance(item, TextNode) and item.is_sticky and fill is not ShapeNode._KEEP:
                item.set_bg(fill or None)
                changed = True
        return changed

    def group_selection(self):
        items = self.scene().selected_canvas_items()
        if len(items) < 2:
            return
        group_id = _new_id()
        for item in items:
            item.group_id = group_id
        self._emit_changed()

    def set_links_flow(self, links, on):
        pass
        changed = [l for l in links if l.flow != on]
        for link in changed:
            link.flow = on
            link.update()
        if changed:
            self.scene().ensure_flow()
            self._emit_changed()
        return bool(changed)

    def toggle_flow_selection(self):
        links = [i for i in self.scene().selectedItems() if isinstance(i, LinkNode)]
        if links:
            self.set_links_flow(links, not all(l.flow for l in links))

    def align_selection(self, mode):
        pass
        items = [i for i in self.scene().selected_canvas_items() if not _is_locked(i)]
        if len(items) < 2:
            return
        rects = [i.sceneBoundingRect() for i in items]
        bounds = _items_rect(items)
        for item, r in zip(items, rects):
            if mode == 'left':
                d = QtCore.QPointF(bounds.left() - r.left(), 0)
            elif mode == 'hcenter':
                d = QtCore.QPointF(bounds.center().x() - r.center().x(), 0)
            elif mode == 'right':
                d = QtCore.QPointF(bounds.right() - r.right(), 0)
            elif mode == 'top':
                d = QtCore.QPointF(0, bounds.top() - r.top())
            elif mode == 'vcenter':
                d = QtCore.QPointF(0, bounds.center().y() - r.center().y())
            else:
                d = QtCore.QPointF(0, bounds.bottom() - r.bottom())
            item.setPos(item.pos() + d)
        self._emit_changed()

    def ungroup_selection(self):
        items = [i for i in self.scene().selected_canvas_items() if getattr(i, 'group_id', None)]
        for item in items:
            item.group_id = None
        if items:
            self._emit_changed()

    def toggle_lock_selection(self):
        items = self.scene().selected_canvas_items()
        if not items:
            return
        lock = not all(_is_locked(i) for i in items)
        for item in items:
            _set_locked(item, lock)
        self.scene().refresh_selection_ui()
        self.viewport().update()
        self._emit_changed()

    def edit_link_label(self, link):
        text, ok = QtWidgets.QInputDialog.getText(self.window(), 'Link', 'Label (empty to remove):',
                                                  QtWidgets.QLineEdit.Normal, link.label)
        if ok and text.strip() != link.label:
            link.set_label(text.strip())
            self._emit_changed()

    def delete_selection(self):
        targets = []
        for item in self.scene().selectedItems():
            target = _canvas_target(item)
            if target is not None and not _is_locked(target) and target not in targets:
                targets.append(target)
        for target in targets:
            self.scene().remove_canvas_item(target)
        if targets:
            self._emit_changed()
        return bool(targets)

    def reorder_selected(self, mode, targets=None):
        if targets is None:
            targets = self.scene().selected_canvas_items()
        if targets and self.scene().reorder(targets, mode):
            self._emit_changed()

    def handle_canvas_shortcut(self, event):
        pass
        if _ctrl_letter(event, 'C'):
            self.copy_selection()
            return True
        if _ctrl_letter(event, 'X'):
            if self.copy_selection():
                self.delete_selection()
            return True
        if _ctrl_letter(event, 'V'):
            self.paste_from_clipboard()
            return True
        if _ctrl_letter(event, 'D'):
            self.duplicate_selection()
            return True
        if _ctrl_letter(event, 'F'):
            self.search_bar.open_bar()
            return True
        if _ctrl_letter(event, 'A'):
            self.select_all()
            return True
        if _ctrl_letter(event, 'G') and event.modifiers() & QtCore.Qt.AltModifier:
            self.wrap_selection_in_frame()
            return True
        if _ctrl_letter(event, 'G'):
            self.group_selection()
            return True
        if _ctrl_letter(event, 'G', shift=True):
            self.ungroup_selection()
            return True
        if _ctrl_letter(event, 'L', shift=True):
            self.toggle_lock_selection()
            return True
        if event.key() == QtCore.Qt.Key_F5 and not event.modifiers():
            self.present_requested.emit()
            return True
        if event.key() in (QtCore.Qt.Key_F1, QtCore.Qt.Key_Question):
            self.help_requested.emit()
            return True

        if event.modifiers() & QtCore.Qt.ShiftModifier and not event.modifiers() & QtCore.Qt.ControlModifier:
            if _key_is(event, '1'):
                self.fit_all()
                return True
            if _key_is(event, '2'):
                self.fit_selection()
                return True
        mode = _order_mode_for(event)
        if mode:
            self.reorder_selected(mode)
            return True
        return False


    def mousePressEvent(self, event):

        if event.button() == QtCore.Qt.MiddleButton or (event.button() == QtCore.Qt.LeftButton and self._space_held):
            self._pan_start = event.pos()
            self.viewport().setCursor(QtCore.Qt.ClosedHandCursor)
            event.accept()
            return

        scene_pos = self.mapToScene(event.pos())


        crop_image = self.scene().active_crop
        if crop_image is not None:
            hit = self.itemAt(event.pos())
            inside = hit is not None and (hit is crop_image or hit.parentItem() is crop_image
                                          or (hit.parentItem() is not None and hit.parentItem().parentItem() is crop_image))
            if not inside:
                crop_image.finish_crop(apply=True)
                event.accept()
                return

        if event.button() == QtCore.Qt.RightButton:
            target = _canvas_target(self.itemAt(event.pos()))
            if target is not None:
                self.show_context_menu(event, target)
            else:
                self.show_canvas_menu(event)
            return

        if event.button() == QtCore.Qt.LeftButton:
            badge_item = self._lock_badge_at(scene_pos)
            if badge_item is not None:
                self._unlock_item = badge_item
                self._unlock_started = time.monotonic()
                self._unlock_timer.start()
                self.viewport().update()
                event.accept()
                return

            tool = self.current_tool
            if tool == 'eraser':
                self._erase_at(event.pos())
                return

            if tool == 'eyedropper':
                self._pick_color_at(event.pos())
                return

            if tool == 'select':
                target = _canvas_target(self.itemAt(event.pos()))
                mods = event.modifiers()
                alt = bool(mods & QtCore.Qt.AltModifier)
                if alt and target is not None and not isinstance(target, LinkNode) and not _is_locked(target):
                    self._start_alt_duplicate(target, event.pos())


                self._shift_select = bool(mods & QtCore.Qt.ShiftModifier) and not alt
                super().mousePressEvent(_with_ctrl_for_shift(event) if self._shift_select else event)

                self._press_scene = scene_pos
                self._drag_starts = [(i, i.pos()) for i in self.scene().selected_canvas_items() if not _is_locked(i)]
                return

            if tool == 'link':
                self.start_link_item = self._linkable_at(event.pos())
                if self.start_link_item is not None:
                    self.start_link_side = _side_at(_link_rect(self.start_link_item), scene_pos)

                    self.drawing_item = QtWidgets.QGraphicsPathItem()
                    self.drawing_item.setPen(QtGui.QPen(QtGui.QColor(LINK_COLOR), 3, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap))
                    self._drawing_tool = tool
                    self.scene().addItem(self.drawing_item)
                else:
                    self.show_toast('Start the link on a note, image, shape or frame')
                return

            if tool in ('pen', 'highlighter'):
                self.current_path = QtGui.QPainterPath(scene_pos)
                self._stroke_points = [QtCore.QPointF(scene_pos)]
                self._smooth_pos = QtCore.QPointF(scene_pos)
                self._stroke_moved = False
                is_hi = (tool == 'highlighter')
                width = self.pen_width * 5 if is_hi else self.pen_width
                self.drawing_item = PathNode(self.current_path, self.pen_color, width, is_highlighter=is_hi, dash=self.line_dash,
                                             brush=self.brush_style, alpha=self.highlighter_alpha)
                self.drawing_item.setCacheMode(QtWidgets.QGraphicsItem.NoCache)
                self._drawing_tool = tool
                self.scene().addItem(self.drawing_item)
                return

            if tool in SHAPE_TOOLS:
                self.start_pos = scene_pos
                self.drawing_item = ShapeNode(tool, QtCore.QRectF(self.start_pos, self.start_pos), self.pen_color, self.pen_width,
                                              dash=self.line_dash, fill=self.fill_color, fill_alpha=self.fill_alpha)
                self._drawing_tool = tool
                self.scene().addItem(self.drawing_item)
                return

            if tool == 'frame':
                scene = self.scene()
                self.start_pos = scene_pos
                count = sum(1 for i in scene.canvas_items() if isinstance(i, FrameNode))
                frame = FrameNode(QtCore.QRectF(0, 0, 0, 0), title='Frame %d' % (count + 1), color=QtGui.QColor(*GLOW_COLOR).name())
                frame.setPos(scene_pos)

                frame.setZValue(min([i.zValue() for i in scene.canvas_items()] or [0]) - 1)
                self.drawing_item = frame
                self._drawing_tool = tool
                scene.addItem(frame)
                return

            if tool == 'sticky':
                self._add_text_node('<span style="%s color: #141414;">New sticky</span>' % self._font_style(), scene_pos,
                                    is_sticky=True, bg=self.sticky_color, text_width=STICKY_WIDTH)
                self._emit_changed()
                self.tool_finished.emit()
                return

            if tool == 'code':
                html = ('<pre style="font-family: \'Source Code Pro\', \'%s\'; font-size:%dpt; color: %s; margin: 5px;">'
                        '// Your code here<br>float amp = chf("amp");<br>v@P.y += sin(@Frame * 0.1) * amp;</pre>'
                        % (_font_family('mono'), self.text_size, VEX_COLORS['default']))
                self._add_text_node(html, scene_pos, is_code=True)
                self._emit_changed()
                self.tool_finished.emit()
                return

        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):

        if self._pan_start is not None and event.buttons() & (QtCore.Qt.MiddleButton | QtCore.Qt.LeftButton):
            delta = event.pos() - self._pan_start
            self.scroll_by(-delta.x(), -delta.y())
            self._pan_start = event.pos()
            if self._zoom_timer.isActive():


                self._zoom_anchor_view = self._zoom_anchor_view + QtCore.QPointF(delta)
            event.accept()
            return

        scene_pos = self.mapToScene(event.pos())
        if self._unlock_item is not None:
            if not self._lock_badge_rect(self._unlock_item).adjusted(-8, -8, 8, 8).contains(scene_pos):
                self._cancel_unlock()
            return
        over_badge = _enum_int(event.buttons()) == 0 and self._lock_badge_at(scene_pos) is not None
        if over_badge != self._badge_hover:
            self._badge_hover = over_badge
            if over_badge:
                self.viewport().setCursor(QtCore.Qt.PointingHandCursor)
                self.show_toast('Hold to unlock')
            else:
                self._update_cursor()

        super().mouseMoveEvent(event)

        dragging = (self.current_tool == 'select' and event.buttons() & QtCore.Qt.LeftButton
                    and isinstance(self.scene().mouseGrabberItem(), CANVAS_TYPES))
        if dragging:
            self._mark_interaction()
            if (event.modifiers() & QtCore.Qt.AltModifier and self._alt_copies is None
                    and self._drag_starts and self._press_scene is not None):
                self._leave_copies_behind()
        if dragging and event.modifiers() & QtCore.Qt.ShiftModifier and self._drag_starts and self._press_scene is not None:

            total = scene_pos - self._press_scene
            horizontal = abs(total.x()) >= abs(total.y())
            for item, start in self._drag_starts:
                if horizontal:
                    item.setPos(item.pos().x(), start.y())
                else:
                    item.setPos(start.x(), item.pos().y())
        elif dragging and not self.grid_enabled:
            self._apply_smart_guides()

        if self.current_tool == 'eraser' and event.buttons() & QtCore.Qt.LeftButton:
            self._erase_at(event.pos())
            return

        if self.drawing_item is not None and event.buttons() & QtCore.Qt.LeftButton:
            tool = self._drawing_tool
            if tool == 'link':
                self.drawing_item.setPath(_link_preview_path(_link_rect(self.start_link_item), self.start_link_side, scene_pos))
            elif tool in ('pen', 'highlighter'):

                self._smooth_pos = self._smooth_pos + (scene_pos - self._smooth_pos) * BRUSH_STABILIZER
                step = BRUSH_STEP_PX / max(1e-6, self.transform().m11())
                last = self._stroke_points[-1]
                if QtCore.QLineF(last, self._smooth_pos).length() > step:
                    point = QtCore.QPointF(self._smooth_pos)
                    self._stroke_points.append(point)
                    self.current_path.quadTo(last, (last + point) / 2)
                    self.drawing_item.set_path(self.current_path)
                    self._stroke_moved = True
            elif tool in SHAPE_TOOLS:
                end_pos = scene_pos
                if event.modifiers() & QtCore.Qt.ShiftModifier and tool in ('rect', 'ellipse'):
                    dx = end_pos.x() - self.start_pos.x()
                    dy = end_pos.y() - self.start_pos.y()
                    side = max(abs(dx), abs(dy))
                    end_pos = QtCore.QPointF(self.start_pos.x() + math.copysign(side, dx), self.start_pos.y() + math.copysign(side, dy))
                self.drawing_item.set_rect(QtCore.QRectF(self.start_pos, end_pos))
            elif tool == 'frame':
                rect = QtCore.QRectF(self.start_pos, scene_pos).normalized()
                self.drawing_item.setPos(rect.topLeft())
                self.drawing_item.set_frame_rect(QtCore.QRectF(0, 0, rect.width(), rect.height()))

    def mouseReleaseEvent(self, event):
        if self._pan_start is not None and event.button() in (QtCore.Qt.MiddleButton, QtCore.Qt.LeftButton):
            self._pan_start = None
            self._update_cursor()
            event.accept()
            return

        if self._unlock_item is not None:
            self._cancel_unlock()
            self.show_toast('Hold the lock for a second to unlock')
            event.accept()
            return

        if self._guides:
            self._guides = []
            self.viewport().update()
        self._drag_starts = None
        self._press_scene = None

        if self._alt_copies is not None:
            copies, press = self._alt_copies, self._alt_press
            self._alt_copies = self._alt_press = None
            if QtCore.QLineF(QtCore.QPointF(press), QtCore.QPointF(event.pos())).length() < 4:

                super().mouseReleaseEvent(event)
                for item in copies:
                    self.scene().remove_canvas_item(item)
                return

        if event.button() == QtCore.Qt.LeftButton and self.drawing_item is not None:
            if self._drawing_tool in ('pen', 'highlighter') and self._stroke_moved:

                points = _chaikin(self._stroke_points + [self.mapToScene(event.pos())], BRUSH_FINAL_SMOOTHING)

                tolerance = BRUSH_SIMPLIFY_PX / max(1e-6, self.transform().m11())
                self.drawing_item.set_path(_points_path(_simplify_points(points, tolerance)))
            self._stroke_points = []
            self._smooth_pos = None
            if isinstance(self.drawing_item, PathNode):
                finished, self.drawing_item = self.drawing_item, None
                self.rest_cache(finished)
                self.drawing_item = finished
            if self._drawing_tool == 'link':
                self._finish_link(event.pos())
            elif not self._discard_if_empty(self.drawing_item) and self._drawing_tool == 'frame':
                self.tool_finished.emit()
            self.drawing_item = None
            self._drawing_tool = None
            self.start_link_item = None
            self.current_path = None
            self.start_pos = None
            self._emit_changed()
            return

        shift_select, self._shift_select = getattr(self, '_shift_select', False), False
        if shift_select and event.button() == QtCore.Qt.LeftButton:
            event = _with_ctrl_for_shift(event)
        super().mouseReleaseEvent(event)
        self._emit_changed()

    def _finish_link(self, pos):
        self.scene().removeItem(self.drawing_item)
        start = self.start_link_item
        end = self._linkable_at(pos, exclude=start)
        if end is None:
            self.show_toast('Release over a note, image, shape or frame to link')
            return
        if any(link.item_start is end or link.item_end is end for link in start.links):
            self.show_toast('These are already linked')
            return
        end_side = _side_at(_link_rect(end), self.mapToScene(pos))
        self.scene().addItem(LinkNode(start, end, color=self.pen_color, width=self.pen_width,
                                      start_side=self.start_link_side, end_side=end_side,
                                      dash=self.line_dash, arrows=self.link_arrows, flow=self.link_flow))
        self.scene().ensure_flow()

    def _leave_copies_behind(self):
        pass


        scene = self.scene()
        moving = [(i, start) for i, start in self._drag_starts if i.scene() is scene]
        if not moving:
            return
        items = [i for i, _ in moving]
        delta = moving[0][0].pos() - moving[0][1]
        center = _items_rect(items).center() - delta
        copies = scene.import_fragment(scene.export_fragment(items), center, select=False)
        if copies:
            self._alt_copies = copies
            self._alt_press = self.mapFromScene(self._press_scene)

    def _start_alt_duplicate(self, target, pos):
        pass
        scene = self.scene()
        if not target.isSelected():
            scene.clearSelection()
            target.setSelected(True)
        items = [i for i in scene.selected_canvas_items() if not _is_locked(i)]
        if not items:
            return
        copies = scene.import_fragment(scene.export_fragment(items), _items_rect(items).center())
        if copies:
            self._alt_copies, self._alt_press = copies, pos
            for item in copies:
                if isinstance(item, FrameNode):


                    item._skip_children_once = True

    def _pick_color_at(self, pos):
        pass
        image = self.viewport().grab(QtCore.QRect(pos, QtCore.QSize(1, 1))).toImage()
        if image.isNull():
            return
        color = image.pixelColor(0, 0).name()
        self.color_picked.emit(color)
        self.show_toast('Picked %s' % color)
        self.tool_finished.emit()

    def _discard_if_empty(self, item):

        if isinstance(item, PathNode):
            empty = not self._stroke_moved
        elif isinstance(item, ShapeNode):
            empty = abs(item.geom_rect.width()) < 2 and abs(item.geom_rect.height()) < 2
        elif isinstance(item, FrameNode):
            empty = item.frame_rect.width() < 20 or item.frame_rect.height() < 20
        else:
            empty = False
        if empty:
            self.scene().removeItem(item)
        return empty

    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        if event.modifiers() & QtCore.Qt.ControlModifier and self.current_tool in SIZED_CURSOR_TOOLS:

            if delta:
                step = max(1, int(round(self.pen_width * 0.1)))
                value = int(max(1, min(200, self.pen_width + (step if delta > 0 else -step))))
                if value != self.pen_width:
                    self.brush_size_requested.emit(value)
                    self.show_toast('Size %d' % value)
            event.accept()
            return
        if event.modifiers() & QtCore.Qt.ControlModifier:
            zoom_factor = 1.1 if delta > 0 else 1 / 1.1
            selected = self.scene().selected_canvas_items()
            for item in selected:
                item.setScale(item.scale() * zoom_factor)
            if selected:
                self._wheel_timer.start()
            return

        if not delta:
            return
        if not self._zoom_timer.isActive():
            self._zoom_target = self.transform().m11()

        self._zoom_target = max(MIN_ZOOM, min(MAX_ZOOM, self._zoom_target * _zoom_per_notch() ** (delta / 120.0)))
        self._zoom_anchor_view = _event_pos(event)
        self._zoom_anchor_scene = self.mapToScene(self._zoom_anchor_view.toPoint())
        if not self._zoom_timer.isActive():
            self._zoom_timer.start()
            self._begin_zoom_cache()
            self._zoom_last_tick = time.perf_counter()
        event.accept()

    def mouseDoubleClickEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton and self.current_tool == 'select':
            target = _canvas_target(self.itemAt(event.pos()))
            if isinstance(target, LinkNode):
                if target.remove_point_at(self.mapToScene(event.pos())):
                    self._emit_changed()
                else:
                    self.edit_link_label(target)
                return
            if isinstance(target, ImageNode) and not _is_locked(target) and target.cropper is None:
                target.start_crop()
                return
        if event.button() == QtCore.Qt.LeftButton and not self.itemAt(event.pos()) and self.current_tool == 'select':
            node = self._add_text_node('<span style="%s">New note</span>' % self._font_style(), self.mapToScene(event.pos()))
            self._emit_changed()



            cursor = node.textCursor()
            cursor.select(QtGui.QTextCursor.Document)
            node.start_editing(cursor)
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def _menu(self):
        menu = QtWidgets.QMenu(self)
        menu.setStyleSheet(_style("""
            QMenu { background: %(panel)s; color: %(text)s; border: 1px solid %(panel_border)s; padding: 4px; }
            QMenu::item { padding: 6px 24px 6px 12px; border-radius: 4px; }
            QMenu::item:selected { background: %(accent_strong)s; color: #ffffff; }
            QMenu::item:disabled { color: %(caption)s; }
            QMenu::separator { height: 1px; background: %(menu_sep)s; margin: 4px 8px; }
        """))
        _plain_menu(menu)
        return menu

    @staticmethod
    def _add(menu, text, fn):
        action = menu.addAction(text)
        action.triggered.connect(lambda checked=False: fn())
        return action

    def show_context_menu(self, event, target):
        menu = self._menu()
        scene = self.scene()
        if isinstance(target, LinkNode):
            if not target.isSelected():
                scene.clearSelection()
                target.setSelected(True)
            self._add(menu, "🏷  Edit label…\tDouble-click", lambda: self.edit_link_label(target))
            self._add(menu, ("⏹  Stop live flow" if target.flow else "✨  Live flow"), self.toggle_flow_selection)
            arrows = menu.addMenu("➡️  Arrows")
            for label, value in (('None', 0), ('At the end', 1), ('Both ends', 2)):
                self._add(arrows, ('● ' if target.arrows == value else '   ') + label,
                          lambda v=value: self.apply_style_to_selection(arrows=v) and self._emit_changed())
            lines = menu.addMenu("〰️  Line style")
            for value, label in LINE_STYLES:
                self._add(lines, ('● ' if target.dash == value else '   ') + label,
                          lambda v=value: self.apply_style_to_selection(dash=v) and self._emit_changed())
            menu.addSeparator()
            self._add(menu, "🗑  Delete\tDel", self.delete_selection)
            _exec(menu, self.mapToGlobal(event.pos()))
            menu.deleteLater()
            return

        if not target.isSelected():
            scene.clearSelection()
            target.setSelected(True)
        targets = scene.selected_canvas_items()
        locked = all(_is_locked(i) for i in targets)
        self._add(menu, ("🔓  Unlock" if locked else "🔒  Lock") + "\tCtrl+Shift+L", self.toggle_lock_selection)
        group_ids = {getattr(i, 'group_id', None) for i in targets}
        already_grouped = len(group_ids) == 1 and None not in group_ids
        if len(targets) >= 2 and not already_grouped:
            self._add(menu, "🔗  Group\tCtrl+G", self.group_selection)
        if any(getattr(i, 'group_id', None) for i in targets):
            self._add(menu, "✂️  Ungroup\tCtrl+Shift+G", self.ungroup_selection)
        self._add(menu, "🔲  Wrap in frame\tCtrl+Alt+G", self.wrap_selection_in_frame)

        if isinstance(target, ImageNode) and len(targets) == 1:
            menu.addSeparator()
            self._add(menu, "✂️  Crop\tDouble-click", target.start_crop)
            opacity = menu.addMenu("🌗  Opacity")
            for value in (100, 75, 50, 25):
                def set_opacity(v=value):
                    target.setOpacity(v / 100.0)
                    self._emit_changed()
                self._add(opacity, ('● ' if round(target.opacity() * 100) == value else '   ') + '%d%%' % value, set_opacity)
            self._add(menu, "📋  Copy image", lambda: (target.copy_to_clipboard(), self.show_toast('Image copied')))

            def save_image():
                path = target.save_as(self.window())
                if path:
                    self.show_toast('Saved to %s' % os.path.basename(path))
            self._add(menu, "💾  Save image as…", save_image)
            self._add(menu, "ℹ️  Show info", lambda: QtWidgets.QMessageBox.information(self.window(), 'Image info', target.info_text()))

        if isinstance(target, YouTubeNode) and len(targets) == 1:
            menu.addSeparator()
            self._add(menu, "▶️  Open on YouTube\tDouble-click", target.open_video)
            self._add(menu, "🔗  Copy link", lambda: (target.copy_link(), self.show_toast('Link copied')))
            self._add(menu, "🔄  Refresh title and preview", target.refresh)

        stickies = [i for i in targets if isinstance(i, TextNode) and i.is_sticky]
        if stickies:
            menu.addSeparator()
            colors = menu.addMenu("🎨  Sticky color")
            for color in STICKY_COLORS:
                def set_color(c=color):
                    for sticky in stickies:
                        sticky.set_bg(c)
                    self.sticky_color = c
                    self._emit_changed()
                colors.addAction(_swatch_icon(color), color).triggered.connect(lambda checked=False, f=set_color: f())

        if isinstance(target, FrameNode):
            menu.addSeparator()
            self._add(menu, "📐  Fit frame to content", lambda: target.fit_to_content() and self._emit_changed())
            self._add(menu, "▸  Expand frame" if target.collapsed else "▾  Collapse frame", target.toggle_collapse)

        menu.addSeparator()
        if sum(1 for i in targets if not _is_locked(i)) >= 2:
            align = menu.addMenu("📏  Align")
            for entry in (("⬅️  Left", 'left'), ("↔️  Center", 'hcenter'), ("➡️  Right", 'right'), None,
                          ("⬆️  Top", 'top'), ("↕️  Middle", 'vcenter'), ("⬇️  Bottom", 'bottom')):
                if entry is None:
                    align.addSeparator()
                    continue
                self._add(align, entry[0], lambda m=entry[1]: self.align_selection(m))
        order = menu.addMenu("🧱  Order")
        for text, mode in (("⏫  Bring to front\tCtrl+Shift+]", 'front'), ("🔺  Bring forward\tCtrl+]", 'forward'),
                           ("🔻  Send backward\tCtrl+[", 'backward'), ("⏬  Send to back\tCtrl+Shift+[", 'back')):
            self._add(order, text, lambda m=mode: self.reorder_selected(m, targets))
        self._add(menu, "📄  Duplicate\tCtrl+D", self.duplicate_selection)
        self._add(menu, "🗑  Delete\tDel", self.delete_selection)
        _exec(menu, self.mapToGlobal(event.pos()))
        menu.deleteLater()

    def show_canvas_menu(self, event):
        pass
        menu = self._menu()
        pos = self.mapToScene(event.pos())
        self._add(menu, "📋  Paste\tCtrl+V", self.paste_from_clipboard)
        menu.addSeparator()

        def add_sticky():
            self._add_text_node('<span style="%s color: #141414;">New sticky</span>' % self._font_style(), pos,
                                is_sticky=True, bg=self.sticky_color, text_width=STICKY_WIDTH)
            self._emit_changed()

        def add_note():
            self._add_text_node('<span style="%s">New note</span>' % self._font_style(), pos)
            self._emit_changed()

        def add_frame():
            scene = self.scene()
            count = sum(1 for i in scene.canvas_items() if isinstance(i, FrameNode))
            frame = FrameNode(QtCore.QRectF(0, 0, 640, 440), title='Frame %d' % (count + 1), color=QtGui.QColor(*GLOW_COLOR).name())
            frame.setPos(pos)
            frame.setZValue(min([i.zValue() for i in scene.canvas_items()] or [0]) - 1)
            scene.addItem(frame)
            self._emit_changed()

        self._add(menu, "📝  Add sticky here", add_sticky)
        self._add(menu, "🗒  Add note here", add_note)
        self._add(menu, "🔲  Add frame here", add_frame)
        menu.addSeparator()
        links = self.scene().link_items()
        if links:
            all_flow = all(l.flow for l in links)
            self._add(menu, "⏹  Stop live flow on all links" if all_flow else "✨  Live flow on all links",
                      lambda: self.set_links_flow(links, not all_flow))
        self._add(menu, "☑️  Select all\tCtrl+A", self.select_all)
        self._add(menu, "🔍  Show everything\tShift+1", self.fit_all)
        _exec(menu, self.mapToGlobal(event.pos()))
        menu.deleteLater()

    def keyPressEvent(self, event):
        focus_item = self.scene().focusItem()
        if isinstance(focus_item, TextNode) and focus_item.is_editing():
            super().keyPressEvent(event)
            return

        crop_image = self.scene().active_crop
        if crop_image is not None and event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter, QtCore.Qt.Key_Escape):
            crop_image.finish_crop(apply=event.key() != QtCore.Qt.Key_Escape)
            return

        if event.key() == QtCore.Qt.Key_Space and not event.isAutoRepeat():
            self._space_held = True
            self._update_cursor()
            return

        if self.handle_canvas_shortcut(event):
            return

        arrows = {QtCore.Qt.Key_Left: (-1, 0), QtCore.Qt.Key_Right: (1, 0), QtCore.Qt.Key_Up: (0, -1), QtCore.Qt.Key_Down: (0, 1)}
        if event.key() in arrows and not event.modifiers() & QtCore.Qt.ControlModifier:

            step = (SETTINGS['grid_size'] if self.grid_enabled else 10) if event.modifiers() & QtCore.Qt.ShiftModifier else 1
            dx, dy = arrows[event.key()]
            self.nudge_selection(dx * step, dy * step)
            return

        if event.key() == QtCore.Qt.Key_Escape:
            self.scene().clearSelection()
            return

        if event.key() in (QtCore.Qt.Key_Delete, QtCore.Qt.Key_Backspace):
            if self.delete_selection():
                return
        super().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        if event.key() == QtCore.Qt.Key_Space and not event.isAutoRepeat():
            self._space_held = False
            if self._pan_start is None:
                self._update_cursor()
            return
        super().keyReleaseEvent(event)

    def focusOutEvent(self, event):
        self._space_held = False
        super().focusOutEvent(event)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls() or event.mimeData().hasImage() or event.mimeData().hasText():
            event.acceptProposedAction()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls() or event.mimeData().hasImage() or event.mimeData().hasText():
            event.acceptProposedAction()

    def dropEvent(self, event):
        downloads = self._downloads
        added = self._insert_mime(event.mimeData(), self.mapToScene(_event_pos(event).toPoint()))
        event.acceptProposedAction()
        if added:
            self._emit_changed()
        elif self._downloads == downloads:
            self.show_toast('Nothing to add: drop images, YouTube links or text')

class PresentationView(QtWidgets.QGraphicsView):
    pass


    THUMB_W, THUMB_H = 160, 96
    STRIP_ZONE = 0.22

    def __init__(self, scene, frames):
        super().__init__(scene)
        self.frames = frames
        self.index = 0
        self._anim = None
        self.setWindowFlags(QtCore.Qt.Window | QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.setInteractive(False)
        self.setRenderHint(QtGui.QPainter.Antialiasing)
        self.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        self.setTransformationAnchor(QtWidgets.QGraphicsView.NoAnchor)
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.setBackgroundBrush(QtGui.QColor(12, 12, 12))
        self.setSceneRect(-SCENE_HALF, -SCENE_HALF, 2 * SCENE_HALF, 2 * SCENE_HALF)
        self.setMouseTracking(True)
        self.viewport().setMouseTracking(True)
        self.counter = QtWidgets.QLabel(self)
        self.counter.setStyleSheet("color: #bbbbbb; background: rgba(0,0,0,150); border-radius: 10px; "
                                   "padding: 4px 12px; font-size: 13px;")


        arrow_style = ("QToolButton { color: rgba(255,255,255,170); background: rgba(0,0,0,90); border: none;"
                       " border-radius: 28px; font-size: 34px; font-weight: bold; }"
                       "QToolButton:hover { color: #ffffff; background: rgba(0,0,0,170); }"
                       "QToolButton:disabled { color: rgba(255,255,255,40); background: rgba(0,0,0,40); }")
        self.btn_prev = QtWidgets.QToolButton(self)
        self.btn_next = QtWidgets.QToolButton(self)
        for btn, text, step in ((self.btn_prev, '‹', -1), (self.btn_next, '›', 1)):
            btn.setText(text)
            btn.setFixedSize(56, 56)
            btn.setCursor(QtCore.Qt.PointingHandCursor)
            btn.setFocusPolicy(QtCore.Qt.NoFocus)
            btn.setStyleSheet(arrow_style)
            btn.clicked.connect(lambda checked=False, s=step: self.go(self.index + s))


        self.strip = QtWidgets.QScrollArea(self)
        self.strip.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.strip.setWidgetResizable(True)
        self.strip.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.strip.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.strip.setFixedHeight(self.THUMB_H + 34)
        self.strip.setStyleSheet(
            "QScrollArea { background: rgba(0,0,0,170); border-radius: 12px; }"
            "QScrollArea > QWidget > QWidget { background: transparent; }"
            "QScrollBar:horizontal { height: 6px; background: transparent; }"
            "QScrollBar::handle:horizontal { background: rgba(255,255,255,80); border-radius: 3px; }"
            "QScrollBar::add-line, QScrollBar::sub-line { width: 0px; }"
            "QToolButton { background: transparent; border: 2px solid transparent; border-radius: 6px; padding: 2px; }"
            "QToolButton:hover { border-color: rgba(255,255,255,120); }"
            "QToolButton:checked { border-color: %s; }" % QtGui.QColor(*GLOW_COLOR).name())
        holder = QtWidgets.QWidget()
        row = QtWidgets.QHBoxLayout(holder)
        row.setContentsMargins(10, 8, 10, 8)
        row.setSpacing(8)
        self.thumbs = []
        for k, frame in enumerate(frames):
            btn = QtWidgets.QToolButton()
            btn.setCheckable(True)
            btn.setFocusPolicy(QtCore.Qt.NoFocus)
            btn.setCursor(QtCore.Qt.PointingHandCursor)
            btn.setToolTip('%d. %s' % (k + 1, frame.title))
            btn.setIconSize(QtCore.QSize(self.THUMB_W, self.THUMB_H))
            btn.clicked.connect(lambda checked=False, i=k: self.go(i))
            row.addWidget(btn)
            self.thumbs.append(btn)
        row.addStretch()
        self.strip.setWidget(holder)
        self.strip.hide()

    def _render_thumbs(self):
        scene = self.scene()
        for frame, btn in zip(self.frames, self.thumbs):
            pixmap = QtGui.QPixmap(self.THUMB_W, self.THUMB_H)
            pixmap.fill(QtGui.QColor(28, 28, 28))
            painter = QtGui.QPainter(pixmap)
            painter.setRenderHint(QtGui.QPainter.Antialiasing)
            painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
            scene.render(painter, QtCore.QRectF(pixmap.rect()), self._slide_rect(frame))
            painter.end()
            btn.setIcon(QtGui.QIcon(pixmap))

    def start(self):
        self.scene().clearSelection()
        self._render_thumbs()
        self.showFullScreen()
        self.setFocus()
        QtCore.QTimer.singleShot(60, lambda: self.go(0, animate=False))

    def _slide_rect(self, frame):
        return frame.sceneBoundingRect().adjusted(-30, -30, 30, 30)

    def go(self, index, animate=True):
        if not self.frames:
            return
        self.index = max(0, min(index, len(self.frames) - 1))
        frame = self.frames[self.index]
        self.counter.setText('%s   %d / %d' % (frame.title, self.index + 1, len(self.frames)))
        self.counter.adjustSize()
        self.btn_prev.setEnabled(self.index > 0)
        self.btn_next.setEnabled(self.index < len(self.frames) - 1)
        for k, btn in enumerate(self.thumbs):
            btn.setChecked(k == self.index)
        if self.thumbs:
            self.strip.ensureWidgetVisible(self.thumbs[self.index], 60, 0)
        self._place_overlays()
        _stop_animation(self._anim)
        self._anim, _ = _fly_to(self, self._slide_rect(frame), duration=450 if animate else 1)

    def _place_overlays(self):
        w, h = self.width(), self.height()
        strip_w = min(w - 80, len(self.thumbs) * (self.THUMB_W + 18) + 30)
        self.strip.setFixedWidth(max(200, strip_w))
        self.strip.move((w - self.strip.width()) // 2, h - self.strip.height() - 20)
        bottom = self.strip.y() - 10 if self.strip.isVisible() else h - 24
        self.counter.move((w - self.counter.width()) // 2, bottom - self.counter.height())
        self.btn_prev.move(24, (h - self.btn_prev.height()) // 2)
        self.btn_next.move(w - self.btn_next.width() - 24, (h - self.btn_next.height()) // 2)

    def _update_strip(self, y):
        show = y > self.height() * (1.0 - self.STRIP_ZONE)
        if show != self.strip.isVisible():
            self.strip.setVisible(show)
            self._place_overlays()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._place_overlays()

    def mouseMoveEvent(self, event):
        self._update_strip(event.pos().y())
        event.accept()

    def keyPressEvent(self, event):
        key = event.key()
        if key == QtCore.Qt.Key_Escape:
            self.close()
        elif key in (QtCore.Qt.Key_Right, QtCore.Qt.Key_Space, QtCore.Qt.Key_PageDown, QtCore.Qt.Key_Down):
            self.go(self.index + 1)
        elif key in (QtCore.Qt.Key_Left, QtCore.Qt.Key_PageUp, QtCore.Qt.Key_Up, QtCore.Qt.Key_Backspace):
            self.go(self.index - 1)
        elif key == QtCore.Qt.Key_Home:
            self.go(0)
        elif key == QtCore.Qt.Key_End:
            self.go(len(self.frames) - 1)

    def mousePressEvent(self, event):

        back = event.button() == QtCore.Qt.RightButton or event.pos().x() < self.viewport().width() / 2
        self.go(self.index + (-1 if back else 1))

    def wheelEvent(self, event):
        event.accept()
