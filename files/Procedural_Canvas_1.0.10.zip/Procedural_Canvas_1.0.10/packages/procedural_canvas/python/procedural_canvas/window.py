pass

from ._link import pull
pull(globals())




def _houdini_main_window():
    pass
    qt = getattr(hou, 'qt', None)
    return qt.mainWindow() if qt is not None else None


class MiroCanvasWindow(QtWidgets.QWidget):
    pass

    def __init__(self, node, embedded=False):
        if not ensure_licensed(_houdini_main_window()):
            raise LicenseRequired('%s: no license key' % PLUGIN_NAME)
        super().__init__(None if embedded else _houdini_main_window())
        self.embedded = embedded
        self.on_shutdown = None
        if not embedded:
            self.setWindowFlags(self.windowFlags() | QtCore.Qt.Window)
            self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
            self.resize(1600, 900)

        self.node = node
        self.session_id = node.sessionId()
        self.undo_stack = []
        self.redo_stack = []
        self._restoring = False
        self._save_enabled = True
        self._read_only_reason = None
        self._last_saved_state = None
        self._save_failed = False
        self._torn_down = False
        self._shown_once = False

        self._preview_item = None
        self._preview_states = []
        self._recent_colors = []
        self._last_text_color = '#ffffff'
        self._color_popup = None
        self._tutorial = None
        self._density = None
        self._restore_geometry = None

        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        self.scene = CanvasScene(node, self)


        self.view = MiroView(self.scene)

        self._shortcuts_overlay = None
        self._build_ui()
        self.main_layout.addWidget(self.view)
        self._build_status_bar()
        self.apply_theme()
        self._setup_hotkeys()
        if GPU_VIEWPORT and SETTINGS['gpu'] and (not embedded or SETTINGS['gpu_docked']):
            self.view.set_gpu(True)
        self.view.color_picked.connect(self._on_color_picked)
        self.view.brush_size_requested.connect(self._set_brush_size)
        self.view.help_requested.connect(self.toggle_shortcuts)

        self._save_timer = QtCore.QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(SAVE_DELAY_MS)
        self._save_timer.timeout.connect(self._on_save_timer)


        self._save_worker = _SaveWorker(self)
        self._save_worker.done.connect(self._on_payload_ready)
        self._save_generation = 0
        self._save_in_flight = False
        self._save_again = False

        self.scene.canvas_changed.connect(self.record_history)
        recheck_later()
        check_updates(self._on_update_found, self._on_update_installed)
        self.scene.history_amend.connect(self.amend_history)
        self.scene.request_save.connect(self.schedule_save)
        self.view.tool_finished.connect(lambda: self.tool_combo.setCurrentIndex(0))
        self.view.present_requested.connect(self.start_presentation)

        self._load()
        state = self.scene.snapshot()
        self.undo_stack = [state]
        self._last_saved_state = state
        self._register_callbacks()
        self._update_title()
        self._remove_legacy_thumbnail()
        self.update_node_summary()


    def showEvent(self, event):
        if not self._shown_once:
            self._shown_once = True



            self.view.schedule_minimap()
        super().showEvent(event)

    def shutdown(self):
        pass
        if self._torn_down:
            return
        presentation, self._presentation = getattr(self, '_presentation', None), None
        if presentation is not None:
            try:
                presentation.close()
            except RuntimeError:
                pass
        try:
            self._end_preview()
            focus_item = self.scene.focusItem()
            if focus_item is not None:
                focus_item.clearFocus()
            self.record_history()
            self.flush_save()
            self.update_node_summary()
        except Exception:


            _log_error('Error while closing the board')
        finally:
            self._teardown()
        callback, self.on_shutdown = self.on_shutdown, None
        if callback is not None:
            callback(self)

    def request_close(self):
        if self.embedded:
            self.shutdown()
        else:
            self.close()

    def closeEvent(self, event):
        self.shutdown()
        super().closeEvent(event)

    def changeEvent(self, event):
        pass


        super().changeEvent(event)
        if (self.embedded or not EMULATE_MAXIMIZE or event.type() != QtCore.QEvent.WindowStateChange
                or not self.windowState() & QtCore.Qt.WindowMaximized):
            return
        QtCore.QTimer.singleShot(0, self._fake_maximize)

    def _fake_maximize(self):
        try:
            if not self.windowState() & QtCore.Qt.WindowMaximized:
                return
            screen = self.screen() or QtGui.QGuiApplication.primaryScreen()
            available = screen.availableGeometry()
            self.setWindowState(QtCore.Qt.WindowNoState)
            frame, inner = self.frameGeometry(), self.geometry()
            margins = (inner.left() - frame.left(), inner.top() - frame.top(),
                       frame.right() - inner.right(), frame.bottom() - inner.bottom())
            full = available.adjusted(margins[0], margins[1], -margins[2], -margins[3])
            if self._restore_geometry is not None and abs(inner.width() - full.width()) < 8 \
                    and abs(inner.height() - full.height()) < 8:

                self.setGeometry(self._restore_geometry)
                self._restore_geometry = None
                return
            normal = self.normalGeometry()
            self._restore_geometry = normal if normal.isValid() and normal.width() > 0 else QtCore.QRect(inner)
            self.setGeometry(full)
        except RuntimeError:
            pass

    def _register_callbacks(self):
        self._node_event_types = (hou.nodeEventType.BeingDeleted, hou.nodeEventType.NameChanged)
        self._node_cb = self._on_node_event
        self._hip_cb = self._on_hip_event
        self.node.addEventCallback(self._node_event_types, self._node_cb)
        hou.hipFile.addEventCallback(self._hip_cb)

    def _teardown(self):
        if self._torn_down:
            return
        self._torn_down = True
        self._save_timer.stop()
        try:
            self.node.removeEventCallback(self._node_event_types, self._node_cb)
        except (hou.Error, AttributeError):
            pass
        try:
            hou.hipFile.removeEventCallback(self._hip_cb)
        except (hou.Error, AttributeError):
            pass
        if _CANVAS_WINDOWS.get(self.session_id) is self:
            del _CANVAS_WINDOWS[self.session_id]
        self.undo_stack, self.redo_stack = [], []

        try:
            self.scene.release()
        except RuntimeError:
            pass

    def _on_node_event(self, event_type, **kwargs):
        if event_type == hou.nodeEventType.BeingDeleted:
            self._set_read_only('node deleted')
            QtCore.QTimer.singleShot(0, self.request_close)
        elif event_type == hou.nodeEventType.NameChanged:
            self._update_title()

    def _on_hip_event(self, event_type):
        if event_type == hou.hipFileEventType.BeforeSave:
            self.flush_save()
        elif event_type == hou.hipFileEventType.BeforeClear:
            self._set_read_only('scene is closing')
            QtCore.QTimer.singleShot(0, self.request_close)

    def _set_read_only(self, reason):
        self._save_enabled = False
        self._read_only_reason = reason
        self._save_timer.stop()
        self._update_title()
        self._set_save_state('Not saving: %s' % reason)

    def _update_title(self):
        try:
            name = self.node.name()
        except hou.Error:
            name = '?'
        title = f"Procedural Canvas: {name}"
        if not self._save_enabled:
            title += f"  [not saving: {self._read_only_reason}]"
        elif self._save_failed:
            title += "  [SAVE FAILED]"
        self.setWindowTitle(title)


    def _load(self):
        parm = self.node.parm(PARM_NAME)
        if parm is None:
            self._set_read_only(f'no "{PARM_NAME}" parameter')
            QtWidgets.QMessageBox.warning(self.parentWidget(), 'Procedural Canvas',
                                          f'This node has no "{PARM_NAME}" string parameter. Changes will not be saved.')
            return
        try:
            raw = parm.unexpandedString()
        except hou.Error:
            raw = parm.evalAsString()
        if not raw.strip():
            return
        try:
            doc = decode_payload(raw)
            if isinstance(doc, list):
                doc = migrate_legacy(doc)
            version = doc.get('version', 0)
            problems = self.scene.load_document(doc)
        except Exception:
            _log_error('Could not read canvas data')
            self._handle_load_failure(raw)
            return
        if version > FORMAT_VERSION:
            self._set_read_only('board is from a newer version')
            QtWidgets.QMessageBox.warning(self.parentWidget(), 'Procedural Canvas',
                                          f'This board was saved by a newer version of the tool (format v{version}). '
                                          'It is opened without saving to avoid damaging the data.')
        elif problems:
            QtWidgets.QMessageBox.warning(self.parentWidget(), 'Procedural Canvas',
                                          f'{len(problems)} item(s) could not be displayed. They were not deleted '
                                          'and stay in the node data. See the Python console for details.')

    def _write_backup(self, raw):
        folder = hou.getenv('HOUDINI_TEMP_DIR') or tempfile.gettempdir()
        path = os.path.join(folder, 'canvas_backup_%s_%s.txt' % (self.node.name(), time.strftime('%Y%m%d_%H%M%S')))
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(raw)
            return path
        except OSError:
            _log_error('Could not write a backup')
            return None

    def _handle_load_failure(self, raw):
        self._set_read_only('data could not be read')
        backup = self._write_backup(raw)
        box = QtWidgets.QMessageBox(self.parentWidget())
        box.setIcon(QtWidgets.QMessageBox.Warning)
        box.setWindowTitle('Procedural Canvas')
        text = 'The saved canvas data could not be read.\n\n'
        if backup:
            text += f'The original data was backed up to:\n{backup}\n\n'
        else:
            text += 'A backup could NOT be written.\n\n'
        text += ('"View only" opens an empty canvas and leaves the node data untouched.\n'
                 '"Start over" lets new changes overwrite the old data in the node.')
        box.setText(text)
        view_only = box.addButton('View only', QtWidgets.QMessageBox.RejectRole)
        start_fresh = box.addButton('Start over', QtWidgets.QMessageBox.DestructiveRole)
        box.setDefaultButton(view_only)
        _exec(box)
        if box.clickedButton() == start_fresh:
            self._save_enabled = True
            self._read_only_reason = None

    def schedule_save(self):
        if self._save_enabled and not self._restoring and not self._torn_down and self._preview_item is None:
            self._save_timer.start()
            self._set_save_state('Unsaved changes')

    def _on_save_timer(self):
        if _mouse_pressed():
            self._save_timer.start()
            return
        self.flush_save(sync=False)

    def flush_save(self, sync=True):
        pass

        self._save_timer.stop()
        if not self._save_enabled:
            return
        state = self.scene.snapshot()
        if state == self._last_saved_state:
            self._set_save_state('Saved')
            return
        try:
            doc = self.scene.to_document(state)
        except Exception:
            _log_error('Could not save the canvas to the node')
            self._report_save_failure()
            return
        self._save_generation += 1
        if sync:
            self._apply_payload(encode_payload(doc), state)
            return
        if self._save_in_flight:
            self._save_again = True
            return
        self._save_in_flight = True
        self._save_worker.start(doc, state, self._save_generation)

    def _on_payload_ready(self, payload, state, generation):
        self._save_in_flight = False
        if self._torn_down:
            return
        if generation == self._save_generation:
            self._apply_payload(payload, state)
        if self._save_again:
            self._save_again = False
            self.schedule_save()

    def _apply_payload(self, payload, state):
        try:
            parm = self.node.parm(PARM_NAME)
            if parm is None:
                return
            with hou.undos.disabler():
                parm.set(payload)
            self._last_saved_state = state
        except hou.ObjectWasDeleted:
            self._set_read_only('node deleted')
            return
        except Exception:
            _log_error('Could not save the canvas to the node')
            self._report_save_failure()
            return
        self._set_save_state('Saved ' + time.strftime('%H:%M:%S'))
        if self._save_failed:
            self._save_failed = False
            self._update_title()
            self.view.show_toast('Board saved again')
        self.update_node_summary()

    def _safe_node_name(self):
        try:
            return self.node.name()
        except hou.Error:
            return '?'

    def _report_save_failure(self):
        pass

        first = not self._save_failed
        self._save_failed = True
        self._update_title()
        self._set_save_state('Save failed')
        if first:
            reason = ''
            try:
                if self.node.isInsideLockedHDA() or self.node.parm(PARM_NAME).isLocked():
                    reason = '\nThe node or its parameter is locked — unlock it (or Allow Editing of Contents).'
                elif 'take' in traceback.format_exc().lower():
                    reason = '\nThe parameter is not included in the current take — switch to the main take or include it.'
            except Exception:
                pass
            QtWidgets.QMessageBox.warning(
                self, 'Procedural Canvas',
                'Could not save the board into the node "%s".%s\n\nYour changes are kept in this window and '
                'saving will be retried. Details are in the Houdini console.' % (self._safe_node_name(), reason))


    def _summary(self):
        items = self.scene.canvas_items()
        notes = sum(1 for i in items if isinstance(i, TextNode))
        images = sum(1 for i in items if isinstance(i, ImageNode))
        frames = sum(1 for i in items if isinstance(i, FrameNode))
        parts = ['%d notes' % notes, '%d images' % images]
        if frames:
            parts.append('%d frames' % frames)
        return 'Canvas: %s | edited %s' % (', '.join(parts), time.strftime('%H:%M'))

    def update_node_summary(self):
        pass

        if not self._save_enabled:
            return
        try:
            ours = self.node.userData(UD_COMMENT) or ''
            current = self.node.comment()
            if current and current != ours:
                return
            text = self._summary() if SETTINGS['node_summary'] and self.scene.canvas_items() else ''
            if text == current:
                return
            with hou.undos.disabler():
                self.node.setComment(text)
                self.node.setUserData(UD_COMMENT, text)
                self.node.setGenericFlag(hou.nodeFlag.DisplayComment, bool(text))
        except hou.Error:
            pass

    def _remove_legacy_thumbnail(self):
        pass
        try:
            cid = self.node.userData(UD_CANVAS_ID)
            if not cid:
                return
            import nodegraphutils
            parent = self.node.parent()
            images = list(nodegraphutils.loadBackgroundImages(parent))
            kept = [img for img in images if cid not in img.path()]
            if len(kept) != len(images):
                with hou.undos.disabler():
                    nodegraphutils.saveBackgroundImages(parent, kept)
                for pane in hou.ui.paneTabs():
                    if isinstance(pane, hou.NetworkEditor) and pane.pwd() == parent:
                        pane.setBackgroundImages(kept)
            folder = hou.text.expandString(LEGACY_THUMB_DIR)
            if os.path.isdir(folder):
                for name in os.listdir(folder):
                    if name.startswith(cid + '_'):
                        os.remove(os.path.join(folder, name))
        except Exception:
            pass


    def record_history(self):
        if self._restoring or self._torn_down or self._preview_item is not None:
            return
        state = self.scene.snapshot()
        if self.undo_stack and self.undo_stack[-1] == state:
            return
        self.undo_stack.append(state)
        dropped = bool(self.redo_stack)
        self.redo_stack.clear()
        if len(self.undo_stack) > HISTORY_LIMIT:
            self.undo_stack.pop(0)
            dropped = True
        if dropped:
            self.scene.prune_assets(self.undo_stack)
        self.schedule_save()

    def _on_update_found(self, version, url, notes):
        try:
            self.view.show_toast('Update %s is available — see Settings → About' % version)
        except RuntimeError:
            pass

    def _on_update_installed(self, version, notes):
        try:
            self.view.show_toast('%s updated to %s — restart Houdini to use it' % (PLUGIN_NAME, version))
        except RuntimeError:
            pass

    def amend_history(self):
        pass

        if self._restoring or self._torn_down:
            return
        if self.undo_stack:
            self.undo_stack[-1] = self.scene.snapshot()
        self.schedule_save()

    def _restore(self, state):
        self._restoring = True
        try:
            self.scene.restore(state)
        finally:
            self._restoring = False



        self.undo_stack[-1] = self.scene.snapshot()
        self.schedule_save()
        self.view.schedule_minimap()

    def _cancel_crop(self):
        pass

        crop_image = self.scene.active_crop
        if crop_image is None:
            return False
        crop_image.finish_crop(apply=False)
        return True

    def undo(self):
        if self._cancel_crop():
            return
        self._end_preview()
        self.record_history()
        if len(self.undo_stack) > 1:
            self.redo_stack.append(self.undo_stack.pop())
            self._restore(self.undo_stack[-1])

    def redo(self):
        if self._cancel_crop():
            return
        self._end_preview()
        if self.redo_stack:
            self.undo_stack.append(self.redo_stack.pop())
            self._restore(self.undo_stack[-1])

    def keyPressEvent(self, event):
        if _ctrl_letter(event, 'Z'):
            self.undo()
            return
        if _ctrl_letter(event, 'Z', shift=True) or _ctrl_letter(event, 'Y'):
            self.redo()
            return

        if self.view.handle_canvas_shortcut(event):
            return
        super().keyPressEvent(event)


    def _create_btn(self, text, tooltip, callback):
        btn = QtWidgets.QToolButton()
        icon = _button_icon(text) if text and any(ord(ch) > 0x2000 for ch in text) else None
        if icon is not None:
            btn.setIcon(icon)
            btn.setToolButtonStyle(QtCore.Qt.ToolButtonIconOnly)
        elif text and any(ord(ch) > 0x2000 for ch in text):
            btn.setText(_button_label(text))
        else:
            btn.setText(text)
        btn.setToolTip(tooltip)
        if callback is not None:
            btn.clicked.connect(callback)
        self._sized_buttons.append(btn)
        return btn

    def _menu_button(self, text, tooltip, fill_menu):
        pass

        btn = self._create_btn(text, tooltip, None)
        btn.setPopupMode(QtWidgets.QToolButton.InstantPopup)
        menu = QtWidgets.QMenu(btn)
        menu.aboutToShow.connect(lambda: (menu.clear(), fill_menu(menu)))
        _plain_menu(menu)
        btn.setMenu(menu)
        HoverOpener(btn, lambda: menu.popup(btn.mapToGlobal(QtCore.QPoint(0, btn.height() + 2))),
                    lambda: menu, menu.close)
        return btn

    @staticmethod
    def _add_actions(menu, entries):
        for entry in entries:
            if entry is None:
                menu.addSeparator()
                continue
            action = menu.addAction(entry[0])
            action.triggered.connect(lambda checked=False, fn=entry[1]: fn())


    def start_tutorial(self):
        if self._tutorial is not None:
            try:
                self._tutorial.finish()
            except RuntimeError:
                pass
        steps = [
            {'widget': lambda: self.text_tools,
             'title': 'Text',
             'text': 'Press <b>N</b> for a note, <b>S</b> for a sticky, <b>C</b> for a code block, or double-click '
                     'an empty spot. Font, size, bold, italic, lists, checklists and colors live here.<br><br>'
                     'Select a few characters to style only them, or the whole note to style all of it. '
                     'Hover a font or a color to preview it. New notes use the font and size chosen here.'},
            {'widget': lambda: self.draw_tools,
             'title': 'Draw',
             'text': 'Pick a tool: brushes with a stabilizer (Smooth, Ink, Calligraphy, Chalk, Neon), highlighter, '
                     'shapes, arrows and links between elements.<br><br>'
                     'Color, fill, line style and size apply to new strokes and to whatever is selected. '
                     'Hold <b>Shift</b> for straight lines, use the eraser for parts of a stroke, '
                     'and <b>Ctrl + wheel</b> over the board to resize the brush.'},
            {'widget': lambda: self.view_tools,
             'title': 'View',
             'text': 'Grid and snapping, image rounding and search (<b>Ctrl+F</b>).<br><br>'
                     'Navigate with the mouse wheel to zoom, <b>Space + drag</b> or the middle button to pan, '
                     'and <b>F</b> to fit everything. Frames turn into full-screen slides in presentation mode.'},
            {'widget': lambda: self.board_tools,
             'title': 'Board',
             'text': 'Take a snapshot of the Houdini viewport straight onto the board, dock the board next to '
                     'Parameters or open it in a separate window that can stay on top while you drag images '
                     'from a browser.<br><br>'
                     'Shortcuts (<b>?</b>), this tutorial and Settings are here too. The board autosaves into '
                     'the node, and <b>Ctrl+S</b> in Houdini saves it with the scene.'},
            {'widget': lambda: self.view.minimap,
             'title': 'Minimap',
             'text': 'The whole board at a glance. The highlighted rectangle is what you see right now.<br><br>'
                     'Click or drag on the minimap to jump anywhere on the board. '
                     'Paste images, files, links and text from anywhere with <b>Ctrl+V</b> — that is all you need to start.'},
        ]
        self._tutorial = TutorialOverlay(self, steps)
        self._tutorial.start()


    def _sorted_frames(self):
        frames = [i for i in self.scene.canvas_items() if isinstance(i, FrameNode)]

        return sorted(frames, key=lambda f: (round(f.sceneBoundingRect().top() / 50.0), f.sceneBoundingRect().left()))

    def _fill_frames_menu(self, menu):
        frames = self._sorted_frames()
        if not frames:
            menu.addAction('No frames yet — draw one with the Frame tool (F)').setEnabled(False)
            return
        for frame in frames:
            action = menu.addAction(frame.title)
            action.triggered.connect(lambda checked=False, f=frame: self.view.animate_to(f.sceneBoundingRect().adjusted(-40, -40, 40, 40)))
        menu.addSeparator()
        menu.addAction('▶️  Present all\tF5').triggered.connect(lambda checked=False: self.start_presentation())

    def start_presentation(self):
        frames = self._sorted_frames()
        if not frames:
            QtWidgets.QMessageBox.information(self, 'Procedural Canvas',
                                              'Presentation shows frames as slides. Draw a frame first (Frame tool, F).')
            return
        self._presentation = PresentationView(self.scene, frames)
        self._presentation.start()

    def snapshot_viewport(self):
        pass
        try:
            viewer = hou.ui.paneTabOfType(hou.paneTabType.SceneViewer)
        except (hou.Error, AttributeError):
            viewer = None
        if viewer is None:
            QtWidgets.QMessageBox.information(self, 'Procedural Canvas', 'Open a Scene Viewer to take a snapshot.')
            return
        folder = hou.getenv('HOUDINI_TEMP_DIR') or tempfile.gettempdir()
        prefix = 'canvas_snapshot_%d' % int(time.time() * 1000)
        frame = hou.frame()
        try:
            settings = viewer.flipbookSettings().stash()
            settings.frameRange((frame, frame))
            settings.outputToMPlay(False)
            settings.output(os.path.join(folder, prefix + '.$F4.jpg').replace('\\', '/'))
            viewer.flipbook(viewer.curViewport(), settings)
        except hou.Error:
            _log_error('Viewport snapshot failed')
            QtWidgets.QMessageBox.warning(self, 'Procedural Canvas', 'Could not capture the viewport. See the Python console.')
            return
        files = sorted(f for f in os.listdir(folder) if f.startswith(prefix))
        if not files:
            QtWidgets.QMessageBox.warning(self, 'Procedural Canvas', 'The viewport snapshot was not written.')
            return
        image = QtGui.QImage(os.path.join(folder, files[0]))
        for name in files:
            try:
                os.remove(os.path.join(folder, name))
            except OSError:
                pass
        if image.isNull():
            return

        center = self.view.mapToScene(self.view.viewport().rect().center())
        items = self.view._add_images([_encode_image(image)], center)
        self.scene.clearSelection()
        for item in items:
            item.setSelected(True)
        self.record_history()

    _TOOLBAR_TEMPLATE = """
        QWidget#toolbar { background: %(toolbar)s; border-bottom: 1px solid %(border)s; }
        QFrame#toolGroup { background: %(group)s; border: 1px solid %(group_border)s; border-radius: 9px; }
        QLabel#groupCaption { color: %(caption)s; font-size: 10px; font-weight: bold; padding: 0 4px 0 2px; }
        QToolButton, QComboBox, QSpinBox, QFontComboBox {
            color: %(text)s; background: %(btn)s; border: 1px solid %(btn_border)s; border-radius: 6px;
            font-family: '%(emoji_font)s', '%(ui_font)s', sans-serif; font-size: 15px; font-weight: bold; padding: 1px 4px;
        }
        QComboBox, QSpinBox, QFontComboBox { font-size: 13px; }
        QComboBox { combobox-popup: 0; }
        QComboBox QAbstractItemView { background: %(panel)s; color: %(text)s; selection-background-color: %(accent_strong)s; }
        QToolButton { padding: 0px; }
        QToolButton:hover { background: %(btn_hover)s; border-color: %(accent)s; }
        QToolButton:checked { background: %(accent_strong)s; color: white; border-color: %(accent)s; }
        QToolButton::menu-indicator { image: none; width: 0px; }
        QLabel { color: %(dim)s; font-size: 12px; }
        QSlider::groove:horizontal { height: 4px; background: %(btn_border)s; border-radius: 2px; }
        QSlider::handle:horizontal { width: 14px; margin: -6px 0; border-radius: 7px; background: %(accent)s; }
        QMenu { background: %(panel)s; color: %(text)s; border: 1px solid %(panel_border)s; padding: 4px; }
        QMenu::item { padding: 6px 24px 6px 12px; border-radius: 4px; }
        QMenu::item:selected { background: %(accent_strong)s; color: #ffffff; }
        QMenu::item:disabled { color: %(caption)s; }
        QMenu::separator { height: 1px; background: %(menu_sep)s; margin: 4px 8px; }
    """

    _STATUS_TEMPLATE = """
        QWidget#statusBar { background: %(status)s; border-top: 1px solid %(border)s; }
        QLabel { color: %(dim)s; font-size: 12px; }
        QLabel#saveState { color: %(caption)s; }
        QToolButton { color: %(text)s; background: transparent; border: 1px solid transparent; border-radius: 4px;
                      font-size: 12px; padding: 1px 8px; }
        QToolButton:hover { border-color: %(btn_border)s; background: %(btn)s; }
        QToolButton::menu-indicator { image: none; width: 0px; }
        QMenu { background: %(panel)s; color: %(text)s; border: 1px solid %(panel_border)s; padding: 4px; }
        QMenu::item { padding: 5px 22px 5px 12px; border-radius: 4px; }
        QMenu::item:selected { background: %(accent_strong)s; color: #ffffff; }
        QMenu::separator { height: 1px; background: %(menu_sep)s; margin: 4px 8px; }
    """

    TOOL_HINTS = {
        'select': 'Drag to move · Shift — one axis · Alt — duplicate · Space — pan',
        'link': 'Drag from one note or image to another · start near an edge to pin the link there',
        'pen': 'Draw freehand · color and size apply to the selection too',
        'highlighter': 'Translucent marker strokes',
        'arrow': 'Drag to draw an arrow',
        'rect': 'Drag to draw · Shift — square',
        'ellipse': 'Drag to draw · Shift — circle',
        'frame': 'Drag to draw a frame · Ctrl+Alt+G wraps the selection',
        'eraser': 'Click or drag · brush strokes are erased in parts',
        'sticky': 'Click to place a sticky note',
        'code': 'Click to place a code block',
        'eyedropper': 'Click anywhere to pick a color for the brush',
    }

    def _group(self, caption, widgets):
        pass
        frame = QtWidgets.QFrame()
        frame.setObjectName('toolGroup')
        layout = QtWidgets.QHBoxLayout(frame)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.setSpacing(3)
        label = QtWidgets.QLabel(caption.upper())
        label.setObjectName('groupCaption')
        layout.addWidget(label)
        self._group_captions.append(label)
        for widget in widgets:
            if widget is None:
                layout.addSpacing(14)
            else:
                layout.addWidget(widget)
        return frame

    def _build_ui(self):
        self._sized_buttons = []
        self._group_captions = []



        self.font_combo = FontPickerButton()
        self.font_combo.setToolTip("Font: click and type a name (hover to preview; applies to the selected "
                                   "characters or notes, and to new notes)")
        if SETTINGS['font_family']:
            self.font_combo.setCurrentFont(QtGui.QFont(SETTINGS['font_family']))
        self.font_combo.picked.connect(lambda family: self.change_font(QtGui.QFont(family)))
        self.font_combo.previewed.connect(self._preview_font_family)
        self.font_combo.preview_ended.connect(self._end_preview)


        self.font_size = FontSizeButton()
        self.font_size.setToolTip("Font size: click for a slider (applies to the selected characters or note, and to new notes)")
        self.font_size.setRange(8, 300)
        self.font_size.setValue(SETTINGS['font_size'])
        self.font_size.valueChanged.connect(self.change_font_size)
        self.font_size.previewed.connect(self._preview_font_size)
        self.font_size.preview_ended.connect(self._end_preview)

        self.btn_bold = self._create_btn("B", "Bold", lambda: self.apply_format('bold'))
        self.btn_ital = self._create_btn("I", "Italic", lambda: self.apply_format('italic'))
        self.btn_under = self._create_btn("U", "Underline", lambda: self.apply_format('underline'))
        self.btn_strike = self._create_btn("S", "Strikethrough", lambda: self.apply_format('strike'))
        for btn, attr in ((self.btn_ital, 'setItalic'), (self.btn_under, 'setUnderline'), (self.btn_strike, 'setStrikeOut')):
            font = btn.font()
            getattr(font, attr)(True)
            btn.setFont(font)
        self.btn_colr = self._create_btn("🎨", "Text color (hover to preview)", self.open_text_color)
        self.btn_mark = self._create_btn("🖍️", "Highlight (marker behind the text)", self.open_highlight)

        self.align_buttons = []
        for kind, tip, alignment in (('left', 'Align text left', QtCore.Qt.AlignLeft),
                                     ('center', 'Center text', QtCore.Qt.AlignHCenter),
                                     ('right', 'Align text right', QtCore.Qt.AlignRight)):

            btn = self._create_btn('', tip, lambda checked=False, a=alignment: self.apply_alignment(a))
            btn.setIcon(_align_icon(kind))
            btn.setToolButtonStyle(QtCore.Qt.ToolButtonIconOnly)
            self.align_buttons.append(btn)
        self.btn_para = self._menu_button("¶", "Lists and line spacing", lambda menu: self._add_actions(menu, (
            ("•  Bulleted list", lambda: self.toggle_list('bullet')),
            ("1.  Numbered list", lambda: self.toggle_list('number')),
            ("☑️  Checklist (to-do)", lambda: self.toggle_list('check')),
            None,
            ("↕  Line spacing 1.0", lambda: self.apply_line_spacing(100)),
            ("↕  Line spacing 1.15", lambda: self.apply_line_spacing(115)),
            ("↕  Line spacing 1.5", lambda: self.apply_line_spacing(150)),
            ("↕  Line spacing 2.0", lambda: self.apply_line_spacing(200)),
        )))


        self.text_tools = self._group('Text', [self.font_combo, self.font_size, None,
                                               self.btn_bold, self.btn_ital, self.btn_under, self.btn_strike, None,
                                               self.btn_colr, self.btn_mark, None]
                                      + self.align_buttons + [None, self.btn_para])


        self.tool_combo = QtWidgets.QComboBox()
        self.tool_combo.addItems([_plain(label) for _, label, _ in TOOLS])
        self.tool_combo.currentIndexChanged.connect(self.change_tool)
        HoverOpener(self.tool_combo, self.tool_combo.showPopup,
                    lambda: self.tool_combo.view().window(), self.tool_combo.hidePopup)

        self.btn_pen_color = self._create_btn("", "Brush color (also recolors selected strokes, shapes and links)", self.open_pen_color)
        self.btn_fill = self._create_btn("", "Fill for rectangles and ellipses, color for stickies", self.open_fill)
        self._update_pen_swatch()
        self.btn_line = self._menu_button("〰️", "Line style and link arrows", self._fill_line_menu)
        self.btn_brush = self._menu_button("🖌️", "Brush style and highlighter opacity (also for selected strokes)",
                                           self._fill_brush_menu)


        self.width_label = QtWidgets.QLabel("Size")
        self.width_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.width_slider.setToolTip("Brush size")
        self.width_slider.setRange(1, 50)
        self.width_spin = QtWidgets.QSpinBox()
        self.width_spin.setToolTip("Brush size (type any value up to 200)")
        self.width_spin.setRange(1, 200)
        self.width_slider.valueChanged.connect(self.set_pen_width)
        self.width_spin.valueChanged.connect(self.set_pen_width)
        self.set_pen_width(4)
        self.btn_reset_tools = self._create_btn("↺", "Reset tool settings to defaults: color, size, line and brush "
                                                     "style, arrows, fill (%s)" % RESET_TOOLS_KEY, self.reset_tool_settings)
        draw_group = self._group('Draw', [self.tool_combo, self.btn_pen_color, self.btn_fill, self.btn_line, self.btn_brush,
                                          self.width_label, self.width_slider, self.width_spin, self.btn_reset_tools])
        self.draw_tools = draw_group





        self.btn_grid = self._create_btn("🌐", "Show grid", self.toggle_grid)
        self.btn_grid.setCheckable(True)
        self.btn_snap = self._create_btn("🧲", "Snap to grid", self.toggle_snap)
        self.btn_snap.setCheckable(True)
        view_group = self._group('View', [
            self.btn_grid,
            self.btn_snap,
            self._menu_button("📑", "Go to frame · present frames as slides (F5)", self._fill_frames_menu),
            self._create_btn("🔍", "Search (Ctrl+F)", lambda: self.view.search_bar.open_bar()),
            self._create_btn("🖼️", "Toggle image rounding", self.toggle_rounding),
        ])
        self.view_tools = view_group


        board_buttons = [
            self._create_btn("📸", "Snapshot of the Houdini viewport", self.snapshot_viewport),
            self._menu_button("📁", "Export as PNG", self._fill_file_menu),
        ]
        if self.embedded:
            board_buttons.append(self._create_btn("↗️", "Open this board in a separate window", lambda: launch(self.node)))
        else:
            board_buttons.append(self._create_btn("📌", "Dock this board into a Houdini pane (next to Parameters)",
                                                  lambda: open_panel(self.node)))
            self.btn_pin = self._create_btn("📍", "Keep this window on top of other windows (handy for dragging from a browser)",
                                            self.toggle_on_top)
            self.btn_pin.setCheckable(True)
            board_buttons.append(self.btn_pin)
        board_buttons += [
            self._create_btn("❓", "Keyboard shortcuts (? or F1)", self.toggle_shortcuts),
            self._create_btn("🎓", "Tutorial", self.start_tutorial),
            self._create_btn("⚙️", "Settings", self.open_settings),
        ]
        board_group = self._group('Board', board_buttons)
        self.board_tools = board_group


        self.toolbar = QtWidgets.QWidget()
        self.toolbar.setObjectName('toolbar')
        self.toolbar.setAttribute(QtCore.Qt.WA_StyledBackground, True)
        flow = FlowLayout(self.toolbar, spacing=8)
        flow.setContentsMargins(10, 8, 10, 8)
        for group in (self.text_tools, draw_group, view_group, board_group):
            flow.addWidget(group)
        self.main_layout.addWidget(self.toolbar)
        self._apply_density()

        if SETTINGS['grid_default']:
            self.btn_grid.setChecked(True)
            self.toggle_grid()
            self.btn_snap.setChecked(True)
            self.view.grid_enabled = self.scene.snap_to_grid = True

    def _build_status_bar(self):
        pass
        self.status_bar = QtWidgets.QWidget()
        self.status_bar.setObjectName('statusBar')
        self.status_bar.setAttribute(QtCore.Qt.WA_StyledBackground, True)
        self.status_bar.setFixedHeight(26)
        layout = QtWidgets.QHBoxLayout(self.status_bar)
        layout.setContentsMargins(10, 0, 6, 0)
        layout.setSpacing(14)
        self.status_hint = QtWidgets.QLabel()
        self.status_selection = QtWidgets.QLabel()
        self.status_save = QtWidgets.QLabel()
        self.status_save.setObjectName('saveState')
        self.status_perf = QtWidgets.QLabel()
        self.status_perf.setObjectName('saveState')
        self.status_perf.setToolTip('Frame time over the last 2 s: median / worst, and frames longer than 33 ms. '
                                    'Written to the error log every 10 s while the board moves.')
        self._perf_timer = QtCore.QTimer(self)
        self._perf_timer.setInterval(500)
        self._perf_timer.timeout.connect(self._update_perf)
        self._perf_log_at = 0.0
        self._apply_frame_stats()
        self.zoom_button = QtWidgets.QToolButton()
        self.zoom_button.setToolTip('Zoom')
        self.zoom_button.setPopupMode(QtWidgets.QToolButton.InstantPopup)
        zoom_menu = QtWidgets.QMenu(self.zoom_button)
        zoom_menu.aboutToShow.connect(lambda: (zoom_menu.clear(), self._fill_zoom_menu(zoom_menu)))
        self.zoom_button.setMenu(zoom_menu)
        layout.addWidget(self.status_hint, 1)
        layout.addWidget(self.status_selection)
        layout.addWidget(self.status_save)
        layout.addWidget(self.status_perf)
        layout.addWidget(self.zoom_button)
        self.main_layout.addWidget(self.status_bar)
        self.scene.selectionChanged.connect(self._update_status_selection)
        self.view.view_changed.connect(self._update_status_zoom)
        self._update_status_selection()
        self._update_status_zoom()
        self.status_hint.setText(self.TOOL_HINTS['select'])
        self._set_save_state('Not saving: %s' % self._read_only_reason if not self._save_enabled else 'Saved')

    def _fill_zoom_menu(self, menu):
        for zoom in ZOOM_PRESETS:
            self._add_actions(menu, (('%d %%' % round(zoom * 100), lambda z=zoom: self.view.zoom_to(z)),))
        menu.addSeparator()
        self._add_actions(menu, (
            ('Fit everything\tShift+1', self.view.fit_all),
            ('Fit selection\tShift+2', self.view.fit_selection),
            None,
            (('Hide' if SETTINGS['minimap_visible'] else 'Show') + ' minimap', self.toggle_minimap),
        ))

    def toggle_minimap(self):
        SETTINGS.values['minimap_visible'] = not SETTINGS['minimap_visible']
        SETTINGS.save()
        self.view.minimap.apply_settings()

    def _update_status_selection(self):
        try:
            count = len(self.scene.selected_canvas_items()) + sum(1 for i in self.scene.selectedItems() if isinstance(i, LinkNode))
        except RuntimeError:
            return
        self.status_selection.setText('%d selected' % count if count else '')

    def _update_status_zoom(self):
        self.zoom_button.setText('%d %%' % self.view.zoom_percent())

    def _apply_frame_stats(self):
        on = bool(SETTINGS['frame_stats'])
        self.status_perf.setVisible(on)
        if on and not self._perf_timer.isActive():
            self._perf_timer.start()
        elif not on:
            self._perf_timer.stop()

    def _update_perf(self):
        try:
            report = self.view.frame_report()
        except RuntimeError:
            return
        if report is None:
            return
        text = '%d ms / %d ms' % (round(report['median']), round(report['max']))
        if report['long']:
            text += '  ·  %d slow' % report['long']
        self.status_perf.setText(text)
        now = time.monotonic()
        if now - self._perf_log_at >= 10.0:
            self._perf_log_at = now
            _log_info('perf: %s %s gpu=%d frames=%d median=%.1f p95=%.1f max=%.1f slow=%d zoom=%d%% items=%d' % (
                'docked' if self.embedded else 'window', platform_tag(), report['gpu'], report['frames'],
                report['median'], report['p95'], report['max'], report['long'], self.view.zoom_percent(),
                len(self.scene.canvas_items())))

    def _set_save_state(self, text):
        if getattr(self, 'status_save', None) is not None:
            self.status_save.setText(text)

    def apply_theme(self):
        pass
        self.toolbar.setStyleSheet(_style(self._TOOLBAR_TEMPLATE))
        self.status_bar.setStyleSheet(_style(self._STATUS_TEMPLATE))
        for item in self.scene.canvas_items():
            if isinstance(item, TextNode):
                item.apply_theme()
        self.view.search_bar.apply_theme()
        for btn, kind in zip(getattr(self, 'align_buttons', []), ('left', 'center', 'right')):
            btn.setIcon(_align_icon(kind))
        self._update_pen_swatch()
        self.view.resetCachedContent()
        self.view.viewport().update()
        self.view.minimap.apply_settings()
        self.view.minimap.refresh()

    def _apply_density(self):
        pass
        width = self.width()
        level = next(k for k, row in enumerate(TOOLBAR_DENSITY) if width >= row[0])
        if level == self._density:
            return
        self._density = level
        _, btn, font_w, slider_w = TOOLBAR_DENSITY[level]
        for button in self._sized_buttons:
            button.setFixedSize(btn, btn)
            button.setIconSize(QtCore.QSize(btn - 12, btn - 12))
        self.font_combo.setFixedSize(font_w, btn)
        self.tool_combo.setFixedSize((170, 140, 118)[level], btn)
        self.font_size.setFixedSize((64, 56, 52)[level], btn)
        self.width_spin.setFixedSize((58, 52, 48)[level], btn)
        self.width_slider.setFixedWidth(slider_w)
        self.width_label.setVisible(level == 0)
        for caption in self._group_captions:
            caption.setVisible(level == 0)
        self.toolbar.layout().invalidate()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if getattr(self, 'toolbar', None) is not None:
            self._apply_density()


    @staticmethod
    def _apply_settings_everywhere(values):
        SETTINGS.values.update(values)
        for win in list(_CANVAS_WINDOWS.values()):
            try:
                win.apply_settings()
            except RuntimeError:
                pass

    def open_settings(self):
        pass
        original = dict(SETTINGS.values)
        dialog = SettingsDialog(self)
        throttle = QtCore.QTimer(dialog)
        throttle.setSingleShot(True)
        throttle.setInterval(120)
        throttle.timeout.connect(lambda: self._apply_settings_everywhere(dialog.values()))
        dialog.changed.connect(throttle.start)
        if _exec(dialog):
            self._apply_settings_everywhere(dialog.values())
            SETTINGS.save()
            gl_changed = any(original[k] != SETTINGS[k] for k in ('gpu_vsync', 'gpu_samples'))
            for win in list(_CANVAS_WINDOWS.values()):
                try:
                    want = GPU_VIEWPORT and SETTINGS['gpu'] and (not win.embedded or SETTINGS['gpu_docked'])
                    if gl_changed and want:
                        win.view.set_gpu(False)
                    win.view.set_gpu(want)
                except RuntimeError:
                    pass
        else:
            throttle.stop()
            self._apply_settings_everywhere(original)

    def apply_settings(self):
        _refresh_accent()
        self._apply_frame_stats()
        self.apply_theme()
        self.view.viewport().update()
        if self.scene.applied_corner != SETTINGS['image_corner']:
            self.scene.applied_corner = SETTINGS['image_corner']
            self.scene._pixmaps.clear()
            for item in self.scene.canvas_items():
                if isinstance(item, ImageNode):
                    item._update_pixmap()
        self.view.text_family = SETTINGS['font_family'] or None
        self.view.text_size = SETTINGS['font_size']
        self.font_combo.blockSignals(True)
        if SETTINGS['font_family']:
            self.font_combo.setCurrentFont(QtGui.QFont(SETTINGS['font_family']))
        self.font_combo.blockSignals(False)
        self.font_size.blockSignals(True)
        self.font_size.setValue(SETTINGS['font_size'])
        self.font_size.blockSignals(False)
        self.update_node_summary()
        self.view.schedule_minimap()

    def _setup_hotkeys(self):
        for idx, (_, _, key) in enumerate(TOOLS):
            shortcut = QShortcut(QtGui.QKeySequence(key), self)

            shortcut.setContext(QtCore.Qt.WidgetWithChildrenShortcut)
            shortcut.activated.connect(lambda i=idx: self.tool_combo.setCurrentIndex(i))
        reset = QShortcut(QtGui.QKeySequence(RESET_TOOLS_KEY), self)
        reset.setContext(QtCore.Qt.WidgetWithChildrenShortcut)
        reset.activated.connect(self.reset_tool_settings)

    def reset_tool_settings(self):
        pass

        view = self.view
        view.pen_color = DEFAULT_PEN_COLOR
        view.line_dash = 'solid'
        view.link_arrows = 0
        view.link_flow = False
        view.brush_style = 'smooth'
        view.highlighter_alpha = HIGHLIGHTER_ALPHA
        view.fill_color = None
        view.fill_alpha = 100
        view.sticky_color = None
        for widget in (self.width_slider, self.width_spin):
            widget.blockSignals(True)
            widget.setValue(DEFAULT_PEN_WIDTH)
            widget.blockSignals(False)
        view.pen_width = DEFAULT_PEN_WIDTH
        self._update_pen_swatch()
        view._update_cursor()
        view.show_toast('Tool settings reset to defaults')

    def change_tool(self, index):
        self.view.current_tool = TOOLS[index][0]
        if self.view.current_tool == 'select':
            self.view.setDragMode(QtWidgets.QGraphicsView.RubberBandDrag)
        else:
            self.view.setDragMode(QtWidgets.QGraphicsView.NoDrag)
        self.view._update_cursor()
        if getattr(self, 'status_hint', None) is not None:
            self.status_hint.setText(self.TOOL_HINTS.get(self.view.current_tool, ''))

    def _set_brush_size(self, value):
        pass
        for widget in (self.width_slider, self.width_spin):
            widget.blockSignals(True)
            widget.setValue(value)
            widget.blockSignals(False)
        self.view.pen_width = value
        self.view._update_cursor()

    def set_pen_width(self, value):
        self.view.pen_width = value
        if getattr(self.view, 'current_tool', None) in SIZED_CURSOR_TOOLS:
            self.view._update_cursor()

        for widget in (self.width_slider, self.width_spin):
            if widget.value() != value:
                widget.blockSignals(True)
                widget.setValue(value)
                widget.blockSignals(False)

        if getattr(self, 'view', None) is not None and self.view.apply_style_to_selection(width=value):
            self.view._nudge_timer.start()


    def _update_pen_swatch(self):
        border = _theme()['btn_border']
        self.btn_pen_color.setStyleSheet(
            "QToolButton { background: %s; border: 2px solid %s; border-radius: 6px; }"
            "QToolButton:hover { border-color: %s; }" % (self.view.pen_color, border, _theme()['text']))
        fill = self.view.fill_color
        if fill:
            color = QtGui.QColor(fill)
            color.setAlpha(int(255 * self.view.fill_alpha / 100.0))
            background = 'rgba(%d, %d, %d, %d)' % (color.red(), color.green(), color.blue(), color.alpha())
        else:
            background = ('qlineargradient(x1:0, y1:1, x2:1, y2:0, stop:0 transparent, stop:0.46 transparent, '
                          'stop:0.47 #ff4757, stop:0.53 #ff4757, stop:0.54 transparent, stop:1 transparent)')
        self.btn_fill.setStyleSheet(
            "QToolButton { background: %s; border: 2px dashed %s; border-radius: 6px; }"
            "QToolButton:hover { border-color: %s; }" % (background, border, _theme()['text']))

    def _on_color_picked(self, color):
        self.view.pen_color = color
        self._remember_color(color)
        self._update_pen_swatch()

    def open_fill(self):
        pass

        targets = [i for i in self.scene.selected_canvas_items() if not _is_locked(i)
                   and ((isinstance(i, ShapeNode) and i.shape_type != 'arrow') or (isinstance(i, TextNode) and i.is_sticky))]
        originals = [(i, i.fill if isinstance(i, ShapeNode) else i.bg) for i in targets]
        state = {'picked': False}

        def set_fill(item, color):
            if isinstance(item, ShapeNode):
                item.set_style(fill=color or None)
            else:
                item.set_bg(color or None)

        def hover(color):
            for item in targets:
                set_fill(item, color)

        def close():
            if not state['picked']:
                for item, color in originals:
                    try:
                        set_fill(item, color)
                    except RuntimeError:
                        pass

        def pick(color):
            state['picked'] = True
            self.view.fill_color = color or None
            self._update_pen_swatch()
            if self.view.apply_fill_to_selection(fill=color or None):
                self.record_history()

        def opacity(value):
            self.view.fill_alpha = value
            self._update_pen_swatch()
            if self.view.apply_fill_to_selection(alpha=value):
                self.view._nudge_timer.start()

        popup = ColorPopup(self, self.view.fill_color, self._recent_colors, 'Fill', none_label='No fill',
                           opacity=self.view.fill_alpha, palette=STICKY_COLORS + ColorPopup.PALETTE[:16])
        popup.picked.connect(lambda c: (self._remember_color(c) if c else None, pick(c)))
        popup.opacity_changed.connect(opacity)
        if targets:
            popup.hovered.connect(hover)
            popup.closed.connect(close)
        self._color_popup = popup
        popup.popup_below(self.btn_fill)

    def _fill_brush_menu(self, menu):
        view = self.view

        def set_brush(style):
            view.brush_style = style
            strokes = [i for i in self.scene.selectedItems()
                       if isinstance(i, PathNode) and not i.is_highlighter and not _is_locked(i)]
            for stroke in strokes:
                stroke.set_style(brush=style)
            if strokes:
                self.record_history()
            self.view.show_toast('Brush: %s' % BRUSH_STYLES[style])

        for style, label in BRUSH_STYLES.items():
            self._add_actions(menu, ((('● ' if view.brush_style == style else '    ') + label, lambda s=style: set_brush(s)),))

        def set_alpha(value):
            view.highlighter_alpha = value
            strokes = [i for i in self.scene.selectedItems()
                       if isinstance(i, PathNode) and i.is_highlighter and not _is_locked(i)]
            for stroke in strokes:
                stroke.set_style(alpha=value)
            if strokes:
                self.record_history()
            self.view.show_toast('Highlighter opacity %d%%' % value)

        menu.addSeparator()
        menu.addAction('Highlighter opacity').setEnabled(False)
        for value in (15, 30, 50, 70, 90):
            self._add_actions(menu, ((('● ' if view.highlighter_alpha == value else '    ') + '%d%%' % value,
                                      lambda v=value: set_alpha(v)),))

    def _fill_line_menu(self, menu):
        view = self.view

        def set_dash(value):
            view.line_dash = value
            if view.apply_style_to_selection(dash=value):
                self.record_history()

        def set_arrows(value):
            view.link_arrows = value
            if view.apply_style_to_selection(arrows=value):
                self.record_history()

        for value, label in LINE_STYLES:
            self._add_actions(menu, ((('● ' if view.line_dash == value else '    ') + label, lambda v=value: set_dash(v)),))
        menu.addSeparator()
        menu.addAction('Link arrows').setEnabled(False)
        for label, value in (('No arrows', 0), ('Arrow at the end', 1), ('Arrows at both ends', 2)):
            self._add_actions(menu, ((('● ' if view.link_arrows == value else '    ') + label, lambda v=value: set_arrows(v)),))

        def toggle_flow():
            view.link_flow = not view.link_flow
            view.set_links_flow([i for i in self.scene.selectedItems() if isinstance(i, LinkNode)], view.link_flow)

        menu.addSeparator()
        self._add_actions(menu, ((('● ' if view.link_flow else '    ') + '✨ Live flow (moving dots)', toggle_flow),))

    def _remember_color(self, color):
        if color in self._recent_colors:
            self._recent_colors.remove(color)
        self._recent_colors.insert(0, color)
        del self._recent_colors[8:]

    def _show_color_popup(self, button, current, title, on_pick, on_hover=None, on_close=None):
        popup = ColorPopup(self, current, self._recent_colors, title)

        def picked(color):
            self._remember_color(color)
            on_pick(color)

        popup.picked.connect(picked)
        if on_hover is not None:
            popup.hovered.connect(on_hover)
        if on_close is not None:
            popup.closed.connect(on_close)
        self._color_popup = popup
        popup.popup_below(button)

    def open_pen_color(self):

        styled = [i for i in self.scene.selectedItems()
                  if isinstance(i, (PathNode, ShapeNode, LinkNode)) and not _is_locked(i)]
        originals = [(i, i.color_hex) for i in styled]
        state = {'picked': False}

        def hover(color):
            for item in styled:
                item.set_style(color=color)

        def close():
            if not state['picked']:
                for item, color in originals:
                    try:
                        item.set_style(color=color)
                    except RuntimeError:
                        pass

        def pick(color):
            state['picked'] = True
            self.view.pen_color = color
            self._update_pen_swatch()
            if self.view.apply_style_to_selection(color=color):
                self.record_history()
        self._show_color_popup(self.btn_pen_color, self.view.pen_color, "Brush color", pick,
                               on_hover=hover if styled else None, on_close=close if styled else None)

    def open_text_color(self):
        self._show_color_popup(self.btn_colr, self._last_text_color, "Text color",
                               self.apply_text_color, on_hover=self.preview_text_color, on_close=self._end_preview)

    @staticmethod
    def _highlight_format(color):
        fmt = QtGui.QTextCharFormat()
        fmt.setBackground(QtGui.QColor(color) if color else QtGui.QColor(0, 0, 0, 0))
        return fmt

    def open_highlight(self):
        popup = ColorPopup(self, '#ffeb3b', self._recent_colors, 'Highlight', none_label='No highlight',
                           palette=['#ffeb3b', '#ffd43b', '#ffa94d', '#ff8787', '#f783ac', '#da77f2',
                                    '#9775fa', '#74c0fc', '#63e6be', '#8ce99a', '#c0eb75', '#dee2e6'])
        popup.hovered.connect(lambda c: self._preview_char_format(lambda current: self._highlight_format(c)))
        popup.picked.connect(lambda c: self._apply_char_format(lambda current: self._highlight_format(c)))
        popup.closed.connect(self._end_preview)
        self._color_popup = popup
        popup.popup_below(self.btn_mark)


    def _apply_block_format(self, fmt):
        pass
        self._end_preview()
        items = self._get_text_items()
        if not items:
            return
        if len(items) == 1:
            cursor, partial = self._target_cursor(items[0], items[0].last_selection)
            cursor.mergeBlockFormat(fmt)
            self._finish_text_edit(items[0], cursor, partial)
            return
        for item in items:
            cursor, _ = self._target_cursor(item, None)
            cursor.mergeBlockFormat(fmt)
            item.last_selection = None
            item.update()
        self.view.setFocus()
        self.record_history()

    def apply_alignment(self, alignment):
        fmt = QtGui.QTextBlockFormat()
        fmt.setAlignment(alignment)
        self._apply_block_format(fmt)

    def apply_line_spacing(self, percent):
        pass

        fmt = QtGui.QTextBlockFormat()
        fmt.setLineHeight(float(percent), _enum_int(getattr(QtGui.QTextBlockFormat, 'ProportionalHeight', 1)))
        fmt.setTopMargin(0)
        fmt.setBottomMargin(0)
        fmt.setLeftMargin(0)
        fmt.setTextIndent(0)
        self._apply_block_format(fmt)

    def toggle_list(self, kind):
        pass
        self._end_preview()
        item = self._get_text_item()
        if not item:
            return
        cursor, partial = self._target_cursor(item, item.last_selection)
        doc = item.document()
        blocks = []
        block = doc.findBlock(cursor.selectionStart())
        while block.isValid() and block.position() <= cursor.selectionEnd():
            blocks.append(block)
            block = block.next()
        if not blocks:
            return
        styles = {'bullet': QtGui.QTextListFormat.ListDisc, 'number': QtGui.QTextListFormat.ListDecimal,
                  'check': QtGui.QTextListFormat.ListDisc}
        first = blocks[0]
        is_check = first.blockFormat().marker() != _marker('NoMarker')
        current = first.textList()
        already = current is not None and (is_check if kind == 'check' else
                                           (not is_check and current.format().style() == styles[kind]))
        editor = QtGui.QTextCursor(doc)
        editor.beginEditBlock()
        if already:
            for blk in blocks:
                lst = blk.textList()
                if lst is not None:
                    lst.remove(blk)
                fmt = blk.blockFormat()
                fmt.setIndent(0)
                fmt.setMarker(_marker('NoMarker'))
                QtGui.QTextCursor(blk).setBlockFormat(fmt)
        else:
            for blk in blocks:
                lst = blk.textList()
                if lst is not None:
                    lst.remove(blk)
            list_format = QtGui.QTextListFormat()
            list_format.setStyle(styles[kind])
            list_format.setIndent(1)
            new_list = QtGui.QTextCursor(first).createList(list_format)
            for blk in blocks[1:]:
                new_list.add(blk)
            marker = QtGui.QTextBlockFormat()
            marker.setMarker(_marker('Unchecked') if kind == 'check' else _marker('NoMarker'))
            for blk in blocks:
                QtGui.QTextCursor(blk).mergeBlockFormat(marker)
        editor.endEditBlock()
        self._finish_text_edit(item, cursor, partial)

    def _finish_text_edit(self, item, cursor, partial):
        item.update()
        if partial:
            item.start_editing(cursor)
        else:
            cursor.clearSelection()
            item.setTextCursor(cursor)
            self.view.setFocus()
        self.record_history()


    def toggle_on_top(self):
        on = self.btn_pin.isChecked()
        if not self._set_topmost_native(on):

            geometry = self.geometry()
            self.setWindowFlag(QtCore.Qt.WindowStaysOnTopHint, on)
            self.setGeometry(geometry)
            self.show()
        self.view.show_toast('Pinned on top' if on else 'Unpinned')

    def _set_topmost_native(self, on):
        pass

        if os.name != 'nt':
            return False
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                            ctypes.c_int, ctypes.c_int, ctypes.c_uint]
            user32.SetWindowPos.restype = wintypes.BOOL
            hwnd = wintypes.HWND(int(self.winId()))
            insert_after = wintypes.HWND(-1 if on else -2)
            flags = 0x0001 | 0x0002 | 0x0010
            return bool(user32.SetWindowPos(hwnd, insert_after, 0, 0, 0, 0, flags))
        except Exception:
            return False

    def toggle_shortcuts(self):
        overlay = self._shortcuts_overlay
        if overlay is not None:
            try:
                if overlay.isVisible():
                    overlay.close()
                    return
            except RuntimeError:
                pass
        self._shortcuts_overlay = ShortcutsOverlay(self)
        self._shortcuts_overlay.start()


    def _fill_file_menu(self, menu):
        self._add_actions(menu, (
            ('💾  Export board as PNG…', self.export_png),
            ('🖼️  Export area as PNG…', self.export_area),
        ))

    @staticmethod
    def _color_format(color):
        fmt = QtGui.QTextCharFormat()
        fmt.setForeground(QtGui.QColor(color))
        return fmt

    def preview_text_color(self, color):
        self._preview_char_format(lambda current: self._color_format(color))

    def apply_text_color(self, color):
        self._last_text_color = color
        self._apply_char_format(lambda current: self._color_format(color))


    def toggle_rounding(self):
        images = [i for i in self.scene.items() if isinstance(i, ImageNode)]
        if not images:
            return
        any_unrounded = any(not img.is_rounded for img in images)
        for img in images:
            img.set_rounded(any_unrounded)
        self.record_history()

    def toggle_grid(self, *args):
        pass
        self.view.grid_visible = self.btn_grid.isChecked()
        self.view.resetCachedContent()
        self.view.viewport().update()

    def toggle_snap(self, *args):
        pass
        enabled = self.btn_snap.isChecked()
        self.view.grid_enabled = enabled
        self.scene.snap_to_grid = enabled
        self.view.show_toast('Snap to grid on' if enabled else 'Snap to grid off')

    def export_png(self):
        pass
        items = [i for i in self.scene.canvas_items() if i.isVisible()]
        if not items:
            self.view.show_toast('The board is empty')
            return
        self._save_png(_items_rect(items).adjusted(-50, -50, 50, 50), 1.0)

    def export_area(self):
        pass
        picker = AreaPicker(self.view)

        picker.picked.connect(lambda r: self._save_png(self.view.mapToScene(r).boundingRect(),
                                                       max(1.0, self.view.transform().m11() * 2)))
        picker.start()

    def _save_png(self, rect, scale):
        if rect.isEmpty():
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save canvas", "", "PNG Images (*.png)")
        if not path:
            return
        if not path.lower().endswith('.png'):
            path += '.png'
        selected = self.scene.selectedItems()
        self.scene.clearSelection()
        k = min(scale, EXPORT_MAX_SIDE / max(rect.width(), rect.height()))
        img = QtGui.QImage(max(1, int(rect.width() * k)), max(1, int(rect.height() * k)), QtGui.QImage.Format_ARGB32)
        img.fill(QtGui.QColor(_canvas_bg()))
        painter = QtGui.QPainter(img)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        self.scene.render(painter, QtCore.QRectF(img.rect()), rect)
        painter.end()
        for item in selected:
            item.setSelected(True)

        if not img.save(path):
            QtWidgets.QMessageBox.warning(self, 'Procedural Canvas', f'Could not save the file:\n{path}')
            return
        self.view.show_toast('Saved %s' % os.path.basename(path))


    def _get_text_items(self):
        pass

        focus = self.scene.focusItem()
        selected = [i for i in self.scene.selected_canvas_items() if isinstance(i, TextNode)]
        for item in ([focus] if isinstance(focus, TextNode) else []) + selected:
            if item.is_editing() or item.last_selection:
                return [item]
        if selected:
            return selected
        return [focus] if isinstance(focus, TextNode) else []

    def _get_text_item(self):
        items = self._get_text_items()
        return items[0] if items else None

    @staticmethod
    def _target_cursor(item, saved_selection):
        pass

        cursor = item.textCursor()
        if not cursor.hasSelection() and saved_selection:
            anchor, position = saved_selection
            cursor = QtGui.QTextCursor(item.document())
            cursor.setPosition(anchor)
            cursor.setPosition(position, QtGui.QTextCursor.KeepAnchor)
        if cursor.hasSelection():

            whole = cursor.selectionStart() == 0 and cursor.selectionEnd() >= item.document().characterCount() - 1
            return cursor, not whole
        cursor.select(QtGui.QTextCursor.Document)
        return cursor, False

    @staticmethod
    def _merge_format(cursor, fmt, partial):
        cursor.mergeCharFormat(fmt)
        if not partial:


            cursor.mergeBlockCharFormat(fmt)

    def _preview_char_format(self, build):
        pass

        if self._preview_item is None:
            items = self._get_text_items()
            if not items:
                return
            self._preview_states = [(i, i.html(), i.last_selection) for i in items]
            self._preview_item = items[0]
        else:
            for item, html, _ in self._preview_states:
                item.setHtml(html)
        for item, _, selection in self._preview_states:
            cursor, partial = self._target_cursor(item, selection)
            fmt = build(cursor.charFormat())
            if fmt is not None:
                self._merge_format(cursor, fmt, partial)
                item.refresh_render()

    def _end_preview(self):
        if self._preview_item is None:
            return
        self._preview_item = None
        for item, html, selection in self._preview_states:
            try:
                if item.toHtml() != html:
                    item.setHtml(html)
                    item.refresh_render()
                item._html = html
                item.last_selection = selection
            except RuntimeError:
                pass
        self._preview_states = []

    def _apply_char_format(self, build):
        pass



        self._end_preview()
        items = self._get_text_items()
        if not items:
            return
        for item in items:
            cursor, partial = self._target_cursor(item, item.last_selection)
            fmt = build(cursor.charFormat())
            if fmt is not None:
                self._merge_format(cursor, fmt, partial)
                if not partial:
                    item._remember_font()
                item.refresh_render()
            if partial and len(items) == 1:

                item.start_editing(cursor)
            else:
                cursor.clearSelection()
                item.setTextCursor(cursor)
                item.last_selection = None
        if not (len(items) == 1 and items[0].is_editing()):
            self.view.setFocus()
        self.record_history()

    def _preview_font_family(self, family):
        def build(current):
            fmt = QtGui.QTextCharFormat()
            _set_font_family(fmt, family)
            return fmt
        self._preview_char_format(build)

    def change_font(self, font):
        self.view.text_family = font.family()

        def build(current):
            fmt = QtGui.QTextCharFormat()
            _set_font_family(fmt, font.family())
            return fmt
        self._apply_char_format(build)

    def _preview_font_size(self, size):
        def build(current):
            fmt = QtGui.QTextCharFormat()
            fmt.setFontPointSize(size)
            return fmt
        self._preview_char_format(build)

    def change_font_size(self, size):
        self.view.text_size = size

        def build(current):
            fmt = QtGui.QTextCharFormat()
            fmt.setFontPointSize(size)
            return fmt
        self._apply_char_format(build)

    def apply_format(self, action):
        def build(current):
            fmt = QtGui.QTextCharFormat()
            if action == 'bold':
                bold = _enum_int(QtGui.QFont.Bold)
                fmt.setFontWeight(_enum_int(QtGui.QFont.Normal) if current.fontWeight() >= bold else bold)
            elif action == 'italic':
                fmt.setFontItalic(not current.fontItalic())
            elif action == 'underline':
                fmt.setFontUnderline(not current.fontUnderline())
            elif action == 'strike':
                fmt.setFontStrikeOut(not current.fontStrikeOut())
            return fmt
        self._apply_char_format(build)


class _SaveWorker(QtCore.QObject):
    pass
    done = QtCore.Signal(object, object, int)

    def start(self, doc, state, generation):
        def work():
            try:
                payload = encode_payload(doc)
            except Exception:
                _log_error('Could not encode the canvas document')
                payload = None
            self.done.emit(payload, state, generation)
        threading.Thread(target=work, daemon=True).start()


class ShortcutsOverlay(QtWidgets.QFrame):
    pass
    SHORTCUTS = [
        ('Tools', [('V / L / B / M', 'Select, Link, Brush, Marker'), ('A / U / O / F', 'Arrow, Rectangle, Ellipse, Frame'),
                   ('E / I', 'Eraser, Eyedropper'), ('N / C', 'Sticky, Code block'),
                   ('R', 'Reset tool settings (color, size, styles)')]),
        ('Edit', [('Ctrl+C / X / V', 'Copy, cut, paste (also images)'), ('Ctrl+D', 'Duplicate'),
                  ('Alt + drag', 'Duplicate while dragging'), ('Ctrl+Z / Ctrl+Y', 'Undo / redo'),
                  ('Del', 'Delete'), ('Ctrl+A / Esc', 'Select all / deselect'), ('Arrows (+Shift)', 'Nudge 1 px (10 px)')]),
        ('Arrange', [('Ctrl+G / Ctrl+Shift+G', 'Group / ungroup'), ('Ctrl+Alt+G', 'Wrap in a frame'),
                     ('Ctrl+Shift+L', 'Lock / unlock'), ('Ctrl+] / Ctrl+[', 'Forward / backward'),
                     ('Shift + drag', 'Move along one axis')]),
        ('View', [('Space + drag', 'Pan'), ('Shift+1 / Shift+2', 'Fit all / fit selection'),
                  ('Ctrl+F', 'Search'), ('F5', 'Present frames'), ('Double-click image', 'Crop')]),
    ]

    def __init__(self, window):
        super().__init__(window)
        self.setObjectName('shortcuts')
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.setStyleSheet(_style("QFrame#shortcuts { background: %(panel)s; border: 1px solid %(accent)s; border-radius: 12px; }"
                                  "QLabel { color: %(text)s; font-size: 13px; background: transparent; }"
                                  "QLabel#head { color: %(accent)s; font-size: 14px; font-weight: bold; }"
                                  "QLabel#key { color: %(dim)s; font-family: '%(mono_font)s'; }"))
        grid = QtWidgets.QGridLayout(self)
        grid.setContentsMargins(22, 18, 22, 18)
        grid.setHorizontalSpacing(18)
        for column, (title, rows) in enumerate(self.SHORTCUTS):
            head = QtWidgets.QLabel(title)
            head.setObjectName('head')
            grid.addWidget(head, 0, column * 2, 1, 2)
            for row, (key, text) in enumerate(rows, start=1):
                key_label = QtWidgets.QLabel(key)
                key_label.setObjectName('key')
                grid.addWidget(key_label, row, column * 2)
                grid.addWidget(QtWidgets.QLabel(text), row, column * 2 + 1)
        self.setFocusPolicy(QtCore.Qt.StrongFocus)

    def start(self):
        self.adjustSize()
        parent = self.parentWidget()
        self.move((parent.width() - self.width()) // 2, max(10, (parent.height() - self.height()) // 2))
        self.show()
        self.raise_()
        self.setFocus()

    def keyPressEvent(self, event):
        self.close()

    def mousePressEvent(self, event):
        self.close()
