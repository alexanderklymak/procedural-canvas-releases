pass

















import sys
import importlib

from . import _link
from . import core, items_base, text, images, youtube, shapes, scene, widgets, licensing, view, window, panel

_link.finish()
_link.export(globals())


def reload_plugin():
    pass



    package = sys.modules[__name__]
    names = [__name__ + '.' + n for n in _link.ORDER]
    for name in names:
        with open(sys.modules[name].__file__, encoding='utf-8') as f:
            compile(f.read(), sys.modules[name].__file__, 'exec')
    saved = {name: dict(vars(sys.modules[name])) for name in names}
    windows = dict(core._CANVAS_WINDOWS)
    try:
        for name in names:
            module_dict = vars(sys.modules[name])
            for key in [k for k in module_dict if not k.startswith('__')]:
                del module_dict[key]
        for name in names:
            importlib.reload(sys.modules[name])
        _link.finish()
    except Exception:
        for name, old in saved.items():
            vars(sys.modules[name]).clear()
            vars(sys.modules[name]).update(old)
        raise
    core._CANVAS_WINDOWS.update(windows)
    _link.export(vars(package))
    return getattr(package, 'PLUGIN_VERSION', '?')
