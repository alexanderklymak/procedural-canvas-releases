pass

from ._link import pull
pull(globals())




_CROP_ROLES = ('tl', 't', 'tr', 'r', 'br', 'b', 'bl', 'l')
_CROP_CURSORS = {'tl': QtCore.Qt.SizeFDiagCursor, 'br': QtCore.Qt.SizeFDiagCursor, 'tr': QtCore.Qt.SizeBDiagCursor,
                 'bl': QtCore.Qt.SizeBDiagCursor, 't': QtCore.Qt.SizeVerCursor, 'b': QtCore.Qt.SizeVerCursor,
                 'l': QtCore.Qt.SizeHorCursor, 'r': QtCore.Qt.SizeHorCursor}


class CropHandle(QtWidgets.QGraphicsRectItem):
    def __init__(self, overlay, role):
        super().__init__(overlay)
        self.role = role
        self.setRect(-6, -6, 12, 12)
        self.setBrush(QtGui.QBrush(QtCore.Qt.white))
        self.setPen(QtGui.QPen(QtGui.QColor(*GLOW_COLOR), 2))
        self.setZValue(20)
        self.setFlag(QtWidgets.QGraphicsItem.ItemIgnoresTransformations)
        self.setCursor(_CROP_CURSORS[role])

    def mousePressEvent(self, event):
        event.accept()

    def mouseMoveEvent(self, event):
        overlay = self.parentItem()
        overlay.drag_edge(self.role, overlay.mapFromScene(event.scenePos()))
        event.accept()

    def mouseReleaseEvent(self, event):
        event.accept()


class CropOverlay(QtWidgets.QGraphicsItem):
    pass


    def __init__(self, image_item, rect):
        super().__init__(image_item)
        self.bounds = image_item.boundingRect()
        self.crop_rect = QtCore.QRectF(rect)
        self._drag = None
        self.setZValue(15)
        self.setCursor(QtCore.Qt.SizeAllCursor)
        self.handles = [CropHandle(self, role) for role in _CROP_ROLES]
        self._place_handles()

    def _place_handles(self):
        r = self.crop_rect
        points = {'tl': r.topLeft(), 't': QtCore.QPointF(r.center().x(), r.top()), 'tr': r.topRight(),
                  'r': QtCore.QPointF(r.right(), r.center().y()), 'br': r.bottomRight(),
                  'b': QtCore.QPointF(r.center().x(), r.bottom()), 'bl': r.bottomLeft(),
                  'l': QtCore.QPointF(r.left(), r.center().y())}
        for handle in self.handles:
            handle.setPos(points[handle.role])

    def set_crop_rect(self, rect):
        self.crop_rect = rect.intersected(self.bounds)
        self._place_handles()
        self.update()

    def drag_edge(self, role, p):
        b, r = self.bounds, QtCore.QRectF(self.crop_rect)
        x = max(b.left(), min(p.x(), b.right()))
        y = max(b.top(), min(p.y(), b.bottom()))
        if role in ('tl', 'l', 'bl'):
            r.setLeft(min(x, r.right() - 10))
        if role in ('tr', 'r', 'br'):
            r.setRight(max(x, r.left() + 10))
        if role in ('tl', 't', 'tr'):
            r.setTop(min(y, r.bottom() - 10))
        if role in ('bl', 'b', 'br'):
            r.setBottom(max(y, r.top() + 10))
        self.set_crop_rect(r)

    def boundingRect(self):
        return self.bounds.adjusted(-2, -2, 2, 2)

    def shape(self):
        path = QtGui.QPainterPath()
        path.addRect(self.crop_rect)
        return path

    def paint(self, painter, option, widget):
        shade = QtGui.QPainterPath()
        shade.addRect(self.bounds)
        shade.addRect(self.crop_rect)
        painter.fillPath(shade, QtGui.QColor(0, 0, 0, 150))
        pen = QtGui.QPen(QtGui.QColor(255, 255, 255, 90), 0)
        painter.setPen(pen)
        r = self.crop_rect
        for k in (1, 2):
            painter.drawLine(QtCore.QLineF(r.left() + r.width() * k / 3, r.top(), r.left() + r.width() * k / 3, r.bottom()))
            painter.drawLine(QtCore.QLineF(r.left(), r.top() + r.height() * k / 3, r.right(), r.top() + r.height() * k / 3))
        painter.setPen(QtGui.QPen(QtCore.Qt.white, 0))
        painter.drawRect(r)

    def mousePressEvent(self, event):
        self._drag = (event.pos(), QtCore.QRectF(self.crop_rect))
        event.accept()

    def mouseMoveEvent(self, event):
        if self._drag is None:
            return
        start, rect = self._drag
        moved = rect.translated(event.pos() - start)
        b = self.bounds
        moved.moveLeft(max(b.left(), min(moved.left(), b.right() - moved.width())))
        moved.moveTop(max(b.top(), min(moved.top(), b.bottom() - moved.height())))
        self.set_crop_rect(moved)
        event.accept()

    def mouseReleaseEvent(self, event):
        self._drag = None
        event.accept()

    def mouseDoubleClickEvent(self, event):
        self.parentItem().finish_crop(apply=True)
        event.accept()


def _sniff_image_format(raw):
    if raw.startswith(b'\x89PNG'):
        return 'PNG'
    if raw.startswith(b'\xff\xd8'):
        return 'JPG'
    if raw.startswith(b'GIF8'):
        return 'GIF'
    return 'PNG'


class ImageNode(QtWidgets.QGraphicsPixmapItem):
    TYPE = 'image'

    def __init__(self, scene, asset_id, x=0, y=0, rounded=True, uid=None, crop=None):
        super().__init__()
        self.uid = uid or _new_id()
        self.canvas_scene = scene
        self.asset_id = asset_id
        self.is_rounded = rounded
        self.crop = QtCore.QRectF(*crop) if crop else None
        self.links = []
        self.cropper = None
        self._crop_before = None
        self._movie = None
        self._movie_buffer = None
        self.hover = HoverEffect(self)
        self._mips = {}
        self.setFlags(QtWidgets.QGraphicsItem.ItemIsSelectable | QtWidgets.QGraphicsItem.ItemIsMovable | QtWidgets.QGraphicsItem.ItemSendsGeometryChanges)


        self.setCacheMode(QtWidgets.QGraphicsItem.NoCache)
        self.setAcceptHoverEvents(True)
        self.setTransformationMode(QtCore.Qt.SmoothTransformation)

        self.grips = ItemGrips(self, rotate=True)
        self._start_animation()
        self._update_pixmap()
        self.setPos(x, y)

    @classmethod
    def from_dict(cls, d, scene):
        item = cls(scene, d.get('asset'), rounded=d.get('rounded', True), uid=d.get('id'), crop=d.get('crop'))
        item.setOpacity(d.get('opacity', 1.0))
        _apply_base(item, d)
        return item

    def to_dict(self):
        d = _base_dict(self)
        d.update(asset=self.asset_id, rounded=self.is_rounded)
        if self.crop is not None:
            c = self.crop
            d['crop'] = [round(c.x(), 1), round(c.y(), 1), round(c.width(), 1), round(c.height(), 1)]
        if self.opacity() < 0.999:
            d['opacity'] = round(self.opacity(), 3)
        return d

    def apply_dict(self, d):
        crop = QtCore.QRectF(*d['crop']) if d.get('crop') else None
        if d.get('asset') != self.asset_id or d.get('rounded', True) != self.is_rounded or crop != self.crop:
            self.asset_id = d.get('asset')
            self.is_rounded = d.get('rounded', True)
            self.crop = crop
            self._update_pixmap()
        self.setOpacity(d.get('opacity', 1.0))
        _apply_base(self, d)


    def _start_animation(self):
        raw = self.canvas_scene.assets.get(self.asset_id, b'')
        if not raw.startswith(b'GIF8'):
            return
        buffer = QtCore.QBuffer()
        buffer.setData(QtCore.QByteArray(raw))
        buffer.open(QtCore.QIODevice.ReadOnly)
        movie = QtGui.QMovie()
        movie.setDevice(buffer)
        if not movie.isValid() or movie.frameCount() == 1:
            return


        movie.setCacheMode(QtGui.QMovie.CacheNone)
        movie.frameChanged.connect(self._on_movie_frame)
        self._movie, self._movie_buffer = movie, buffer
        movie.start()

    def _on_movie_frame(self, _frame):
        try:
            if self.cropper is None:
                self.setPixmap(self.canvas_scene.process_image(self._movie.currentImage(), self.is_rounded, self.crop))
            else:
                self.setPixmap(QtGui.QPixmap.fromImage(self._movie.currentImage()))
        except RuntimeError:
            self._movie.stop()


    def start_crop(self):
        if self.cropper is not None:
            return
        self.hover.suspend()
        old = self.crop
        anchor = self.mapToScene(QtCore.QPointF(0, 0))
        self.crop = None
        self._update_pixmap()

        full_point = old.topLeft() if old is not None else QtCore.QPointF(0, 0)
        self.setPos(self.pos() + (anchor - self.mapToScene(full_point)))
        self._crop_before = old
        self.grips.set_visible(False)
        self.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, False)
        self.cropper = CropOverlay(self, old if old is not None else self.boundingRect())
        self.canvas_scene.active_crop = self

    def finish_crop(self, apply=True):
        if self.cropper is None:
            return
        full = self.boundingRect()
        rect = self.cropper.crop_rect if apply else (self._crop_before or full)
        rect = QtCore.QRectF(round(rect.x()), round(rect.y()), round(rect.width()), round(rect.height()))
        anchor = self.mapToScene(rect.topLeft())
        cropper, self.cropper = self.cropper, None
        cropper.setParentItem(None)
        if cropper.scene() is not None:
            cropper.scene().removeItem(cropper)
        self.crop = None if rect == QtCore.QRectF(full.toRect()) else rect
        self._update_pixmap()
        self.setPos(self.pos() + (anchor - self.mapToScene(QtCore.QPointF(0, 0))))
        _set_locked(self, _is_locked(self))
        self.canvas_scene.active_crop = None
        self.canvas_scene.refresh_selection_ui()
        self.canvas_scene.canvas_changed.emit()


    def source_image(self):
        pass
        image = QtGui.QImage.fromData(QtCore.QByteArray(self.canvas_scene.assets.get(self.asset_id, b'')))
        if self.crop is not None and not image.isNull():
            image = image.copy(self.crop.toRect())
        return image

    def copy_to_clipboard(self):
        QtWidgets.QApplication.clipboard().setImage(self.source_image())

    def save_as(self, parent):
        raw = self.canvas_scene.assets.get(self.asset_id, b'')
        fmt = _sniff_image_format(raw) if self.crop is None else 'PNG'
        ext = {'PNG': 'png', 'JPG': 'jpg', 'GIF': 'gif'}[fmt]
        path, _ = QtWidgets.QFileDialog.getSaveFileName(parent, 'Save image', 'image.' + ext, '%s (*.%s)' % (fmt, ext))
        if not path:
            return None
        try:
            if self.crop is None:
                with open(path, 'wb') as f:
                    f.write(raw)
            elif not self.source_image().save(path):
                raise OSError('image could not be encoded')
        except OSError as exc:
            _log_error('Could not save the image to %s' % path)
            QtWidgets.QMessageBox.warning(parent, 'Procedural Canvas', 'Could not save the image:\n%s\n\n%s' % (path, exc))
            return None
        return path

    def info_text(self):
        raw = self.canvas_scene.assets.get(self.asset_id, b'')
        image = QtGui.QImage.fromData(QtCore.QByteArray(raw))
        lines = ['Format: %s%s' % (_sniff_image_format(raw), ' (animated)' if self._movie is not None else ''),
                 'Original: %d × %d px' % (image.width(), image.height()),
                 'Stored size: %.1f KB' % (len(raw) / 1024.0)]
        if self.crop is not None:
            lines.append('Cropped to: %d × %d px' % (self.crop.width(), self.crop.height()))
        shown = self.sceneBoundingRect()
        lines.append('On canvas: %d × %d (scale %d%%)' % (shown.width(), shown.height(), round(self.scale() * 100)))
        if self.opacity() < 0.999:
            lines.append('Opacity: %d%%' % round(self.opacity() * 100))
        return '\n'.join(lines)

    def content_rect(self):
        return self.boundingRect()

    def corner_radius(self):
        rect = self.boundingRect()
        return min(rect.width(), rect.height()) * SETTINGS['image_corner'] / 100.0 if self.is_rounded else 0

    def hoverEnterEvent(self, event):
        self.hover.enter()
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):
        self.hover.leave()
        super().hoverLeaveEvent(event)

    def mousePressEvent(self, event):
        self.hover.suspend()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        self.hover.resume()


    def setPixmap(self, pixmap):
        self._mips = {}
        self._exact = None
        self._exact_key = None
        super().setPixmap(pixmap)

    def drop_exact(self):
        self._exact, self._exact_key = None, None

    def _exact_params(self, view):
        pass
        t = self.sceneTransform()
        dpr = view.viewport().devicePixelRatioF()
        return max(1e-6, view.transform().m11() * math.hypot(t.m11(), t.m12())) * dpr, dpr

    def build_exact(self, view):
        pass
        device_scale, dpr = self._exact_params(view)
        key = round(device_scale, 4)
        if self._exact_key == key:
            return False
        base = self.pixmap()
        w, h = int(round(base.width() * device_scale)), int(round(base.height() * device_scale))
        if w < 1 or h < 1 or w * h > EXACT_CACHE_MAX_PIXELS:
            self._exact, self._exact_key = None, key
            return False
        source = self._level_pixmap(device_scale)
        exact = source.scaled(w, h, QtCore.Qt.IgnoreAspectRatio, QtCore.Qt.SmoothTransformation)
        exact.setDevicePixelRatio(dpr)
        self._exact, self._exact_key = exact, key
        return True

    def _level_pixmap(self, screen_scale):
        pass
        base = self.pixmap()
        if screen_scale >= 0.75 or self._movie is not None:
            return base


        level = 1.0
        while screen_scale * level * math.sqrt(2) <= 1.0 and level < 64:
            level *= math.sqrt(2)
        level = round(level, 3)
        if level <= 1.0:
            return base
        mip = self._mips.get(level)
        if mip is None:
            w = max(1, int(round(base.width() / level)))
            h = max(1, int(round(base.height() / level)))


            larger = [lv for lv in self._mips if lv < level]
            source = self._mips[max(larger)] if larger else base
            mip = self._mips[level] = source.scaled(w, h, QtCore.Qt.IgnoreAspectRatio, QtCore.Qt.SmoothTransformation)
        return mip

    def paint(self, painter, option, widget=None):
        base = self.pixmap()
        if base.isNull():
            return
        world = painter.worldTransform()
        lod = QtWidgets.QStyleOptionGraphicsItem.levelOfDetailFromTransform(world)
        device = painter.device()
        dpr = device.devicePixelRatioF() if device is not None and hasattr(device, 'devicePixelRatioF') else 1.0
        view = widget.parentWidget() if widget is not None else None
        fast = _is_fast_paint(self, widget)
        target = QtCore.QRectF(self.offset(), QtCore.QSizeF(base.size()))


        scale_only = _enum_int(world.type()) <= _enum_int(QtGui.QTransform.TxScale) and self.transform().isIdentity()
        exact = None
        if getattr(view, '_gpu', False):


            fast = False
            if self._exact is not None:
                self._exact, self._exact_key = None, None
        elif scale_only and self._movie is None and view is not None:
            key = round(lod * dpr, 4)
            if self._exact_key == key:
                exact = self._exact
            elif not fast and hasattr(view, 'request_exact'):
                view.request_exact(self)
        if exact is not None:
            top_left = world.map(target.topLeft())
            painter.save()
            painter.resetTransform()
            painter.drawPixmap(QtCore.QPointF(round(top_left.x()), round(top_left.y())), exact)
            painter.restore()
        else:
            pixmap = self._level_pixmap(lod * dpr)
            painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
            painter.drawPixmap(target, pixmap, QtCore.QRectF(pixmap.rect()))
        _draw_selection_rect(painter, option, target)

    def _update_pixmap(self):
        if self.hover.halo is not None:
            self.hover.halo._glow = None
        if self._movie is not None:
            self._on_movie_frame(0)
        else:
            self.setPixmap(self.canvas_scene.pixmap_for(self.asset_id, self.is_rounded, self.crop))
        self.setTransformOriginPoint(self.boundingRect().center())
        self.grips.update()

    def set_rounded(self, state):
        if state != self.is_rounded:
            self.is_rounded = state
            self._update_pixmap()

    def itemChange(self, change, value):
        value = _snap_position(self, change, value)
        if change in _GEOMETRY_CHANGES:
            _geometry_changed(self)
        elif change == QtWidgets.QGraphicsItem.ItemSceneChange and self._movie is not None:


            if value is None:
                self._movie.stop()
            elif self._movie.state() != QtGui.QMovie.Running:
                self._movie.start()
        return super().itemChange(change, value)
