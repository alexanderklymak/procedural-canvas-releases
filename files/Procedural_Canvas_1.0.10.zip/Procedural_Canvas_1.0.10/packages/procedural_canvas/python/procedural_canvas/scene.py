pass

from ._link import pull
pull(globals())




class CanvasScene(QtWidgets.QGraphicsScene):
    canvas_changed = QtCore.Signal()
    request_save = QtCore.Signal()
    history_amend = QtCore.Signal()
    items_changed = QtCore.Signal()

    def __init__(self, hda_node, parent=None):
        super().__init__(parent)
        self.hda_node = hda_node
        self.snap_to_grid = False
        self.assets = {}
        self._asset_b64 = {}
        self._pixmaps = {}
        self._unreadable_b64 = {}
        self._alive = {}
        self.passthrough_items = []
        self.passthrough_links = []
        self._selection_box = SelectionBox()
        self._box_pending = False
        self._expanding_groups = False
        self.applied_corner = SETTINGS['image_corner']
        self.active_crop = None
        self.selectionChanged.connect(self.refresh_selection_ui)

        self._flow_timer = _precise(QtCore.QTimer(self))
        self._flow_timer.setInterval(int(1000 / LINK_FLOW_FPS))
        self._flow_timer.timeout.connect(self._flow_tick)

    def ensure_flow(self):
        if not self._flow_timer.isActive() and any(l.flow for l in self.link_items()):
            self._flow_timer.start()

    def _flow_tick(self):
        links = [l for l in self.link_items() if l.flow and l.isVisible()]
        if not links:
            if not any(l.flow for l in self.link_items()):
                self._flow_timer.stop()
            return
        phase = time.monotonic() * LINK_FLOW_SPEED
        for link in links:
            link.flow_update(phase)

    def release(self):
        pass


        for item in list(self._alive.values()):
            for name in ('_mips', '_exact', '_exact_key', '_movie', '_movie_buffer'):
                if name in getattr(item, '__dict__', {}):
                    setattr(item, name, {} if name == '_mips' else None)
            if isinstance(item, QtWidgets.QGraphicsPixmapItem):
                try:
                    item.setPixmap(QtGui.QPixmap())
                except RuntimeError:
                    pass
            if 'canvas_scene' in getattr(item, '__dict__', {}):
                item.canvas_scene = None
        self._alive.clear()
        self.assets.clear()
        self._asset_b64.clear()
        self._pixmaps.clear()
        try:
            self.clear()
        except RuntimeError:
            pass



    def addItem(self, item):
        super().addItem(item)
        self._alive[id(item)] = item
        self.items_changed.emit()

    def removeItem(self, item):
        super().removeItem(item)
        self._alive.pop(id(item), None)
        for view in self.views():
            queue = getattr(view, '_exact_queue', None)
            if queue:
                queue[:] = [i for i in queue if i is not item]
        self.items_changed.emit()


    def selected_canvas_items(self):
        return [i for i in self.canvas_items() if i.isSelected()]

    def refresh_selection_ui(self):
        if self._expanding_groups:
            return
        try:
            items = self.canvas_items()
            selected = [i for i in items if i.isSelected()]

            groups = {i.group_id for i in selected if getattr(i, 'group_id', None)}
            if groups:
                missing = [i for i in items
                           if getattr(i, 'group_id', None) in groups and not i.isSelected()]
                if missing:
                    self._expanding_groups = True
                    try:
                        for item in missing:
                            item.setSelected(True)
                    finally:
                        self._expanding_groups = False
                    selected = [i for i in items if i.isSelected()]
            single = len(selected) == 1


            shown = getattr(self, '_grips_shown', [])
            wanted = []
            if single:
                item = selected[0]
                editing = isinstance(item, TextNode) and item.is_editing()
                cropping = getattr(item, 'cropper', None) is not None
                if getattr(item, 'grips', None) is not None and not editing and not cropping and not _is_locked(item):
                    wanted = [item]
            for item in shown:
                if not any(item is w for w in wanted):
                    try:
                        item.grips.set_visible(False)
                    except RuntimeError:
                        pass
            for item in wanted:
                item.grips.set_visible(True)
            self._grips_shown = wanted
            for item in selected:
                item.hover.suspend()
            box = self._selection_box
            if len(selected) >= 2:
                if box.scene() is not self:
                    self.addItem(box)
                box.refresh(selected)
            elif box.scene() is self:
                self.removeItem(box)
                box.targets = []
        except RuntimeError:
            pass

    def update_selection_box(self):
        pass

        if self._selection_box.scene() is not self or self._box_pending:
            return
        self._box_pending = True
        QtCore.QTimer.singleShot(0, self._refresh_selection_box)

    def _refresh_selection_box(self):
        self._box_pending = False
        try:
            box = self._selection_box
            if box.scene() is self:
                box.refresh([i for i in box.targets if i.scene() is self])
        except RuntimeError:
            pass


    def add_asset(self, raw):
        asset_id = hashlib.sha1(raw).hexdigest()
        self.assets.setdefault(asset_id, raw)
        return asset_id

    def asset_b64(self, asset_id):
        b64 = self._asset_b64.get(asset_id)
        if b64 is None:
            b64 = self._asset_b64[asset_id] = base64.b64encode(self.assets[asset_id]).decode('ascii')
        return b64

    @staticmethod
    def _assets_in(states):
        used = set()
        for state in states:
            for d in state.get('items', ()):
                if d.get('asset'):
                    used.add(d['asset'])
        return used

    def prune_assets(self, states):
        pass

        used = self._assets_in(states)
        used |= self._assets_in([{'items': self.passthrough_items}])
        for item in self.canvas_items():
            asset_id = getattr(item, 'asset_id', None)
            if asset_id:
                used.add(asset_id)
        for asset_id in [a for a in self.assets if a not in used]:
            del self.assets[asset_id]
            self._asset_b64.pop(asset_id, None)
        self.prune_pixmaps()

    def prune_pixmaps(self):
        pass

        live = set()
        for item in self.canvas_items():
            if isinstance(item, ImageNode):
                crop = item.crop
                crop_key = (crop.x(), crop.y(), crop.width(), crop.height()) if crop is not None else None
                live.add((item.asset_id, bool(item.is_rounded), crop_key))
            elif isinstance(item, YouTubeNode) and item.asset_id:
                live.add((item.asset_id, False, None))
        for key in [k for k in self._pixmaps if k not in live]:
            del self._pixmaps[key]

    @staticmethod
    def process_image(image, rounded, crop=None):
        pass
        if image.isNull():
            pixmap = QtGui.QPixmap(240, 160)
            pixmap.fill(QtGui.QColor(70, 70, 70))
            return pixmap
        if crop is not None:
            image = image.copy(crop.toRect())
        if not rounded or SETTINGS['image_corner'] <= 0:
            return QtGui.QPixmap.fromImage(image)
        pixmap = QtGui.QPixmap(image.size())
        pixmap.fill(QtCore.Qt.transparent)
        painter = QtGui.QPainter(pixmap)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        path = QtGui.QPainterPath()
        radius = min(image.width(), image.height()) * SETTINGS['image_corner'] / 100.0
        path.addRoundedRect(QtCore.QRectF(image.rect()), radius, radius)
        painter.setClipPath(path)
        painter.drawImage(0, 0, image)
        painter.end()
        return pixmap

    def pixmap_for(self, asset_id, rounded, crop=None):
        crop_key = (crop.x(), crop.y(), crop.width(), crop.height()) if crop is not None else None
        key = (asset_id, bool(rounded), crop_key)
        pixmap = self._pixmaps.get(key)
        if pixmap is None:
            image = QtGui.QImage.fromData(QtCore.QByteArray(self.assets.get(asset_id, b'')))
            pixmap = self._pixmaps[key] = self.process_image(image, rounded, crop)
        return pixmap


    def houdini_paths_for(self, node):
        abs_path = node.path()
        try:
            rel_path = self.hda_node.relativePathTo(node)
        except hou.Error:
            rel_path = abs_path
        return rel_path, abs_path

    def resolve_houdini_node(self, path, abs_path=None):
        for p in (path, abs_path):
            if not p:
                continue
            try:
                node = hou.node(p) if p.startswith('/') else self.hda_node.node(p)
            except hou.Error:
                node = None
            if node is not None:
                return node
        return None


    def canvas_items(self):
        return [i for i in self.items(QtCore.Qt.AscendingOrder) if isinstance(i, CANVAS_TYPES) and i.parentItem() is None]

    def link_items(self):
        return [i for i in self.items() if isinstance(i, LinkNode)]

    def remove_canvas_item(self, item):
        if isinstance(item, FrameNode) and item.collapsed:


            for hidden in item.contained_items():
                if hidden is not item and hidden.scene() is self:
                    self.remove_canvas_item(hidden)
        if isinstance(item, LinkNode):
            item.detach()
        else:
            for link in list(getattr(item, 'links', [])):
                self.remove_canvas_item(link)
        if item.scene() is self:
            self.removeItem(item)

    def reorder(self, targets, mode):
        pass


        order = self.canvas_items()

        def is_selected(item):
            return any(item is t for t in targets)

        selected = [i for i in order if is_selected(i)]
        if not selected:
            return False
        rest = [i for i in order if not is_selected(i)]
        if mode == 'front':
            order = rest + selected
        elif mode == 'back':
            order = selected + rest
        else:
            for item in (reversed(selected) if mode == 'forward' else selected):
                idx = next(k for k, x in enumerate(order) if x is item)
                rng = range(idx + 1, len(order)) if mode == 'forward' else range(idx - 1, -1, -1)
                rect = item.sceneBoundingRect()
                target = next((j for j in rng if not is_selected(order[j]) and order[j].sceneBoundingRect().intersects(rect)), None)
                if target is None:
                    target = next((j for j in rng if not is_selected(order[j])), None)
                if target is None:
                    continue
                order.pop(idx)
                order.insert(target, item)
        for z, item in enumerate(order):
            item.setZValue(z)
        return True

    def _create_item(self, d):
        cls = ITEM_CLASSES.get(d.get('type'))
        if cls is None:
            raise ValueError('Unknown item type: %r' % d.get('type'))
        item = cls.from_dict(d, self)
        self.addItem(item)
        return item

    def _create_link(self, d, by_id):
        start, end = by_id.get(d.get('from')), by_id.get(d.get('to'))
        if start is None or end is None or start is end:
            return None
        link = LinkNode(start, end, d.get('color', LINK_COLOR), d.get('width', 3), uid=d.get('id'),
                        start_side=d.get('from_side', 'auto'), end_side=d.get('to_side', 'auto'),
                        label=d.get('label', ''), dash=d.get('dash', 'solid'), arrows=d.get('arrows', 0),
                        flow=bool(d.get('flow', False)), points=d.get('pts'))
        self.addItem(link)
        if link.flow:
            self.ensure_flow()
        return link


    def export_fragment(self, items):
        pass

        items = list(items)
        for frame in [i for i in items if isinstance(i, FrameNode)]:


            items.extend(i for i in frame.contained_items() if not any(i is t for t in items))
        dicts = [i.to_dict() for i in self.canvas_items() if any(i is t for t in items)]
        ids = {d['id'] for d in dicts}
        links = [l.to_dict() for l in self.link_items() if l.item_start.uid in ids and l.item_end.uid in ids]
        assets = {d['asset']: self.asset_b64(d['asset']) for d in dicts
                  if d.get('asset') in self.assets}
        return {'version': FORMAT_VERSION, 'items': dicts, 'links': links, 'assets': assets}

    def import_fragment(self, fragment, center, select=True):
        for asset_id, b64 in fragment.get('assets', {}).items():
            if asset_id not in self.assets:
                self.assets[asset_id] = base64.b64decode(b64)
                self._asset_b64[asset_id] = b64
        top = max([i.zValue() for i in self.canvas_items()] or [0]) + 1
        id_map = {}
        group_map = {}
        created = []
        for k, d in enumerate(fragment.get('items', [])):
            d = dict(d)
            id_map[d.get('id')] = d['id'] = _new_id()
            if d.get('group'):
                d['group'] = group_map.setdefault(d['group'], _new_id())
            d['z'] = top + k
            try:
                created.append(self._create_item(d))
            except Exception:
                _log_error('Could not paste item %r' % d.get('type'))
        if not created:
            return []
        by_id = {i.uid: i for i in created}
        for d in fragment.get('links', []):
            d = dict(d)
            d['id'] = _new_id()
            d['from'], d['to'] = id_map.get(d.get('from')), id_map.get(d.get('to'))
            self._create_link(d, by_id)
        for item in created:
            if isinstance(item, FrameNode) and item.hidden_ids:
                item.hidden_ids = [id_map[i] for i in item.hidden_ids if i in id_map]
        self.sync_hidden()
        _move_group_center(created, center)
        if select:
            self.clearSelection()
            for item in created:
                item.setSelected(True)
        return created


    def snapshot(self):
        return {'items': [i.to_dict() for i in self.canvas_items()],
                'links': [l.to_dict() for l in self.link_items()]}

    def restore(self, state):
        pass

        snap = self.snap_to_grid
        self.snap_to_grid = False
        try:
            for link in self.link_items():
                link.detach()
                self.removeItem(link)

            existing = {i.uid: i for i in self.canvas_items()}
            wanted = set()
            for d in state['items']:
                wanted.add(d['id'])
                item = existing.get(d['id'])
                try:
                    if item is not None and item.TYPE == d.get('type'):
                        item.apply_dict(d)
                        continue
                    if item is not None:
                        self.removeItem(item)
                    self._create_item(d)
                except Exception:



                    _log_error('Could not restore item %r' % d.get('type'))
                    if not any(p.get('id') == d['id'] for p in self.passthrough_items):
                        self.passthrough_items.append(d)
            for uid, item in existing.items():
                if uid not in wanted:
                    self.removeItem(item)

            by_id = {i.uid: i for i in self.canvas_items()}
            for d in state['links']:
                self._create_link(d, by_id)
        finally:
            self.snap_to_grid = snap
        self.sync_hidden()
        self.refresh_selection_ui()

    def sync_hidden(self):
        pass
        hidden = set()
        for frame in self.canvas_items():
            if isinstance(frame, FrameNode) and frame.collapsed:
                hidden.update(frame.hidden_ids)
        for item in self.canvas_items():
            item.setVisible(item.uid not in hidden)
        self.sync_link_visibility()

    def sync_link_visibility(self):
        for link in self.link_items():
            link.setVisible(link.item_start.isVisible() and link.item_end.isVisible())

    def wrap_in_frame(self, items, title, color):
        pass
        if not items:
            return None
        rect = _items_rect(items).adjusted(-40, -40, 40, 40)
        frame = FrameNode(QtCore.QRectF(0, 0, rect.width(), rect.height()), title=title, color=color)
        frame.setPos(rect.topLeft())
        frame.setZValue(min(i.zValue() for i in self.canvas_items()) - 1)
        self.addItem(frame)
        return frame


    def load_document(self, doc):
        pass
        problems = []
        for asset_id, b64 in doc.get('assets', {}).items():
            try:
                self.assets[asset_id] = base64.b64decode(b64)
                self._asset_b64[asset_id] = b64
            except Exception:
                problems.append('image %s' % asset_id)
                self._unreadable_b64[asset_id] = b64
        for d in doc.get('items', []):
            try:
                self._create_item(d)
            except Exception:
                _log_error('Could not create item %r' % d.get('type'))
                self.passthrough_items.append(d)
                problems.append('item of type %r' % d.get('type'))
        by_id = {i.uid: i for i in self.canvas_items()}
        for d in doc.get('links', []):
            if self._create_link(d, by_id) is None:
                self.passthrough_links.append(d)
        self.sync_hidden()
        return problems

    def to_document(self, state=None):
        state = state or self.snapshot()
        items = state['items'] + self.passthrough_items
        ids = {d.get('id') for d in items}
        links = state['links'] + [l for l in self.passthrough_links if l.get('from') in ids and l.get('to') in ids]
        used = {d.get('asset') for d in items if d.get('asset')}
        assets = {aid: self.asset_b64(aid) for aid in used if aid in self.assets}
        assets.update({aid: b64 for aid, b64 in self._unreadable_b64.items() if aid in used and aid not in assets})
        self.prune_pixmaps()
        return {'version': FORMAT_VERSION, 'items': items, 'links': links, 'assets': assets}
