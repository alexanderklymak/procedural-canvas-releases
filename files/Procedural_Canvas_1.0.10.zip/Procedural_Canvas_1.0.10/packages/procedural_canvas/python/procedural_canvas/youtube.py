pass

from ._link import pull
pull(globals())




_YOUTUBE_RE = re.compile(r'(?:youtube\.com/(?:watch\?(?:[^#\s]*&)?v=|shorts/|embed/|live/|v/)|youtu\.be/)'
                         r'([A-Za-z0-9_-]{11})')
YOUTUBE_RED = '#ff0033'


def _youtube_id(text):
    match = _YOUTUBE_RE.search(text or '')
    return match.group(1) if match else None


class _HttpFetcher(QtCore.QObject):
    pass


    done = QtCore.Signal(object, object, object)

    def __init__(self):
        super().__init__()
        self.done.connect(self._deliver)

    @staticmethod
    def _deliver(callback, data, error):
        try:
            callback(data, error)
        except RuntimeError:
            pass

    def get(self, url, callback, limit=MAX_DOWNLOAD_BYTES):
        def work():
            try:
                request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Procedural Canvas)'})
                with open_url(request, timeout=15) as response:
                    data, error = response.read(limit + 1), None
                if len(data) > limit:
                    data, error = b'', 'file is too large'
            except Exception as exc:
                data, error = b'', str(exc)
            self.done.emit(callback, data, error)
        threading.Thread(target=work, daemon=True).start()


_FETCHER = None


def _http_get(url, callback):
    global _FETCHER
    if _FETCHER is None:
        _FETCHER = _HttpFetcher()
    _FETCHER.get(url, callback)


def _two_lines(text, metrics, width):
    pass
    words = text.split()
    first = ''
    while words:
        candidate = (first + ' ' + words[0]).strip()
        if metrics.horizontalAdvance(candidate) > width and first:
            break
        first = candidate
        words.pop(0)
    if metrics.horizontalAdvance(first) > width:
        return [metrics.elidedText(first, QtCore.Qt.ElideRight, int(width))]
    rest = ' '.join(words)
    lines = [first]
    if rest:
        lines.append(metrics.elidedText(rest, QtCore.Qt.ElideRight, int(width)))
    return lines


class YouTubeNode(QtWidgets.QGraphicsItem):
    pass


    TYPE = 'youtube'
    W, THUMB_H, FOOTER_H, RADIUS = 480.0, 270.0, 88.0, 14.0
    PLAY_W, PLAY_H = 68.0, 48.0

    def __init__(self, scene, url, title='', author='', asset_id=None, uid=None):
        super().__init__()
        self.uid = uid or _new_id()
        self.canvas_scene = scene
        self.url = url
        self.video_id = _youtube_id(url) or ''
        self.title = title
        self.author = author
        self.asset_id = asset_id
        self.links = []
        self.hover = HoverEffect(self)
        self._card_hover = False
        self._play_hover = False
        self._press_screen = None
        self._pending = 0
        self._error = None
        self.setFlags(QtWidgets.QGraphicsItem.ItemIsSelectable | QtWidgets.QGraphicsItem.ItemIsMovable
                      | QtWidgets.QGraphicsItem.ItemSendsGeometryChanges)
        self.setAcceptHoverEvents(True)
        self.setTransformOriginPoint(self.card_rect().center())
        self.grips = ItemGrips(self, rotate=True)

        self.setCacheMode(QtWidgets.QGraphicsItem.DeviceCoordinateCache)

    @classmethod
    def from_dict(cls, d, scene):
        item = cls(scene, d.get('url', ''), title=d.get('title', ''), author=d.get('author', ''),
                   asset_id=d.get('asset'), uid=d.get('id'))
        _apply_base(item, d)
        if not item.title or not item.asset_id:
            item.fetch()
        return item

    def to_dict(self):
        d = _base_dict(self)
        d.update(url=self.url, title=self.title, author=self.author)
        if self.asset_id:
            d['asset'] = self.asset_id
        return d

    def apply_dict(self, d):
        _apply_base(self, d)
        changed = (d.get('url', ''), d.get('title', ''), d.get('author', ''), d.get('asset')) != \
                  (self.url, self.title, self.author, self.asset_id)
        if changed:
            self.url, self.title, self.author, self.asset_id = d.get('url', ''), d.get('title', ''), d.get('author', ''), d.get('asset')
            self.video_id = _youtube_id(self.url) or ''
            self.update()


    def card_rect(self):
        return QtCore.QRectF(0, 0, self.W, self.THUMB_H + self.FOOTER_H)

    def grip_rect(self):
        return self.card_rect()

    def content_rect(self):
        return self.card_rect()

    def corner_radius(self):
        return self.RADIUS

    def boundingRect(self):
        return self.card_rect().adjusted(-3, -3, 3, 3)

    def shape(self):
        path = QtGui.QPainterPath()
        path.addRoundedRect(self.card_rect(), self.RADIUS, self.RADIUS)
        return path

    def _play_rect(self):
        scale = 1.12 if self._play_hover else 1.0
        rect = QtCore.QRectF(0, 0, self.PLAY_W * scale, self.PLAY_H * scale)
        rect.moveCenter(QtCore.QPointF(self.W / 2, self.THUMB_H / 2))
        return rect


    def fetch(self):
        if not self.video_id or self._pending:
            return
        self._error = None
        watch = 'https://www.youtube.com/watch?v=' + self.video_id
        self._get('https://www.youtube.com/oembed?' + urllib.parse.urlencode({'url': watch, 'format': 'json'}),
                  self._on_info)
        if not self.asset_id:
            self._get_thumb(['maxresdefault', 'sddefault', 'hqdefault'])
        self.update()

    def _get(self, url, callback):
        self._pending += 1

        def finished(data, error):
            self._pending -= 1
            if error:
                self._error = error
                _log_info('YouTube: %s — %s' % (url, error))
            callback(data)
            self.update()
        _http_get(url, finished)

    def _get_thumb(self, names):
        url = 'https://i.ytimg.com/vi/%s/%s.jpg' % (self.video_id, names[0])
        self._get(url, lambda data, rest=names[1:]: self._on_thumb(data, rest))

    def _on_info(self, data):
        try:
            info = json.loads(data.decode('utf-8')) if data else {}
        except ValueError:
            info = {}
        title, author = info.get('title') or '', info.get('author_name') or ''
        if (title and title != self.title) or (author and author != self.author):
            self.title = title or self.title
            self.author = author or self.author
            self._error = None
            self._changed(history=False)

    def _on_thumb(self, data, fallbacks):
        image = QtGui.QImage.fromData(QtCore.QByteArray(data)) if data else QtGui.QImage()
        if image.isNull() or image.width() < 200:
            if fallbacks:
                self._error = None
                self._get_thumb(fallbacks)
            return
        target_h = int(image.width() * 9 / 16)
        if image.height() > target_h:
            image = image.copy(0, (image.height() - target_h) // 2, image.width(), target_h)
        if image.width() > 960:
            image = image.scaledToWidth(960, QtCore.Qt.SmoothTransformation)
        self.asset_id = self.canvas_scene.add_asset(_encode_image(image))
        self._changed(history=False)

    def _changed(self, history=True):
        pass

        self.update()
        scene = self.scene()
        if isinstance(scene, CanvasScene):
            scene.request_save.emit()
            (scene.canvas_changed if history else scene.history_amend).emit()


    def open_video(self):
        QtGui.QDesktopServices.openUrl(QtCore.QUrl(self.url or 'https://www.youtube.com/watch?v=' + self.video_id))

    def copy_link(self):
        QtWidgets.QApplication.clipboard().setText(self.url)

    def refresh(self):
        self.asset_id = None
        self.update()
        self.fetch()



    CARD_BG, TITLE_COLOR, SUB_COLOR = '#ffffff', '#0f0f0f', '#606060'

    def paint(self, painter, option, widget=None):
        card = self.card_rect()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        clip = QtGui.QPainterPath()
        clip.addRoundedRect(card, self.RADIUS, self.RADIUS)
        painter.save()
        painter.setClipPath(clip)


        thumb_rect = QtCore.QRectF(0, 0, self.W, self.THUMB_H)
        pixmap = self.canvas_scene.pixmap_for(self.asset_id, False) if self.asset_id in self.canvas_scene.assets else None
        if pixmap is not None and not pixmap.isNull():
            src = QtCore.QRectF(pixmap.rect())
            k = max(thumb_rect.width() / src.width(), thumb_rect.height() / src.height())
            w, h = thumb_rect.width() / k, thumb_rect.height() / k
            src = QtCore.QRectF(src.center().x() - w / 2, src.center().y() - h / 2, w, h)
            painter.drawPixmap(thumb_rect, pixmap, src)
        else:
            gradient = QtGui.QLinearGradient(thumb_rect.topLeft(), thumb_rect.bottomRight())
            gradient.setColorAt(0, QtGui.QColor('#f4f4f6'))
            gradient.setColorAt(1, QtGui.QColor('#e4e4e8'))
            painter.fillRect(thumb_rect, gradient)
            font = _ui_font(13)
            painter.setFont(font)
            painter.setPen(QtGui.QColor('#8a8a8a'))
            if self._pending:
                status = 'Loading preview…'
            elif self._error:
                status = 'Could not load the preview\n%s' % QtGui.QFontMetricsF(font).elidedText(
                    self._error, QtCore.Qt.ElideRight, int(self.W - 60))
            else:
                status = 'No preview'
            painter.drawText(thumb_rect.adjusted(20, 80, -20, 0), QtCore.Qt.AlignCenter, status)

        if pixmap is not None and not pixmap.isNull():

            shade = QtGui.QLinearGradient(0, self.THUMB_H * 0.5, 0, self.THUMB_H)
            shade.setColorAt(0, QtGui.QColor(0, 0, 0, 0))
            shade.setColorAt(1, QtGui.QColor(0, 0, 0, 30 if self._card_hover else 60))
            painter.fillRect(thumb_rect, shade)


        play = self._play_rect()
        painter.setPen(QtCore.Qt.NoPen)
        painter.setBrush(QtGui.QColor(YOUTUBE_RED) if self._card_hover else QtGui.QColor(20, 20, 20, 200))
        painter.drawRoundedRect(play, play.height() * 0.28, play.height() * 0.28)
        c = play.center()
        s = play.height() * 0.22
        painter.setBrush(QtGui.QColor('#ffffff'))
        painter.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(c.x() - s * 0.8, c.y() - s),
                                             QtCore.QPointF(c.x() - s * 0.8, c.y() + s),
                                             QtCore.QPointF(c.x() + s * 1.1, c.y())]))


        footer = QtCore.QRectF(0, self.THUMB_H, self.W, self.FOOTER_H)
        painter.fillRect(footer, QtGui.QColor(self.CARD_BG))
        logo = QtCore.QRectF(16, self.THUMB_H + 16, 30, 21)
        painter.setBrush(QtGui.QColor(YOUTUBE_RED))
        painter.drawRoundedRect(logo, 6, 6)
        lc, ls = logo.center(), 4.5
        painter.setBrush(QtGui.QColor('#ffffff'))
        painter.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(lc.x() - ls * 0.75, lc.y() - ls),
                                             QtCore.QPointF(lc.x() - ls * 0.75, lc.y() + ls),
                                             QtCore.QPointF(lc.x() + ls, lc.y())]))
        text_x = 60.0
        text_w = self.W - text_x - 16
        title_font = _ui_font(15, bold=True)
        metrics = QtGui.QFontMetricsF(title_font)
        painter.setFont(title_font)
        painter.setPen(QtGui.QColor(self.TITLE_COLOR))
        y = self.THUMB_H + 14
        title = self.title or ('Loading…' if self._pending else 'YouTube video')
        for line in _two_lines(title, metrics, text_w):
            painter.drawText(QtCore.QRectF(text_x, y, text_w, metrics.height()), QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter, line)
            y += metrics.height()
        sub_font = _ui_font(12)
        painter.setFont(sub_font)
        painter.setPen(QtGui.QColor(self.SUB_COLOR))
        sub = '%s  ·  YouTube' % self.author if self.author else 'YouTube'
        painter.drawText(QtCore.QRectF(text_x, self.THUMB_H + self.FOOTER_H - 28, text_w, 18),
                         QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter,
                         QtGui.QFontMetricsF(sub_font).elidedText(sub, QtCore.Qt.ElideRight, int(text_w)))
        painter.restore()


        painter.setBrush(QtCore.Qt.NoBrush)
        if self.isSelected():
            painter.setPen(QtGui.QPen(QtGui.QColor(*GLOW_COLOR), 2.5))
        else:
            painter.setPen(QtGui.QPen(QtGui.QColor(0, 0, 0, 28), 1))
        painter.drawRoundedRect(card.adjusted(0.5, 0.5, -0.5, -0.5), self.RADIUS, self.RADIUS)


    def _over_play(self, pos):
        return self._play_rect().adjusted(-6, -6, 6, 6).contains(pos)

    def hoverEnterEvent(self, event):
        self._card_hover = True
        self.hover.enter()
        self.update()
        super().hoverEnterEvent(event)

    def hoverMoveEvent(self, event):
        over = self._over_play(event.pos())
        if over != self._play_hover:
            self._play_hover = over
            if over:
                self.setCursor(QtCore.Qt.PointingHandCursor)
            else:
                self.unsetCursor()
            self.update()
        super().hoverMoveEvent(event)

    def hoverLeaveEvent(self, event):
        self._card_hover = self._play_hover = False
        self.unsetCursor()
        self.hover.leave()
        self.update()
        super().hoverLeaveEvent(event)

    def mousePressEvent(self, event):
        self.hover.suspend()
        self._press_screen = event.screenPos()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)

        if (event.button() == QtCore.Qt.LeftButton and self._press_screen is not None and self._over_play(event.pos())
                and QtCore.QLineF(QtCore.QPointF(self._press_screen), QtCore.QPointF(event.screenPos())).length() < 4):
            self.open_video()
        self._press_screen = None
        self.hover.resume()

    def mouseDoubleClickEvent(self, event):
        self.open_video()
        event.accept()

    def itemChange(self, change, value):
        value = _snap_position(self, change, value)
        if change in _GEOMETRY_CHANGES:
            _geometry_changed(self)
        return super().itemChange(change, value)
