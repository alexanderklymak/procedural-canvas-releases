


def _procedural_canvas_startup():
    import hou

    def before_load(event_type):
        if event_type != hou.hipFileEventType.BeforeLoad:
            return
        try:
            hou.hipFile.removeEventCallback(before_load)
        except Exception:
            pass
        try:
            import procedural_canvas
            procedural_canvas.ensure_loader_hda()
        except Exception as exc:
            print('[Procedural Canvas] could not prepare the node: %s' % exc)

    try:
        hou.hipFile.addEventCallback(before_load)
    except Exception:
        pass


_procedural_canvas_startup()
del _procedural_canvas_startup
