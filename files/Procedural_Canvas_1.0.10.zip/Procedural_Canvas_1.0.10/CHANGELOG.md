# Changelog

The version is set only here and in `PLUGIN_VERSION` (`procedural_canvas/python/procedural_canvas/core.py`).
Scheme `MAJOR.MINOR.PATCH`: patch — bug fixes, minor — new features, major — only if boards or the HDA
stop being compatible. The first bullet lines of a version become the "What's new" text of the update hint.

## 1.0.10 — 2026-10-22

- macOS: menus, toolbar buttons and the tool list show correctly (emoji replaced by Houdini icons)

## 1.0.9 — 2026-10-22

- License check and updates now work on macOS (fixed the SSL certificate error)

## 1.0.8 — 2026-10-21

- Grid no longer jitters during zoom

## 1.0.7 — 2026-10-21

- Memory is freed when a board is closed; user guide (Settings > About > User guide); a new major version is never installed automatically

## 1.0.6 — 2026-10-21

- Houdini 22 support (Python 3.13)

## 1.0.5 — 2026-10-21

- Fixed: docking a board into a Houdini pane

## 1.0.4 — 2026-10-20

- Node icon updates reliably

## 1.0.3 — 2026-10-20

- More reliable automatic updates (OneDrive folders); icons and menus are updated too

## 1.0.2 — 2026-10-20

- Fixed: the update message did not appear

## 1.0.1 — 2026-10-20

- New node icon (KL logo)

## 1.0.0 — first release

- Board inside Houdini: notes, stickies, code blocks, images and GIFs, YouTube cards, brushes, shapes, links, frames.
- Presentation mode, minimap, search, PNG export.
- Install by copying the package into the Houdini packages folder (Houdini 20.5 and 21).
